#!/usr/bin/env python3
"""Summarize synchronizing native profiler diagnostics, never HTTP performance scores."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

from bundle_integrity import verify as verify_bundle
from validate_runs import inspect_run, ordered_hashes

BASE = "5f95115e703ffe51e03e40ae23c78ff841c3335e"
HEAD = "39a06eac411a377e0bc1eb13bdbceb10c9783bf6"
TARGETS = ("text_encoder.forward", "transformer.forward", "vae.decode")
MATCH_FIELDS = ("compile_mode", "parallelism", "dtype", "attention_backend", "cache_backend",
                "vae_mode", "vae_degree", "model_revision", "model_config_sha256", "versions", "client_sha256")
WORKER_FIELDS = ("ir_op_priority", "torch_version", "torch_cuda_version", "cudnn_version", "gpu_name",
                 "gpu_memory_bytes", "matmul_allow_tf32", "cudnn_allow_tf32", "float32_matmul_precision")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def all_rows(run):
    return [json.loads(line) for line in (run["directory"] / "http/requests.jsonl").read_text().splitlines()]


def extract_stages(row):
    try:
        raw = row["server_response_fields"]["metrics"]["stage_durations"]
        normalized = row["server_time_metrics_ms"]
        result = {}
        for target in TARGETS:
            key = "Flux2KleinPipeline." + target
            value = raw[key]
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"Invalid native stage seconds: {key}")
            milliseconds = float(value) * 1000
            if not math.isclose(normalized["stage_durations." + key + "_ms"], milliseconds, rel_tol=1e-12):
                raise ValueError(f"Native stage normalization mismatch: {key}")
            result[target] = milliseconds
        return result
    except KeyError as error:
        raise ValueError(f"Missing source-backed native stage metric: {error}") from error


def worker_configuration(run):
    return [{key: record["worker"].get(key) for key in WORKER_FIELDS}
            for record in run["metadata"]["startup_activation"]["records"]]


def inspect_stage(directory, bundle):
    run = inspect_run(directory)
    meta, client = run["metadata"], run["client"]
    if not meta.get("diagnostic") or not meta.get("stage_metrics_enabled") or meta.get("compile_mode") != "regional":
        raise ValueError("Expected a regional-compile stage diagnostic")
    if meta.get("stage_bundle_sha256") != bundle or not meta.get("stage_bundle_unchanged"):
        raise ValueError("Stage bundle is not the frozen, unchanged tested bundle")
    if meta.get("stage_bundle_manifest_sha256") != digest(Path(__file__).parent / "BUNDLE_MANIFEST.json"):
        raise ValueError("Stage bundle manifest hash mismatch")
    if meta.get("launcher_sha256") != bundle["launch_native.py"] or meta.get("client_sha256") != bundle["bench_tp_service.py"]:
        raise ValueError("Launcher/client hash mismatch")
    if client.get("batches") != [1, 4] or client.get("warmup_per_batch") != 3 or client.get("repeats_per_batch") != 5:
        raise ValueError("Stage workload count mismatch")
    source = meta["source_sha256"]
    if source["vllm_omni/diffusion/profiler/diffusion_pipeline_profiler.py"] != bundle["native_profiler_reference.py"]:
        raise ValueError("Native profiler differs from the CPU-tested source")
    receipt = meta["startup_activation"]
    if len(receipt["records"]) != 4:
        raise ValueError("Stage protocol requires four native worker receipts")
    for record in receipt["records"]:
        rank = record["rank"]
        path = run["directory"] / "startup_activation" / f"rank{rank}.json"
        if digest(path) != receipt["files_sha256"][path.name] or json.loads(path.read_text()) != record:
            raise ValueError("Startup receipt changed")
        stage = record.get("stage_profiler", {})
        if (not stage.get("enabled") or stage.get("targets") != list(TARGETS)
                or stage.get("profiler_source_sha256") != bundle["native_profiler_reference.py"]
                or stage.get("native_outer_wrappers") != dict.fromkeys(TARGETS, True)
                or stage.get("output_rank") != 0 or stage.get("compiled_block_forwards_patched_by_probe") is not False):
            raise ValueError("Native stage wrapper proof missing or mismatched")
    rows = all_rows(run)
    if len(rows) != 16 or any(row["scored"] or row["correctness_only"] or row["profiled"] for row in rows):
        raise ValueError("Unexpected stage request count or scored/profiled row")
    for batch in (1, 4):
        group = [row for row in rows if row["batch"] == batch]
        if len(group) != 8 or sum(row["warmup"] for row in group) != 3:
            raise ValueError("Missing warmup or measured stage requests")
        if len({row["payload_sha256"] for row in group}) != 1:
            raise ValueError("Stage request input changed")
    for row in rows:
        if row["payload"].get("num_inference_steps") != 4 or row["payload"].get("guidance_scale") != 1.0:
            raise ValueError("Stage steps/guidance mismatch")
        extract_stages(row)
    return run


def distribution(values):
    return {"samples_ms": values, "mean_ms": statistics.mean(values),
            "std_ms": statistics.stdev(values) if len(values) > 1 else 0,
            "min_ms": min(values), "max_ms": max(values)}


def compare_native(stage_run, native_dirs):
    results = []
    stage_rows = all_rows(stage_run)
    for directory in native_dirs:
        native = inspect_run(directory)
        if native["metadata"]["diagnostic"] or native["metadata"].get("stage_metrics_enabled"):
            raise ValueError("Native comparison must be uninstrumented")
        if native["metadata"]["variant"] != stage_run["metadata"]["variant"]:
            continue
        for key in MATCH_FIELDS + ("source_sha", "source_sha256"):
            if native["metadata"].get(key) != stage_run["metadata"].get(key):
                raise ValueError(f"Stage/native configuration mismatch: {key}")
        if worker_configuration(native) != worker_configuration(stage_run):
            raise ValueError("Stage/native worker configuration mismatch")
        native_rows = all_rows(native)
        matches = []
        for row in stage_rows:
            corresponding = [other for other in native_rows if other["payload_sha256"] == row["payload_sha256"]]
            if not corresponding:
                raise ValueError("No native request matches diagnostic input")
            matches.append({"label": row["label"], "batch": row["batch"],
                            "matched_native_requests": len(corresponding),
                            "exact_to_all_native_repeats": all(ordered_hashes(row) == ordered_hashes(other)
                                                               for other in corresponding)})
        results.append({"directory": str(directory), "variant": native["metadata"]["variant"],
                        "all_stage_images_exact_to_all_native_repeats": all(item["exact_to_all_native_repeats"] for item in matches),
                        "requests": matches})
    return {"status": "NOT_CHECKED" if not results else ("EXACT" if all(item["all_stage_images_exact_to_all_native_repeats"] for item in results) else "DIFFERENT"),
            "comparisons": results, "interpretation": "A difference does not identify its cause; no observational-neutrality claim."}


def summarize(base_directory, candidate_directory, native_dirs=()):
    bundle = verify_bundle(Path(__file__).parent)
    runs = [inspect_stage(directory, bundle) for directory in (base_directory, candidate_directory)]
    base, candidate = runs
    for run, variant, source in zip(runs, ("O", "A"), (BASE, HEAD), strict=True):
        if run["metadata"]["source_sha"] != source or run["metadata"]["variant"] != variant:
            raise ValueError("Unexpected source/variant")
    for key in MATCH_FIELDS:
        if base["metadata"].get(key) != candidate["metadata"].get(key):
            raise ValueError(f"Unmatched stage configuration: {key}")
    if worker_configuration(base) != worker_configuration(candidate):
        raise ValueError("Unmatched stage worker configuration")
    report = {"kind": "native_stage_diagnostic", "scored": False, "performance_claim_eligible": False,
              "execution_integrity": "PASS", "rank": 0, "across_rank_aggregation": None,
              "timing_method": "Native synchronize/perf_counter/synchronize; seconds converted to ms.",
              "transformer_scope": "Sum of four transformer.forward calls per request; excludes scheduler, latent preparation, text encoder and VAE.",
              "four_call_basis": "Four configured inference steps and guidance_scale=1; source control flow and CPU wrapper test, not a runtime kernel-count proof.",
              "limitations": "Synchronizing instrumentation changes execution. One process per variant and five samples per batch; no confidence interval or independent process replication.",
              "runs": [{"directory": str(run["directory"]), "source_sha": run["metadata"]["source_sha"],
                        "metadata_sha256": digest(run["directory"] / "metadata.json"),
                        "requests_sha256": digest(run["directory"] / "http/requests.jsonl")} for run in runs],
              "native_image_comparison": [compare_native(run, native_dirs) for run in runs], "batches": {}}
    for batch in (1, 4):
        groups = [[row for row in all_rows(run) if row["batch"] == batch] for run in runs]
        if len({row["payload_sha256"] for group in groups for row in group}) != 1:
            raise ValueError("Cross-arm stage inputs differ")
        stage_values = [[extract_stages(row) for row in run["samples"][batch]] for run in runs]
        item = {"within_process_images_exact_including_warmup": [len({ordered_hashes(row) for row in group}) == 1 for group in groups],
                "cross_variant_all_images_exact": len({ordered_hashes(row) for group in groups for row in group}) == 1,
                "stages": {}}
        for target in TARGETS:
            summaries = [distribution([value[target] for value in values]) for values in stage_values]
            item["stages"][target] = {"baseline": summaries[0], "candidate": summaries[1],
                                        "diagnostic_latency_reduction_fraction": 1 - summaries[1]["mean_ms"] / summaries[0]["mean_ms"]}
        report["batches"][str(batch)] = item
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--native", type=Path, nargs="*", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = summarize(args.baseline, args.candidate, args.native)
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"execution_integrity": report["execution_integrity"], "scored": False,
                      "native_image_comparison": [item["status"] for item in report["native_image_comparison"]]}))


if __name__ == "__main__":
    main()
