"""Startup receipts, plus opt-in unscored outer-module boundary observations.

No production source is modified. No block.forward is replaced. Diagnostics
are attached after regional compilation, outside the compiled bound forward.
The default startup-only mode registers no forward hooks and reads no tensors.
"""

from __future__ import annotations

import functools
import dataclasses
import hashlib
import importlib.abc
import importlib.machinery
import json
import os
import sys
import time
from pathlib import Path

MODEL = "vllm_omni.diffusion.models.flux2_klein.flux2_klein_transformer"
WORKER = "vllm_omni.diffusion.worker.diffusion_worker"
RUNNER = "vllm_omni.diffusion.worker.diffusion_model_runner"
PIPELINE = "vllm_omni.diffusion.models.flux2_klein.pipeline_flux2_klein"
STAGE_TARGETS = ("text_encoder.forward", "transformer.forward", "vae.decode")
STATE = {}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def serializable(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    return repr(value)


def configured_compile(block):
    forward = block.forward
    return hasattr(forward, "_torchdynamo_orig_callable") or hasattr(forward, "_torchdynamo_inline")


def record_model(module, model):
    import torch.distributed as dist
    from vllm.distributed import get_tensor_model_parallel_rank, get_tensor_model_parallel_world_size

    if not dist.is_initialized():
        raise RuntimeError("Probe requires real initialized distributed workers")
    rank, world = dist.get_rank(), dist.get_world_size()
    tp_rank, tp = get_tensor_model_parallel_rank(), get_tensor_model_parallel_world_size()
    if world != tp or world != int(os.environ["KLEIN_PROBE_TP"]) or rank != tp_rank:
        raise RuntimeError("Probe requires pure TP/SP1 and contiguous ranks")
    path = Path(module.__file__).resolve()
    if not path.is_relative_to(Path(os.environ["KLEIN_PROBE_SOURCE_ROOT"]).resolve()):
        raise RuntimeError("Imported model outside frozen source")
    if sha256(path) != os.environ["KLEIN_PROBE_MODULE_SHA"]:
        raise RuntimeError("Imported model source hash changed")
    blocks = []
    for index, block in enumerate(model.single_transformer_blocks):
        attn = block.attn
        blocks.append({
            "index": index, "local_tp": bool(getattr(attn, "local_tp", False)),
            "global_heads": attn.heads, "query_num_heads": getattr(attn, "query_num_heads", attn.heads),
            "attention_num_heads": attn.attn.num_heads,
            "input_projection_class": type(attn.to_qkv_mlp_proj).__name__,
            "input_projection_gather_output": getattr(attn.to_qkv_mlp_proj, "gather_output", None),
        })
    STATE.update({
        "schema_version": 2, "status": "PASS", "rank": rank, "world_size": world,
        "tp_rank": tp_rank, "tp_world_size": tp, "pid": os.getpid(), "variant": os.environ["KLEIN_PROBE_VARIANT"],
        "source_sha": os.environ["KLEIN_PROBE_SOURCE_SHA"], "module_file": str(path), "module_sha256": sha256(path),
        "hook_sha256": sha256(__file__), "blocks": blocks, "compile_mode": os.environ["KLEIN_PROBE_COMPILE_MODE"],
    })


def publish_receipt():
    STATE["unix_s"] = time.time()
    STATE["scope"] = "Native worker configuration and constructor/compile setup; not executed-kernel proof"
    directory = Path(os.environ["KLEIN_PROBE_DIR"])
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"rank{STATE['rank']}.json"
    temporary = path.with_suffix(f".tmp-{os.getpid()}")
    try:
        with temporary.open("x") as stream:
            stream.write(json.dumps(STATE, indent=2) + "\n")
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


class BoundaryObserver:
    """Only hashes the first post-warmup request per batch, with a hard byte cap."""

    def __init__(self, model):
        self.model = model
        self.rank = STATE["rank"]
        self.directory = Path(os.environ["KLEIN_PROBE_CAPTURE_DIR"]) / f"rank{self.rank}"
        self.directory.mkdir(parents=True, exist_ok=False)
        self.marker = Path(os.environ["KLEIN_PROBE_MARKER"])
        self.max_bytes = int(os.environ["KLEIN_PROBE_CAPTURE_MAX_BYTES"])
        self.bytes_read = 0
        self.request = None
        self.step = -1
        self.enabled = False
        self.sequence = 0

    def tensor_tree(self, value, aliases=None):
        import torch

        if aliases is None:
            aliases = {}
        if isinstance(value, torch.Tensor):
            self.bytes_read += value.numel() * value.element_size()
            if self.bytes_read > self.max_bytes:
                raise RuntimeError("Diagnostic tensor hashing byte budget exceeded")
            storage = value.untyped_storage()
            identity = (str(value.device), storage.data_ptr())
            alias = aliases.setdefault(identity, len(aliases))
            # Hash logical values; metadata separately preserves original views.
            data = value.detach().contiguous().reshape(-1).view(torch.uint8).cpu().numpy().tobytes()
            return {"tensor": True, "shape": list(value.shape), "dtype": str(value.dtype),
                    "stride": list(value.stride()), "storage_offset": value.storage_offset(),
                    "storage_bytes": storage.nbytes(), "alias_group": alias,
                    "sha256": hashlib.sha256(data).hexdigest()}
        if isinstance(value, dict):
            return {str(k): self.tensor_tree(v, aliases) for k, v in value.items()}
        if isinstance(value, (tuple, list)):
            return [self.tensor_tree(v, aliases) for v in value]
        if dataclasses.is_dataclass(value) and not isinstance(value, type):
            return {field.name: self.tensor_tree(getattr(value, field.name), aliases) for field in dataclasses.fields(value)}
        return serializable(value)

    def emit(self, kind, name, value):
        import torch

        if torch.compiler.is_compiling():
            raise RuntimeError("Boundary observer entered compilation; diagnostics invalid")
        record = {"sequence": self.sequence, "request": self.request, "step": self.step,
                  "kind": kind, "name": name, "tree": self.tensor_tree(value),
                  "rank": self.rank, "outside_compile": True}
        self.sequence += 1
        with (self.directory / "events.jsonl").open("a") as stream:
            stream.write(json.dumps(record, separators=(",", ":")) + "\n")

    def transformer_pre(self, module, args, kwargs):
        import torch

        self.enabled = False
        if not self.marker.exists():
            return
        marker = json.loads(self.marker.read_text())
        if marker.get("iteration") != 0:
            return
        request = f"b{marker['batch']}-sample-00"
        if request != self.request:
            self.request, self.step = request, -1
        self.step += 1
        self.enabled = True
        rng = {"cpu_rng": torch.get_rng_state(), "cuda_rng": torch.cuda.get_rng_state()}
        self.emit("input", "transformer", {"args": args, "kwargs": kwargs, "rng_state": rng})
        if self.step == 0:
            # This identifies resolved object/method configuration only. For IR
            # lowering, actual provider evidence must come from a separate trace.
            providers = []
            for index, block in enumerate(module.single_transformer_blocks):
                norm = block.attn.norm_q
                method = getattr(norm, "_forward_method", norm.forward)
                providers.append({"index": index, "class": type(norm).__module__ + "." + type(norm).__qualname__,
                                  "method": getattr(method, "__qualname__", repr(method))})
            with (self.directory / f"{request}-providers.json").open("x") as stream:
                json.dump({"scope": "Live norm objects and native worker IR priority, not a kernel trace",
                           "worker": STATE["worker"], "norm_q": providers}, stream, indent=2)

    def transformer_post(self, module, args, kwargs, output):
        if self.enabled:
            self.emit("output", "transformer", output)
            self.enabled = False

    def block_pre(self, name):
        def observe(module, args, kwargs):
            if self.enabled:
                self.emit("input", name, {"args": args, "kwargs": kwargs})
        return observe

    def block_post(self, name):
        def observe(module, args, kwargs, output):
            if self.enabled:
                self.emit("output", name, output)
        return observe

    def attach(self):
        self.model.register_forward_pre_hook(self.transformer_pre, with_kwargs=True)
        self.model.register_forward_hook(self.transformer_post, with_kwargs=True)
        for attr in ("transformer_blocks", "single_transformer_blocks"):
            for index, block in enumerate(getattr(self.model, attr)):
                before = block.forward
                block.register_forward_pre_hook(self.block_pre(f"{attr}.{index}"), with_kwargs=True)
                block.register_forward_hook(self.block_post(f"{attr}.{index}"), with_kwargs=True)
                if block.forward is not before:
                    raise RuntimeError("Observer changed the compiled block forward")


def install(module):
    if module.__name__ == PIPELINE:
        if os.environ.get("KLEIN_PROBE_STAGE_REQUIRED") != "1":
            raise RuntimeError("This bundle is for a separate enabled stage diagnostic only")
        module.Flux2KleinPipeline._PROFILER_TARGETS = list(STAGE_TARGETS)
    elif module.__name__ == MODEL:
        cls = module.Flux2Transformer2DModel
        original = cls.__init__

        @functools.wraps(original)
        def init(self, *args, **kwargs):
            result = original(self, *args, **kwargs)
            record_model(module, self)
            return result

        cls.__init__ = init
    elif module.__name__ == WORKER:
        original = module.DiffusionWorker.init_device

        @functools.wraps(original)
        def init_device(self, *args, **kwargs):
            import torch

            result = original(self, *args, **kwargs)
            properties = torch.cuda.get_device_properties(self.device)
            STATE["worker"] = {
                "ir_priority_resolved_by_native_worker": True,
                "ir_op_priority": serializable(self.vllm_config.kernel_config.ir_op_priority),
                "worker_module_file": module.__file__, "worker_module_sha256": sha256(module.__file__),
                "resolver_name": module._resolve_ir_op_priority.__qualname__,
                "device": str(self.device),
                "gpu_name": properties.name, "gpu_memory_bytes": properties.total_memory,
                "torch_version": torch.__version__, "torch_cuda_version": torch.version.cuda,
                "cudnn_version": torch.backends.cudnn.version(),
                "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
                "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
                "float32_matmul_precision": torch.get_float32_matmul_precision(),
            }
            return result

        module.DiffusionWorker.init_device = init_device
    elif module.__name__ == RUNNER:
        cls = module.DiffusionModelRunner
        original_compile = cls._compile_transformer
        original_load = cls.load_model

        @functools.wraps(original_compile)
        def compile_transformer(self, attr_name):
            result = original_compile(self, attr_name)
            model = getattr(self.pipeline, attr_name, None)
            if model is not None and hasattr(model, "single_transformer_blocks"):
                STATE["compile"] = {"single_block_wrappers": [configured_compile(b) for b in model.single_transformer_blocks],
                                    "double_block_wrappers": [configured_compile(b) for b in model.transformer_blocks],
                                    "granularity": str(self.od_config.diffusion_compile_granularity),
                                    "dynamic": bool(self.od_config.diffusion_compile_dynamic)}
                if os.environ.get("KLEIN_PROBE_CAPTURE_DIR"):
                    if not all(STATE["compile"]["single_block_wrappers"]):
                        raise RuntimeError("Diagnostic requires configured compiled single blocks")
                    ranks = [int(rank) for rank in os.environ["KLEIN_PROBE_CAPTURE_RANKS"].split(",")]
                    if STATE["rank"] in ranks:
                        BoundaryObserver(model).attach()
            return result

        @functools.wraps(original_load)
        def load_model(self, *args, **kwargs):
            result = original_load(self, *args, **kwargs)
            if "blocks" in STATE:
                from vllm_omni.diffusion.profiler import diffusion_pipeline_profiler as native_profiler
                pipeline = self.pipeline
                if (not getattr(pipeline, "enable_diffusion_pipeline_profiler", False)
                        or pipeline._PROFILER_TARGETS != list(STAGE_TARGETS)):
                    raise RuntimeError("Native stage profiler targets were not enabled")
                wrapped = {}
                for target in STAGE_TARGETS:
                    owner, method = target.split(".")
                    fn = getattr(getattr(pipeline, owner), method)
                    code = getattr(fn, "__code__", None)
                    if (not hasattr(fn, "__wrapped__") or code is None
                            or Path(code.co_filename).resolve() != Path(native_profiler.__file__).resolve()):
                        raise RuntimeError(f"Expected native outer profiler wrapper for {target}")
                    wrapped[target] = True
                STATE["stage_profiler"] = {
                    "enabled": True, "targets": list(STAGE_TARGETS), "native_outer_wrappers": wrapped,
                    "profiler_source_sha256": sha256(native_profiler.__file__),
                    "timer": "native synchronize/perf_counter/synchronize, seconds accumulated per request",
                    "configuration_only": True, "compiled_block_forwards_patched_by_probe": False,
                    "output_rank": 0, "aggregation": "replying rank0 only; no across-rank reduction",
                }
                STATE["load_model_complete"] = True
                publish_receipt()
            return result

        cls._compile_transformer = compile_transformer
        cls.load_model = load_model


class Loader(importlib.abc.Loader):
    def __init__(self, delegate):
        self.delegate = delegate

    def create_module(self, spec):
        create = getattr(self.delegate, "create_module", None)
        return create(spec) if create else None

    def exec_module(self, module):
        self.delegate.exec_module(module)
        install(module)

    def __getattr__(self, name):
        return getattr(self.delegate, name)


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname not in (MODEL, WORKER, RUNNER, PIPELINE):
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
        if spec and spec.loader:
            spec.loader = Loader(spec.loader)
        return spec


if os.environ.get("KLEIN_PROBE_DIR"):
    sys.meta_path.insert(0, Finder())
