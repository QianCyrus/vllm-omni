#!/usr/bin/env python3
"""Rehash saved PNGs, enforce repeat controls and report bracketed HTTP timing."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read_image(path):
    from PIL import Image

    with Image.open(path) as image:
        rgb = image.convert("RGB")
        return rgb.size, rgb.tobytes()


def inspect_run(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "metadata.json").read_text())
    if metadata.get("status") != "PASS" or not metadata.get("source_unchanged") or not metadata.get("cleanup_complete"):
        raise ValueError(f"Execution integrity failed: {directory}")
    if not metadata.get("startup_proof_unchanged"):
        raise ValueError("Startup receipts were not qualified")
    client = json.loads((directory / "http/metadata.json").read_text())
    rows = [json.loads(line) for line in (directory / "http/requests.jsonl").read_text().splitlines()]
    samples = {}
    for row in rows:
        if canonical_sha(row["payload"]) != row["payload_sha256"]:
            raise ValueError("Request payload hash mismatch")
        if row["http_status"] != 200 or len(row["images"]) != row["batch"]:
            raise ValueError("Request completion/image count mismatch")
        for index, record in enumerate(row["images"]):
            path = (directory / "http" / record["file"]).resolve()
            if not path.is_relative_to((directory / "http/images").resolve()):
                raise ValueError("Image path escaped evidence directory")
            if hashlib.sha256(path.read_bytes()).hexdigest() != record["saved_png_sha256"]:
                raise ValueError("Saved image file hash mismatch")
            size, pixels = read_image(path)
            if size != (record["width"], record["height"]) or index != record["index"]:
                raise ValueError("Image shape/order mismatch")
            if hashlib.sha256(pixels).hexdigest() != record["pixel_sha256"]:
                raise ValueError("Saved decoded pixels hash mismatch")
        if not row["warmup"] and not row["correctness_only"] and not row["profiled"]:
            samples.setdefault(row["batch"], []).append(row)
    if set(samples) != set(client["batches"]):
        raise ValueError("Missing measured shapes")
    for batch, measured in samples.items():
        if len(measured) != client["repeats_per_batch"]:
            raise ValueError("Wrong measured request count")
        payloads = {row["payload_sha256"] for row in measured}
        if len(payloads) != 1:
            raise ValueError("Payload drift within repeated workload")
        if any(row["scored"] == metadata["diagnostic"] for row in measured):
            raise ValueError("Diagnostic/scored evidence mixed")
        if any(not math.isfinite(row["wall_ms"]) or row["wall_ms"] <= 0 for row in measured):
            raise ValueError("Nonpositive or nonfinite timing")
    return {"directory": directory, "metadata": metadata, "client": client, "samples": samples}


def ordered_hashes(row):
    return tuple(image["pixel_sha256"] for image in row["images"])


def pixel_difference(left, left_run, right, right_run):
    metrics = []
    for a, b in zip(left["images"], right["images"], strict=True):
        if a["pixel_sha256"] == b["pixel_sha256"]:
            metrics.append({"exact": True, "mae_8bit": 0.0, "rmse_8bit": 0.0, "max_abs_8bit": 0, "psnr_db": None})
            continue
        size_a, pixels_a = read_image(left_run["directory"] / "http" / a["file"])
        size_b, pixels_b = read_image(right_run["directory"] / "http" / b["file"])
        if size_a != size_b:
            raise ValueError("Cross-arm image dimensions differ")
        # NumPy is optional: rare pilot mismatches can use a CPU byte loop.
        try:
            import numpy as np
            delta = np.frombuffer(pixels_a, dtype=np.uint8).astype(np.int16) - np.frombuffer(pixels_b, dtype=np.uint8)
            mae = float(np.abs(delta).mean())
            mse = float(np.square(delta.astype(np.float64)).mean())
            maximum = int(np.abs(delta).max())
        except ImportError:
            differences = [abs(a - b) for a, b in zip(pixels_a, pixels_b, strict=True)]
            mae = sum(differences) / len(differences)
            mse = sum(delta * delta for delta in differences) / len(differences)
            maximum = max(differences)
        metrics.append({"exact": False, "mae_8bit": mae, "rmse_8bit": math.sqrt(mse),
                        "max_abs_8bit": maximum, "psnr_db": 10 * math.log10(255**2 / mse)})
    return metrics


def validate(directories, drift_limit=0.03):
    if len(directories) != 3:
        raise ValueError("Exactly three independent processes are required (O/A/O or A/O/A)")
    runs = [inspect_run(directory) for directory in directories]
    order = "".join(run["metadata"]["variant"] for run in runs)
    if order not in ("OAO", "AOA"):
        raise ValueError("Expected O/A/O or A/O/A bracket")
    first, middle, last = runs
    if first["metadata"]["source_sha"] != last["metadata"]["source_sha"]:
        raise ValueError("Return control uses a different source commit")
    common_fields = ("compile_mode", "diagnostic", "parallelism", "dtype", "attention_backend", "cache_backend",
                     "vae_mode", "vae_degree", "model_revision", "model_config_sha256", "versions", "client_sha256")
    for field in common_fields:
        if any(run["metadata"].get(field) != first["metadata"].get(field) for run in runs):
            raise ValueError(f"Unmatched experiment configuration: {field}")
    worker_fields = ("ir_op_priority", "torch_version", "torch_cuda_version", "cudnn_version", "gpu_name",
                     "gpu_memory_bytes", "matmul_allow_tf32", "cudnn_allow_tf32", "float32_matmul_precision")
    def worker_configuration(run):
        return [{key: record["worker"].get(key) for key in worker_fields}
                for record in run["metadata"].get("startup_activation", {}).get("records", [])]
    if any(worker_configuration(run) != worker_configuration(first) for run in runs):
        raise ValueError("Native worker GPU/kernel/precision configuration differs")
    if any(set(run["samples"]) != set(first["samples"]) for run in runs):
        raise ValueError("Cross-arm workload shapes differ")
    report = {"schema_version": 1, "order": order, "scored": not first["metadata"]["diagnostic"],
              "execution_integrity": "PASS", "repeat_control": "PASS", "cross_variant_pixels": "EXACT",
              "status": "PIXEL_EXACT", "scope": "One fixed prompt/seed at B1/B4. Does not replace diverse quality tests.",
              "runs": [{"directory": str(run["directory"]), "source_sha": run["metadata"]["source_sha"]} for run in runs],
              "batches": {}}
    for batch in first["samples"]:
        rows = [run["samples"][batch] for run in runs]
        if len({len(value) for value in rows}) != 1:
            raise ValueError("Unmatched repeat count")
        if len({row["payload_sha256"] for values in rows for row in values}) != 1:
            raise ValueError("Cross-arm payload is different")
        within = [all(ordered_hashes(row) == ordered_hashes(values[0]) for row in values) for values in rows]
        returned = ordered_hashes(rows[0][0]) == ordered_hashes(rows[2][0])
        exact = ordered_hashes(rows[0][0]) == ordered_hashes(rows[1][0])
        timings = [[row["wall_ms"] for row in values] for values in rows]
        means = [statistics.mean(values) for values in timings]
        baseline = (means[0] + means[2]) / 2 if order == "OAO" else means[1]
        candidate = means[1] if order == "OAO" else (means[0] + means[2]) / 2
        drift = abs(means[2] / means[0] - 1)
        item = {"within_process_pixels_exact": within, "return_process_pixels_exact": returned,
                "cross_variant_pixels_exact": exact, "first_request_differences": pixel_difference(rows[0][0], first, rows[1][0], middle),
                "request_count_per_process": len(rows[0]), "segment_mean_ms": means,
                "segment_std_ms": [statistics.stdev(values) if len(values) > 1 else 0 for values in timings],
                "return_drift_fraction": drift, "drift_limit": drift_limit,
                "bracket_baseline_ms": baseline, "bracket_candidate_ms": candidate,
                "bracket_latency_reduction_fraction": 1 - candidate / baseline,
                "statistical_unit": "independent server-process bracket, not 30 independent process replicates",
                "confidence_interval": None, "score_eligible": report["scored"] and all(within) and returned and exact and drift <= drift_limit}
        report["batches"][str(batch)] = item
        if not all(within) or not returned:
            report.update(repeat_control="FAIL", status="UNSTABLE_CONTROL")
        if not exact:
            report["cross_variant_pixels"] = "DIFFERENT"
            if report["status"] == "PIXEL_EXACT":
                report["status"] = "NUMERICAL_REVIEW_REQUIRED"
    report["performance_claim_eligible"] = all(item["score_eligible"] for item in report["batches"].values())
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs=3, type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--drift-limit", type=float, default=0.03)
    args = parser.parse_args()
    report = validate(args.runs, args.drift_limit)
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "scored", "performance_claim_eligible")}))


if __name__ == "__main__":
    main()
