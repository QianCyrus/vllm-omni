"""CPU tests of the exact native profiler source and diagnostic metric parsing."""

import importlib.util
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from bench_tp_service import time_metrics_ms
from summarize_stages import TARGETS, extract_stages

ROOT = Path(__file__).parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class NativeProfilerTests(unittest.TestCase):
    def test_copied_targets_compiled_blocks_and_unchanged_returns(self):
        import torch

        messages, syncs = [], []
        logger = types.SimpleNamespace(info=messages.append, warning=messages.append)
        modules = {"vllm.logger": types.SimpleNamespace(init_logger=lambda _: logger),
                   "vllm_omni.platforms": types.SimpleNamespace(current_omni_platform=types.SimpleNamespace(
                       is_available=lambda: True, synchronize=lambda: syncs.append(True)))}
        with patch.dict(sys.modules, modules):
            profiler = load(ROOT / "native_profiler_reference.py", "test_exact_native_profiler")
        mixin = profiler.DiffusionPipelineProfilerMixin
        original_targets = list(mixin._PROFILER_TARGETS)

        class Block(torch.nn.Module):
            def forward(self, value):
                return value + 1

        class Transformer(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.blocks = torch.nn.ModuleList([Block(), Block()])

            def forward(self, value):
                for block in self.blocks:
                    value = block(value)
                return value

        class Flux2KleinPipeline(mixin):
            def __init__(self):
                self.text_encoder = Block()
                self.transformer = Transformer()
                self.vae = types.SimpleNamespace(decode=lambda value: value * 2)

            def forward(self, value):
                value = self.text_encoder(value)
                for _ in range(4):
                    value = self.transformer(value)
                value = self.vae.decode(value)
                return types.SimpleNamespace(output=value, stage_durations=self.stage_durations)

        with patch.dict(os.environ, {"KLEIN_PROBE_STAGE_REQUIRED": "1"}):
            hook = load(ROOT / "hooks/sitecustomize.py", "test_stage_hook")
            hook.install(types.SimpleNamespace(__name__=hook.PIPELINE, Flux2KleinPipeline=Flux2KleinPipeline))
        self.assertEqual(mixin._PROFILER_TARGETS, original_targets)
        self.assertEqual(Flux2KleinPipeline._PROFILER_TARGETS, list(TARGETS))
        self.assertIsNot(Flux2KleinPipeline._PROFILER_TARGETS, mixin._PROFILER_TARGETS)
        pipe = Flux2KleinPipeline()
        pipe.setup_diffusion_pipeline_profiler(enable_diffusion_pipeline_profiler=True)
        # Match native ordering: outer profiler setup, then regional compile.
        for block in pipe.transformer.blocks:
            block.forward = torch.compile(block.forward, backend="eager", fullgraph=True)
            block(torch.tensor([0.0]))
        compiled = [block.forward for block in pipe.transformer.blocks]
        pipe._stage_durations["stale"] = 100
        for _ in range(2):
            messages.clear()
            syncs.clear()
            result = pipe.forward(torch.tensor([3.0]))
            torch.testing.assert_close(result.output, torch.tensor([24.0]), rtol=0, atol=0)
            self.assertEqual(set(result.stage_durations), {"Flux2KleinPipeline." + target for target in TARGETS})
            self.assertEqual(sum("transformer.forward took" in message for message in messages), 4)
            self.assertEqual(sum("text_encoder.forward took" in message for message in messages), 1)
            self.assertEqual(sum("vae.decode took" in message for message in messages), 1)
            self.assertEqual(len(syncs), 14)
            self.assertTrue(all(block.forward is saved for block, saved in zip(pipe.transformer.blocks, compiled)))
            self.assertTrue(all(value > 0 for value in result.stage_durations.values()))

    def test_source_backed_units_and_no_step_latency_substitution(self):
        raw = {"stage_durations": {"Flux2KleinPipeline." + name: 0.25 for name in TARGETS},
               "stage_metrics": {"0": {"denoise_step_latency_ms": 9999}}}
        row = {"server_response_fields": {"metrics": raw}, "server_time_metrics_ms": time_metrics_ms(raw)}
        self.assertEqual(extract_stages(row), dict.fromkeys(TARGETS, 250.0))
        del raw["stage_durations"]["Flux2KleinPipeline.transformer.forward"]
        with self.assertRaisesRegex(ValueError, "Missing source-backed"):
            extract_stages(row)

    def test_invalid_stage_value_and_normalization_rejected(self):
        raw = {"stage_durations": {"Flux2KleinPipeline." + name: 0.25 for name in TARGETS}}
        row = {"server_response_fields": {"metrics": raw}, "server_time_metrics_ms": time_metrics_ms(raw)}
        row["server_time_metrics_ms"]["stage_durations.Flux2KleinPipeline.transformer.forward_ms"] = 0.25
        with self.assertRaisesRegex(ValueError, "normalization mismatch"):
            extract_stages(row)
        raw["stage_durations"]["Flux2KleinPipeline.text_encoder.forward"] = float("nan")
        with self.assertRaisesRegex(ValueError, "Invalid native"):
            extract_stages(row)


if __name__ == "__main__":
    unittest.main()
