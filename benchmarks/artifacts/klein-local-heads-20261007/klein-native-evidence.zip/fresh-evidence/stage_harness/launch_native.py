#!/usr/bin/env python3
"""Run one frozen native Klein service arm; allocation/submission belongs to PJM."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import signal
import socket
import subprocess
import sys
import time
import traceback
import urllib.request
from pathlib import Path

from bench_tp_service import PROMPT
from bundle_integrity import verify as verify_bundle

MODEL_REVISION = "e7b7dc27f91deacad38e78976d1f2b499d76a294"
SOURCE_FILES = (
    "vllm_omni/diffusion/data.py",
    "vllm_omni/config/omni_config.py",
    "vllm_omni/diffusion/registry.py",
    "vllm_omni/diffusion/models/flux2/flux2_transformer.py",
    "vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py",
    "vllm_omni/diffusion/models/flux2_klein/pipeline_flux2_klein.py",
    "vllm_omni/diffusion/distributed/autoencoders/autoencoder_kl.py",
    "vllm_omni/diffusion/distributed/autoencoders/autoencoder_kl_flux2.py",
    "vllm_omni/diffusion/distributed/autoencoders/distributed_vae_executor.py",
    "vllm_omni/diffusion/distributed/parallel_state.py",
    "vllm_omni/diffusion/model_loader/diffusers_loader.py",
    "vllm_omni/diffusion/worker/diffusion_model_runner.py",
    "vllm_omni/entrypoints/openai/api_server.py",
    "vllm_omni/entrypoints/openai/protocol/images.py",
    "vllm_omni/entrypoints/cli/serve.py",
)


def sha256(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


from source_manifest import verify_source

def stop_group(process, graceful_signal=signal.SIGTERM, grace=35):
    if process is None:
        return {"started": False, "group_alive": False}
    # Descendants can outlive the leader. Always address the session group.
    actions = []
    try:
        os.killpg(process.pid, graceful_signal)
        actions.append(signal.Signals(graceful_signal).name)
    except ProcessLookupError:
        pass
    deadline = time.monotonic() + grace
    alive = True
    while time.monotonic() < deadline:
        process.poll()
        try:
            os.killpg(process.pid, 0)
        except ProcessLookupError:
            alive = False
            break
        time.sleep(0.25)
    if alive:
        try:
            os.killpg(process.pid, signal.SIGKILL)
            actions.append("SIGKILL")
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass
        for _ in range(20):
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                alive = False
                break
            time.sleep(0.25)
    return {
        "started": True,
        "pid": process.pid,
        "returncode": process.poll(),
        "signals": actions,
        "group_alive": alive,
    }


from proof_validation import verify_startup_proofs

def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--cache-root", type=Path, required=True, help="Node-local /tmp parent, never the Lustre artifact directory"
    )
    parser.add_argument("--arm", required=True)
    parser.add_argument("--variant", choices=["O", "A"], required=True)
    parser.add_argument("--boundary-capture", action="store_true")
    parser.add_argument("--boundary-ranks", type=int, nargs="+", default=[0])
    parser.add_argument("--capture-max-bytes", type=int, default=100_000_000_000)
    parser.add_argument("--tensor-parallel-size", type=int, choices=[1, 2, 4, 8], default=4)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 4])
    parser.add_argument("--warmup", type=int, default=3)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--seed", type=int, default=8137)
    parser.add_argument("--prompt", default=PROMPT)
    parser.add_argument("--steps", type=int, default=4)
    parser.add_argument("--port", type=int, default=8091)
    parser.add_argument("--compile-mode", choices=["regional", "eager"], default="regional")
    parser.add_argument("--startup-timeout", type=float, default=720)
    parser.add_argument("--request-timeout", type=float, default=300)
    parser.add_argument("--run-timeout", type=float, default=1500)
    parser.add_argument("--skip-b1-check", action="store_true")
    parser.add_argument("--quality-cases", type=int, choices=[0, 1, 2], default=0)
    parser.add_argument("--quality-corpus", type=Path)
    parser.add_argument("--profile-batches", type=int, nargs="*", default=[])
    parser.add_argument("--profile-dir", type=Path)
    parser.add_argument("--profile-timeout", type=float, default=180)
    parser.add_argument("--capture-arm-file", type=Path)
    parser.add_argument(
        "--stage-metrics", action="store_true", help="Enable synchronizing pipeline diagnostics; never score this run"
    )
    parser.add_argument("--diagnostic", action="store_true")
    parser.add_argument("--diagnostic-hook-dir", type=Path)
    parser.add_argument(
        "--startup-hook-dir", type=Path, default=Path(__file__).parent / "hooks", help="Constructor-only activation proof; allowed in scored runs"
    )
    parser.add_argument(
        "--check", action="store_true", help="Validate files and print commands; do not start/import the server"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    bundle_root = Path(__file__).resolve().parent
    bundle_before = verify_bundle(bundle_root)
    if (not args.diagnostic or not args.stage_metrics or args.compile_mode != "regional"
            or args.boundary_capture or args.profile_batches or args.profile_dir or args.capture_arm_file
            or args.quality_corpus or args.quality_cases or args.diagnostic_hook_dir):
        raise ValueError("Stage bundle requires --diagnostic --stage-metrics --compile-mode regional only")
    if args.batches != [1, 4] or args.warmup != 3 or args.repeats != 5 or args.steps != 4:
        raise ValueError("Stage protocol requires B1/B4, 3 warmups, 5 samples and 4 steps")
    args.source_root = args.source_root.resolve()
    args.model = args.model.resolve()
    args.output = args.output.resolve()
    args.source_manifest = args.source_manifest.resolve()
    args.cache_root = args.cache_root.resolve()
    if not args.cache_root.is_relative_to(Path("/tmp").resolve()):
        raise ValueError("--cache-root must be under node-local /tmp")
    if os.environ.get("VLLM_OMNI_KLEIN_LOCAL_TP") is not None:
        raise ValueError("Legacy optimization selectors are forbidden; use independent frozen source exports")
    optimization_environment = {}
    args.startup_hook_dir = args.startup_hook_dir.resolve()
    if not (args.startup_hook_dir / "sitecustomize.py").is_file():
        raise ValueError("Startup hook directory must contain sitecustomize.py")
    if args.diagnostic_hook_dir:
        raise ValueError("External hooks are not supported; use the frozen --boundary-capture observer")
    if args.boundary_capture and not args.diagnostic:
        raise ValueError("Boundary hashes synchronize GPUs and require --diagnostic")
    if args.boundary_capture and args.compile_mode != "regional":
        raise ValueError("Boundary observer is installed after regional compile; eager capture is not supported")
    if args.boundary_capture:
        args.capture_arm_file = args.output / "capture_marker.json"
    if any(rank < 0 or rank >= args.tensor_parallel_size for rank in args.boundary_ranks):
        raise ValueError("Boundary rank is outside TP world")
    if (
        not args.batches
        or len(set(args.batches)) != len(args.batches)
        or any(batch < 1 or batch > 10 for batch in args.batches)
    ):
        raise ValueError("Use unique Images API batch sizes 1..10")
    if args.warmup < 0 or args.repeats < 1 or args.steps < 1:
        raise ValueError("Invalid warmup/repeats/steps")
    if min(args.startup_timeout, args.request_timeout, args.run_timeout, args.profile_timeout) <= 0:
        raise ValueError("Timeouts must be positive")
    if not 1 <= args.port <= 65535:
        raise ValueError("Invalid TCP port")
    before = verify_source(args.source_root, args.source_sha, args.source_manifest)
    native_profiler_sha = before["vllm_omni/diffusion/profiler/diffusion_pipeline_profiler.py"]
    if native_profiler_sha != sha256(bundle_root / "native_profiler_reference.py"):
        raise ValueError("Tested native profiler source differs from the runtime source")
    manifest = json.loads(args.source_manifest.read_text())
    manifest_hash = sha256(args.source_manifest)
    if json.loads((args.model / "model_index.json").read_text()).get("_class_name") != "Flux2KleinPipeline":
        raise ValueError("Model snapshot is not native Flux2KleinPipeline")
    if (args.profile_batches or args.profile_dir or args.stage_metrics) and not args.diagnostic:
        raise ValueError("Profiler/stage instrumentation requires --diagnostic")
    if bool(args.profile_batches) != bool(args.profile_dir):
        raise ValueError("--profile-batches and --profile-dir must be used together")
    if not set(args.profile_batches).issubset(args.batches):
        raise ValueError("Profile batches must receive workload warmup")
    if args.diagnostic_hook_dir and not (args.diagnostic_hook_dir.resolve() / "sitecustomize.py").is_file():
        raise ValueError("Diagnostic hook directory must contain sitecustomize.py")
    transformer_config = json.loads((args.model / "transformer/config.json").read_text())
    if transformer_config.get("num_attention_heads") != 24 or transformer_config.get("num_single_layers") != 20:
        raise ValueError("Unexpected model head/block configuration; require Klein-4B 24 heads / 20 single blocks")
    mode, degree = "tile", 1
    command = [
        sys.executable,
        "-m",
        "vllm_omni.entrypoints.cli.main",
        "serve",
        str(args.model),
        "--omni",
        "--host",
        "127.0.0.1",
        "--port",
        str(args.port),
        "--served-model-name",
        "klein-local-heads-bench",
        "--model-class-name",
        "Flux2KleinPipeline",
        "--num-gpus",
        str(args.tensor_parallel_size),
        "--dtype",
        "bfloat16",
        "--tensor-parallel-size",
        str(args.tensor_parallel_size),
        "--data-parallel-size",
        "1",
        "--pipeline-parallel-size",
        "1",
        "--ulysses-degree",
        "1",
        "--ring-degree",
        "1",
        "--allgather-degree",
        "1",
        "--cfg-parallel-size",
        "1",
        "--vae-parallel-mode",
        mode,
        "--vae-patch-parallel-size",
        str(degree),
        "--vae-fast-path",
        "off",
        "--cache-backend",
        "none",
        "--diffusion-attention-backend",
        "TORCH_SDPA",
        "--log-stats",
    ]
    if args.compile_mode == "eager":
        command.append("--enforce-eager")
    else:
        command.extend(["--diffusion-compile-granularity", "regional", "--diffusion-compile-dynamic"])
    if args.stage_metrics:
        command.append("--enable-diffusion-pipeline-profiler")
    if args.profile_dir:
        profile_config = {
            "profiler": "torch",
            "torch_profiler_dir": str(args.profile_dir.resolve()),
            "torch_profiler_record_shapes": True,
            "torch_profiler_with_stack": False,
            "torch_profiler_with_memory": False,
            "torch_profiler_use_gzip": True,
        }
        command.extend(["--profiler-config", json.dumps(profile_config, separators=(",", ":"))])
    client_path = Path(__file__).with_name("bench_tp_service.py")
    client_command = [
        sys.executable,
        str(client_path),
        "--base-url",
        f"http://127.0.0.1:{args.port}",
        "--output",
        str(args.output / "http"),
        "--arm",
        args.arm,
        "--source-sha",
        args.source_sha,
        "--batches",
        *map(str, args.batches),
        "--warmup",
        str(args.warmup),
        "--repeats",
        str(args.repeats),
        "--seed",
        str(args.seed),
        "--prompt",
        args.prompt,
        "--steps",
        str(args.steps),
        "--request-timeout",
        str(args.request_timeout),
        "--quality-cases",
        str(args.quality_cases),
    ]
    if args.capture_arm_file:
        if not args.diagnostic or not args.boundary_capture or args.profile_batches:
            raise ValueError("Input capture requires --boundary-capture --diagnostic and no torch profiler")
        if args.capture_arm_file.exists():
            raise ValueError("Capture marker already exists")
        client_command.extend(["--capture-arm-file", str(args.capture_arm_file.resolve())])
    if args.profile_batches:
        client_command.extend(
            ["--profile-batches", *map(str, args.profile_batches), "--profile-timeout", str(args.profile_timeout)]
        )
    if args.quality_corpus:
        if not args.quality_corpus.is_file():
            raise ValueError("Quality corpus does not exist")
        client_command.extend(["--quality-corpus", str(args.quality_corpus.resolve())])
    if args.skip_b1_check:
        client_command.append("--skip-b1-check")
    if args.diagnostic:
        client_command.append("--diagnostic")
    if args.check:
        print(
            json.dumps(
                {
                    "static_check": "PASS",
                    "optimization_environment": optimization_environment,
                    "startup_hook_dir": str(args.startup_hook_dir) if args.startup_hook_dir else None,
                    "source_sha256": before,
                    "server_command": command,
                    "client_command": client_command,
                },
                indent=2,
            )
        )
        return
    if "PJM_JOBID" not in os.environ:
        raise RuntimeError("Server execution requires an allocated PJM job; --check is available without one")
    with socket.socket() as probe:
        # A closed server can leave accepted connections in TIME_WAIT.
        # Match the HTTP server's reuse policy; a live listener still fails.
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(("127.0.0.1", args.port))
    args.output.mkdir(parents=True, exist_ok=False)
    if args.profile_dir:
        # Refuse stale traces. Children may be created by profiler workers.
        args.profile_dir.resolve().mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    # Exact source only: discard stale PYTHONPATH and earlier experiment hooks.
    paths = [str(args.source_root)]
    if args.diagnostic_hook_dir:
        paths.insert(0, str(args.diagnostic_hook_dir.resolve()))
    if args.startup_hook_dir:
        paths.insert(0, str(args.startup_hook_dir))
    env["PYTHONPATH"] = os.pathsep.join(paths)
    for key in (
        "KV_MODEL_DIAGNOSTIC_DIR",
        "KV_MODEL_ARM",
        "KV_MODEL_RUN_ID",
        "VLLM_TORCH_PROFILER_DIR",
        "BATCHING_DIAGNOSTIC_DIR",
        "BATCHING_OBSERVER_DIR",
    ):
        env.pop(key, None)
    for key in tuple(env):
        if key.startswith(("KLEIN_TP_", "TP_CAPTURE_", "OMNI_TP_", "KLEIN_PROBE_")):
            env.pop(key)
    capture_environment = {}
    startup_hook_sha256 = {
        str(path.relative_to(args.startup_hook_dir)): sha256(path)
        for path in sorted(args.startup_hook_dir.rglob("*.py"))
    }
    env.update(
        KLEIN_PROBE_STAGE_REQUIRED="1",
        KLEIN_PROBE_DIR=str(args.output / "startup_activation"),
        KLEIN_PROBE_SOURCE_ROOT=str(args.source_root),
        KLEIN_PROBE_SOURCE_SHA=args.source_sha,
        KLEIN_PROBE_VARIANT=args.variant,
        KLEIN_PROBE_TP=str(args.tensor_parallel_size),
        KLEIN_PROBE_COMPILE_MODE=args.compile_mode,
        KLEIN_PROBE_MODULE_SHA=before["vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py"],
    )
    if args.boundary_capture:
        env.update(
            KLEIN_PROBE_CAPTURE_DIR=str(args.output / "boundaries"),
            KLEIN_PROBE_MARKER=str(args.capture_arm_file),
            KLEIN_PROBE_CAPTURE_RANKS=",".join(map(str, args.boundary_ranks)),
            KLEIN_PROBE_CAPTURE_MAX_BYTES=str(args.capture_max_bytes),
        )
        capture_environment = {key: value for key, value in env.items() if key.startswith("KLEIN_PROBE_CAPTURE")}
    env.update(
        PYTHONNOUSERSITE="1",
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONUNBUFFERED="1",
        OMP_NUM_THREADS="1",
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        OMNI_DIFFUSION_PROMPT_EMBED_CACHE="0",
        VLLM_WORKER_MULTIPROC_METHOD="spawn",
    )
    arm_cache = args.cache_root / args.output.name
    arm_cache.mkdir(parents=True, exist_ok=False)
    for name, subdir in (
        ("XDG_CACHE_HOME", "xdg"),
        ("FLASHINFER_WORKSPACE_BASE", "flashinfer"),
        ("TRITON_CACHE_DIR", "triton"),
        ("TORCHINDUCTOR_CACHE_DIR", "inductor"),
        ("VLLM_CACHE_ROOT", "vllm"),
        ("CUDA_CACHE_PATH", "cuda"),
        ("SPEAKER_SAMPLES_DIR", "speakers"),
    ):
        path = arm_cache / subdir
        path.mkdir(parents=True, exist_ok=True)
        env[name] = str(path)
    metadata = {
        "arm": args.arm,
        "stage_bundle_sha256": bundle_before,
        "stage_bundle_manifest_sha256": sha256(bundle_root / "BUNDLE_MANIFEST.json"),
        "variant": args.variant,
        "source_sha": args.source_sha,
        "source_sha256": before,
        "source_base_sha": manifest.get("base_sha"),
        "source_patch_sha256": manifest.get("patch_sha256"),
        "source_manifest_sha256": manifest_hash,
        "model_revision": MODEL_REVISION,
        "model_revision_validation": "Pinned expected snapshot; config hashes verified below, weight shards are not rehashed by this launcher",
        "model_path": str(args.model),
        "model_config_sha256": {
            name: sha256(args.model / name)
            for name in ("model_index.json", "vae/config.json", "transformer/config.json", "text_encoder/config.json")
        },
        "server_command": command,
        "client_command": client_command,
        "launcher_sha256": sha256(Path(__file__)),
        "client_sha256": sha256(client_path),
        "compile_mode": args.compile_mode,
        "diagnostic": args.diagnostic,
        "profile_dir": str(args.profile_dir.resolve()) if args.profile_dir else None,
        "stage_metrics_enabled": args.stage_metrics,
        "startup_hook_sha256": startup_hook_sha256,
        "startup_activation": None,
        "diagnostic_hook_sha256": {
            str(path.relative_to(args.diagnostic_hook_dir.resolve())): sha256(path)
            for path in sorted(args.diagnostic_hook_dir.resolve().rglob("*.py"))
        }
        if args.diagnostic_hook_dir
        else {},
        "capture_environment": capture_environment,
        "optimization_environment": optimization_environment,
        "scored": not args.diagnostic,
        "parallelism": {"tp": args.tensor_parallel_size, "sp": 1, "dp": 1, "pp": 1, "cfg": 1},
        "dtype": "bfloat16",
        "attention_backend": "TORCH_SDPA",
        "cache_backend": "none",
        "vae_mode": mode,
        "vae_degree": degree,
        "pjm_job_id": os.environ.get("PJM_JOBID"),
        "cache_directories": {
            name: env[name]
            for name in ("XDG_CACHE_HOME", "FLASHINFER_WORKSPACE_BASE", "TRITON_CACHE_DIR", "TORCHINDUCTOR_CACHE_DIR")
        },
        "native_image_dummy": "unchanged; all arms use source pipeline default",
        "versions": {},
        "started_unix_s": time.time(),
        "status": "STARTING",
    }
    for package in ("torch", "vllm", "vllm-omni", "diffusers", "transformers", "Pillow"):
        try:
            metadata["versions"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            metadata["versions"][package] = "not installed as a distribution"
    write_json(args.output / "metadata.json", metadata)
    server = client = None
    success = False
    run_start = time.monotonic()

    def interrupted(signum, frame):
        raise InterruptedError(f"Received signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with (
            (args.output / "server.log").open("wb") as server_log,
            (args.output / "client.log").open("wb") as client_log,
        ):
            server = subprocess.Popen(
                command,
                cwd=args.source_root,
                env=env,
                stdout=server_log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            metadata["server_pid"] = server.pid
            while True:
                if server.poll() is not None:
                    raise RuntimeError(f"Server exited before readiness: {server.returncode}")
                if time.monotonic() - run_start > min(args.startup_timeout, args.run_timeout):
                    raise TimeoutError("Server readiness timed out; see server.log")
                try:
                    with opener.open(f"http://127.0.0.1:{args.port}/health", timeout=2) as response:
                        if response.status == 200:
                            break
                except (OSError, urllib.error.URLError):
                    pass
                time.sleep(1)
            metadata["health_ready_ms"] = (time.monotonic() - run_start) * 1000
            if args.startup_hook_dir:
                proof_dir = args.output / "startup_activation"
                while len(list(proof_dir.glob("rank*.json"))) < args.tensor_parallel_size:
                    if server.poll() is not None:
                        raise RuntimeError("Server exited before completing startup activation proof")
                    if time.monotonic() - run_start > min(args.startup_timeout, args.run_timeout):
                        raise TimeoutError("Startup activation proof timed out before client launch")
                    time.sleep(0.25)
                metadata["startup_activation"] = verify_startup_proofs(
                    args.output / "startup_activation",
                    args.source_root,
                    args.source_sha,
                    before["vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py"],
                    args.variant,
                    startup_hook_sha256["sitecustomize.py"],
                    args.tensor_parallel_size, args.compile_mode,
                )
                metadata["startup_activation"]["verified_before_client_unix_s"] = time.time()
            metadata["status"] = "RUNNING"
            write_json(args.output / "metadata.json", metadata)
            client_env = env.copy()
            if args.startup_hook_dir:
                client_env["PYTHONPATH"] = str(args.source_root)
                for key in tuple(client_env):
                    if key.startswith("KLEIN_PROBE_"):
                        client_env.pop(key)
            client = subprocess.Popen(
                client_command,
                cwd=args.output,
                env=client_env,
                stdout=client_log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            while client.poll() is None:
                if server.poll() is not None:
                    raise RuntimeError(f"Server exited during benchmark: {server.returncode}")
                if time.monotonic() - run_start > args.run_timeout:
                    raise TimeoutError("Whole service-arm budget expired")
                time.sleep(1)
            if client.returncode != 0:
                raise RuntimeError(f"HTTP client failed: {client.returncode}; see client.log")
            for record in metadata["startup_activation"]["records"]:
                stage = record.get("stage_profiler", {})
                if (stage.get("enabled") is not True or stage.get("targets") !=
                        ["text_encoder.forward", "transformer.forward", "vae.decode"]
                        or stage.get("profiler_source_sha256") != native_profiler_sha):
                    raise RuntimeError("Stage startup proof is incomplete")
            success = True
    except BaseException as exc:
        write_json(
            args.output / "failure.json",
            {
                "type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            },
        )
        raise
    finally:
        # Ignore a second termination signal only while cleaning up our own
        # tracked process groups; PJM's outer hard deadline remains effective.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        client_cleanup = stop_group(client, grace=5)
        if args.capture_arm_file:
            args.capture_arm_file.unlink(missing_ok=True)
        server_cleanup = stop_group(server, graceful_signal=signal.SIGINT)
        try:
            source_unchanged = (
                verify_source(args.source_root, args.source_sha, args.source_manifest) == before
                and sha256(args.source_manifest) == manifest_hash
            )
        except Exception as exc:
            source_unchanged = False
            metadata["source_verification_error"] = str(exc)
        startup_proof_unchanged = True
        if args.startup_hook_dir:
            try:
                current_hook_hashes = {
                    str(path.relative_to(args.startup_hook_dir)): sha256(path)
                    for path in sorted(args.startup_hook_dir.rglob("*.py"))
                }
                final_proof = verify_startup_proofs(
                    args.output / "startup_activation",
                    args.source_root,
                    args.source_sha,
                    before["vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py"],
                    args.variant,
                    startup_hook_sha256["sitecustomize.py"],
                    args.tensor_parallel_size, args.compile_mode,
                )
                startup_proof_unchanged = (
                    current_hook_hashes == startup_hook_sha256
                    and metadata.get("startup_activation") is not None
                    and final_proof["files_sha256"] == metadata["startup_activation"]["files_sha256"]
                )
            except Exception as exc:
                startup_proof_unchanged = False
                metadata["startup_verification_error"] = str(exc)
        try:
            bundle_unchanged = verify_bundle(bundle_root) == bundle_before
        except Exception as exc:
            bundle_unchanged = False
            metadata["bundle_verification_error"] = str(exc)
        metadata["stage_bundle_unchanged"] = bundle_unchanged
        metadata["startup_proof_unchanged"] = startup_proof_unchanged
        cleanup_complete = not client_cleanup["group_alive"] and not server_cleanup["group_alive"]
        metadata.update(
            status="PASS" if success and source_unchanged and cleanup_complete and startup_proof_unchanged and bundle_unchanged else "FAIL",
            ended_unix_s=time.time(),
            source_unchanged=source_unchanged,
            cleanup_complete=cleanup_complete,
            client_cleanup=client_cleanup,
            server_cleanup=server_cleanup,
        )
        write_json(args.output / "metadata.json", metadata)
        write_json(
            args.output / "validation.json",
            {key: metadata[key] for key in ("status", "scored", "diagnostic", "source_unchanged", "cleanup_complete")},
        )
    if metadata["status"] != "PASS":
        raise RuntimeError("Source/cleanup qualification failed")
    print("MODEL_SERVICE_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
