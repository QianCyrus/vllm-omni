# Native stage diagnostic (2026-10-07)

This independent diagnostic does not change the frozen native timing bundle or any older qualification. It runs the same native Klein-4B Images API inputs at TP4/SP1, BF16, regional compile, 1024x1024, guidance 1, four steps, seed 8137, B1/B4. Each of the O and A services receives three warmups and five measured diagnostic requests per batch: 16 requests and 40 retained images per service.

The startup hook sets a new `_PROFILER_TARGETS` list on `Flux2KleinPipeline` only: `text_encoder.forward`, `transformer.forward`, `vae.decode`. The existing pipeline constructor installs its built-in synchronizing profiler before the runner performs normal regional compilation. The probe does not replace compiled block forwards. The copied `native_profiler_reference.py` must hash-match each frozen source export and is used by the CPU test. All four workers provide native-wrapper and configured-compile receipts.

`transformer.forward` measures the transformer execution itself, accumulated over the four calls in this workload. It excludes the scheduler, latent preparation, text encoder and VAE. The timer synchronizes the platform before and after each outer method and uses `perf_counter`; native seconds are converted to milliseconds. The API returns the replying rank 0's durations; no maximum or average across ranks is computed. Four calls follow from four steps and guidance 1 and are verified in the wrapper CPU test; this is not a runtime kernel-count proof. `denoise_step_latency_ms` is never used for DiT timing. The outer pipeline duration may be absent because the response copies stage durations before the pipeline's final profiler callback.

Synchronization and logging can change execution, so the five samples are diagnostics, not native service performance scores. There is one process per variant and no independent process replication or confidence interval. Rehash every saved PNG, report within/cross-variant differences including warmups, and compare against each available fresh uninstrumented run of the same variant. A mismatch does not establish its cause. Never silently assume the profiler is observationally neutral.

Source implementation: `vllm_omni/diffusion/profiler/diffusion_pipeline_profiler.py`; pipeline setup and four-step control flow in `vllm_omni/diffusion/models/flux2_klein/pipeline_flux2_klein.py`; regional compilation in `vllm_omni/diffusion/worker/diffusion_model_runner.py`; rank 0 reply routing in `vllm_omni/diffusion/executor/multiproc_executor.py` and `vllm_omni/diffusion/worker/diffusion_worker.py`.

## Run and inspect

Freeze once before packaging; keep all resulting bundle files unchanged. The launcher verifies the full bundle before and after each service.

```sh
python bundle_integrity.py --freeze
python -m unittest -v test_stage_harness.py
python launch_native.py --source-root BASE --source-sha 5f95115e703ffe51e03e40ae23c78ff841c3335e --source-manifest BASE_MANIFEST --model MODEL --output OUTPUT/01-O --cache-root /tmp/klein-stage --arm 01-O --variant O --tensor-parallel-size 4 --compile-mode regional --batches 1 4 --warmup 3 --repeats 5 --steps 4 --diagnostic --stage-metrics
python launch_native.py --source-root CANDIDATE --source-sha 39a06eac411a377e0bc1eb13bdbceb10c9783bf6 --source-manifest CANDIDATE_MANIFEST --model MODEL --output OUTPUT/02-A --cache-root /tmp/klein-stage --arm 02-A --variant A --tensor-parallel-size 4 --compile-mode regional --batches 1 4 --warmup 3 --repeats 5 --steps 4 --diagnostic --stage-metrics
python summarize_stages.py --baseline OUTPUT/01-O --candidate OUTPUT/02-A --native NATIVE/01-O NATIVE/02-A NATIVE/03-O --output OUTPUT/stage-summary.json
```

`--check` performs launcher validation and prints commands without starting a server. CPU tests check copied target isolation, unchanged output, four calls, unchanged compiled block method objects, native record reset, and unit conversion. CPU tests do not establish GPU numerical equivalence. The parser fails if genuine transformer metrics are missing, checks receipts and full PNG integrity, and always marks the diagnostic unscored.
