# Fresh native performance run

The five execution scripts are byte-identical copies of the previously validated 20261006 harness: launch_native.py, bench_tp_service.py, source_manifest.py, proof_validation.py and hooks/sitecustomize.py. No old coordinator or quality receipt is used.

Launch each O/A/O arm directly with launch_native.py, --batches 1 4 --warmup 5 --repeats 30 --steps 4 --compile-mode regional. Do not add --diagnostic, --stage-metrics, --boundary-capture or profiling flags to timed runs. The default hook only records worker, constructor and compilation configuration during startup; it installs no forward hooks in this mode. Every image from the 70 requests / 175 images per arm is retained.

The parent job coordinator binds its new prospective protocol, both source manifests, the model snapshot, this frozen bundle and an overall budget. The separate fresh comparator decides numerical and timing eligibility per batch using this run's controls. Old failed qualifications are unchanged and cannot qualify this run. Native HTTP timings are not DiT timings.

Use --check for a no-server static validation. Verify the package with python bundle_integrity.py before launch and after completion. The launcher independently verifies production source and its startup-hook hashes. This unchanged launcher does not read BUNDLE_MANIFEST.json itself: whole-bundle verification is a responsibility of the new job coordinator.

Phase attribution must run separately. Klein's default built-in profiler targets do not include transformer.forward, so simply adding --stage-metrics does not produce a DiT measurement. A separately frozen diagnostic setup is required.
