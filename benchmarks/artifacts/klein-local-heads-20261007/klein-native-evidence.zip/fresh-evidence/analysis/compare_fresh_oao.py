#!/usr/bin/env python3
"""Independently check fresh O/A/O artifacts on CPU; never rewrite run evidence."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
import statistics
import sys
from pathlib import Path

MODULE = "vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py"
WORKER = "vllm_omni/diffusion/worker/diffusion_worker.py"
COMMON = (
    "model_revision",
    "model_path",
    "model_config_sha256",
    "server_command",
    "launcher_sha256",
    "client_sha256",
    "compile_mode",
    "diagnostic",
    "profile_dir",
    "stage_metrics_enabled",
    "startup_hook_sha256",
    "diagnostic_hook_sha256",
    "capture_environment",
    "optimization_environment",
    "parallelism",
    "dtype",
    "attention_backend",
    "cache_backend",
    "vae_mode",
    "vae_degree",
    "versions",
    "native_image_dummy",
    "pjm_job_id",
)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def finite_number(value, positive=False):
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and (value > 0 if positive else value >= 0)
    )


def summarize(values, positive=True):
    """Do not silently remove non-finite samples or outliers."""
    valid = bool(values) and all(finite_number(v, positive=positive) for v in values)
    output = {
        "count": len(values),
        "finite_positive" if positive else "finite_nonnegative": valid,
        "samples_ms": [v if finite_number(v, positive=positive) else None for v in values],
    }
    if not valid:
        output["invalid_samples"] = [
            {"index": i, "value": repr(v)} for i, v in enumerate(values) if not finite_number(v, positive=positive)
        ]
        output.update(mean_ms=None, sample_sd_ms=None, median_ms=None, p95_ms=None)
        return output
    ordered = sorted(values)
    index = (len(ordered) - 1) * 0.95
    lo, hi = math.floor(index), math.ceil(index)
    output.update(
        mean_ms=statistics.mean(values),
        sample_sd_ms=statistics.stdev(values) if len(values) > 1 else 0.0,
        median_ms=statistics.median(values),
        p95_ms=ordered[lo] + (ordered[hi] - ordered[lo]) * (index - lo),
    )
    return output


def expected_payload(protocol, batch):
    return {
        "model": "klein-local-heads-bench",
        "prompt": protocol["prompt"],
        "n": batch,
        "size": f"{protocol['width']}x{protocol['height']}",
        "num_inference_steps": protocol["steps"],
        "guidance_scale": protocol["guidance_scale"],
        "seed": protocol["seed"],
        "generator_device": protocol["generator_device"],
        "response_format": "b64_json",
        "output_format": "png",
        "output_compression": 100,
        "return_stage_metrics": True,
    }


def check_images(arm_root, row, protocol, errors):
    """Rehash every original PNG and its decoded RGB bytes, including warmups."""
    from PIL import Image

    images = row.get("images", [])
    if len(images) != row["batch"]:
        errors.append("wrong image count")
    hashes = []
    for index, record in enumerate(images):
        try:
            file = (arm_root / "http" / record["file"]).resolve()
            if not file.is_relative_to((arm_root / "http").resolve()):
                raise ValueError("image path escapes HTTP artifact directory")
            if record.get("index") != index:
                raise ValueError("image index/order mismatch")
            if sha256(file) != record.get("saved_png_sha256"):
                raise ValueError("PNG file hash mismatch")
            with Image.open(file) as image:
                if image.format != "PNG":
                    raise ValueError("saved image is not PNG")
                rgb = image.convert("RGB")
                if rgb.size != (protocol["width"], protocol["height"]):
                    raise ValueError("wrong decoded image dimensions")
                if (record.get("width"), record.get("height")) != rgb.size or record.get("mode") != "RGB":
                    raise ValueError("image dimension/mode record mismatch")
                actual = hashlib.sha256(rgb.tobytes()).hexdigest()
            if actual != record.get("pixel_sha256"):
                raise ValueError("decoded RGB hash mismatch")
            hashes.append(actual)
        except (KeyError, ValueError, OSError) as exc:
            errors.append(f"image {index}: {exc}")
            hashes.append(None)
    return hashes


def load_arm(path, variant, protocol, manifest_path, harness, verify_proofs):
    errors, rows = [], []
    meta, client, receipts = {}, {}, []
    try:
        meta = read_json(path / "metadata.json")
        client = read_json(path / "http/metadata.json")
        validation = read_json(path / "validation.json")
        http_validation = read_json(path / "http/validation.json")
        manifest = read_json(manifest_path)
        expected_sha = protocol["source_shas"][variant]
        for key in COMMON:
            if key not in meta:
                errors.append(f"missing runtime/config field {key}")
        for name, actual, expected in [
            ("source SHA", meta.get("source_sha"), expected_sha),
            ("source variant", meta.get("variant"), variant),
            ("manifest source SHA", manifest.get("head_sha"), expected_sha),
            ("manifest schema", manifest.get("schema_version"), 2),
            ("source file hashes", meta.get("source_sha256"), manifest.get("files")),
            ("manifest hash", meta.get("source_manifest_sha256"), sha256(manifest_path)),
            ("client source SHA", client.get("source_sha"), expected_sha),
            ("client arm", client.get("arm"), meta.get("arm")),
            ("launcher hash", meta.get("launcher_sha256"), sha256(harness / "launch_native.py")),
            ("client hash", meta.get("client_sha256"), sha256(harness / "bench_tp_service.py")),
            ("client metadata hash", client.get("client_sha256"), meta.get("client_sha256")),
            (
                "startup hook hash",
                meta.get("startup_hook_sha256", {}).get("sitecustomize.py"),
                sha256(harness / "hooks/sitecustomize.py"),
            ),
        ]:
            if actual != expected:
                errors.append(f"{name} mismatch")
        for key in ("model_revision", "parallelism", "dtype", "attention_backend", "compile_mode"):
            if meta.get(key) != protocol[key]:
                errors.append(f"wrong {key}")
        required = {
            "diagnostic": False,
            "stage_metrics_enabled": False,
            "scored": True,
            "profile_dir": None,
            "capture_environment": {},
            "diagnostic_hook_sha256": {},
            "optimization_environment": {},
            "source_unchanged": True,
            "cleanup_complete": True,
            "startup_proof_unchanged": True,
            "status": "PASS",
        }
        for key, expected in required.items():
            if meta.get(key) != expected:
                errors.append(f"metadata {key} is not {expected!r}")
        for name, validation_record in (("launcher", validation), ("client", http_validation)):
            if validation_record.get("status") != "PASS" or validation_record.get("scored") is not True:
                errors.append(f"{name} completion/scored receipt failed")
        for key, expected in {
            "batches": protocol["batches"],
            "warmup_per_batch": protocol["warmup_per_batch"],
            "repeats_per_batch": protocol["measured_requests_per_batch"],
            "concurrency": 1,
            "diagnostic": False,
            "profile_batches": [],
            "capture_arm_file": None,
        }.items():
            if client.get(key) != expected:
                errors.append(f"client {key} mismatch")
        first = read_json(path / "startup_activation/rank0.json")
        # The launcher already verified this remote source root. Here we recheck
        # its recorded source hashes, receipt hashes, paths and expected modules.
        remote_source = Path(first["module_file"]).parents[len(Path(MODULE).parts) - 1]
        proof = verify_proofs(
            path / "startup_activation",
            remote_source,
            expected_sha,
            manifest["files"][MODULE],
            variant,
            meta["startup_hook_sha256"]["sitecustomize.py"],
            protocol["parallelism"]["tp"],
            protocol["compile_mode"],
        )
        if proof["files_sha256"] != meta.get("startup_activation", {}).get("files_sha256"):
            errors.append("startup receipt hashes changed after launch verification")
        receipts = proof["records"]
        for record in receipts:
            worker = record["worker"]
            if worker.get("worker_module_sha256") != manifest["files"][WORKER]:
                errors.append(f"rank {record['rank']} worker source hash mismatch")
            if worker.get("gpu_name") != "NVIDIA A100-SXM4-40GB":
                errors.append(f"rank {record['rank']} unexpected GPU")
            if not str(record["module_file"]).endswith("/" + MODULE):
                errors.append("unexpected model module path")
            if record.get("compile", {}).get("dynamic") is not True:
                errors.append("regional dynamic compile mismatch")
            if record.get("compile", {}).get("double_block_wrappers") != [True] * 5:
                errors.append("double-block regional compile mismatch")
        rows = [json.loads(line) for line in (path / "http/requests.jsonl").read_text().splitlines() if line]
        if http_validation.get("requests_completed") != len(rows):
            errors.append("request count differs from completion receipt")
    except (KeyError, ValueError, OSError) as exc:
        errors.append(f"incomplete or invalid arm artifacts: {exc}")
        # Still read all available requests so another batch cannot disappear.
        try:
            rows = [json.loads(line) for line in (path / "http/requests.jsonl").read_text().splitlines() if line]
        except (ValueError, OSError) as read_error:
            errors.append(f"cannot read requests: {read_error}")
    return {"path": str(path), "metadata": meta, "client": client, "receipts": receipts, "rows": rows, "errors": errors}


def compare_batch(arms, batch, protocol, common_errors):
    measured_by_arm, all_hashes, measured_hashes, labels_by_arm = [], [], [], []
    arm_results, batch_errors, payload_by_arm = [], [], []
    warmup_count = protocol["warmup_per_batch"]
    repeat_count = protocol["measured_requests_per_batch"]
    for i, arm in enumerate(arms):
        selected = [row for row in arm["rows"] if row.get("batch") == batch]
        errors, hashes, measured, measured_pixels, warmups, aux = [], [], [], [], [], []
        timing_errors = []
        expected = expected_payload(protocol, batch)
        for row in selected:
            row_errors = []
            if row.get("arm") != arm["metadata"].get("arm"):
                row_errors.append("request arm mismatch")
            if row.get("payload") != expected or row.get("payload_sha256") != canonical_hash(row.get("payload")):
                row_errors.append("request payload or payload hash mismatch")
            if row.get("http_status") != 200 or row.get("profiled") is not False:
                row_errors.append("HTTP status/profile mode mismatch")
            if not finite_number(row.get("wall_ms"), positive=True):
                timing_errors.append(f"{row.get('label')}: non-finite or non-positive raw latency")
            metrics = row.get("server_time_metrics_ms", {})
            if not all(finite_number(value) for value in metrics.values()):
                timing_errors.append(f"{row.get('label')}: invalid server timing metric")
            pixel_hashes = check_images(Path(arm["path"]), row, protocol, row_errors)
            hashes.append(pixel_hashes)
            if row.get("warmup") is True:
                warmups.append(row)
                if row.get("scored") is not False or row.get("correctness_only") is not False:
                    row_errors.append("warmup scoring mismatch")
            elif row.get("correctness_only") is True:
                aux.append(row)
                if row.get("scored") is not False:
                    row_errors.append("correctness-only request was scored")
            else:
                measured.append(row)
                measured_pixels.append(pixel_hashes)
                if (
                    row.get("warmup") is not False
                    or row.get("correctness_only") is not False
                    or row.get("scored") is not True
                ):
                    row_errors.append("measured scoring flags mismatch")
            errors.extend(f"{row.get('label', 'unlabelled')}: {e}" for e in row_errors)
        if [row.get("label") for row in warmups] != [f"b{batch}-warmup-{n:02}" for n in range(warmup_count)]:
            errors.append("wrong warmup count, order or labels")
        if [row.get("label") for row in measured] != [f"b{batch}-sample-{n:02}" for n in range(repeat_count)]:
            errors.append("wrong measured count, order or labels")
        labels = [row.get("label") for row in selected]
        if len(labels) != len(set(labels)):
            errors.append("duplicate request labels")
        ordinary = [row for row in selected if row not in aux]
        if ordinary != warmups + measured:
            errors.append("warmups do not all precede measured requests")
        within_all = bool(hashes) and all(h == hashes[0] and None not in h and len(h) == batch for h in hashes)
        within_measured = bool(measured_pixels) and all(
            h == measured_pixels[0] and None not in h and len(h) == batch for h in measured_pixels
        )
        measured_by_arm.append([row.get("wall_ms") for row in measured])
        all_hashes.append(hashes)
        measured_hashes.append(measured_pixels)
        labels_by_arm.append(labels)
        payload_by_arm.append([row.get("payload_sha256") for row in selected])
        metric_keys = sorted({key for row in measured for key in row.get("server_time_metrics_ms", {})})
        arm_results.append(
            {
                "arm": arm["metadata"].get("arm"),
                "warmup_requests": len(warmups),
                "measured_requests": len(measured),
                "correctness_only_requests": len(aux),
                "raw_images_verified": sum(len(h) for h in hashes) if not errors else None,
                "within_process_all_recorded_pixels_exact": within_all,
                "within_process_measured_pixels_exact": within_measured,
                "request_labels": labels,
                "ordered_pixel_hashes": hashes,
                "http_wall": summarize(measured_by_arm[-1]),
                "server_metrics_ms": {
                    key: summarize([row.get("server_time_metrics_ms", {}).get(key) for row in measured], positive=False)
                    for key in metric_keys
                },
                "errors": errors,
                "timing_errors": timing_errors,
            }
        )
        batch_errors.extend(f"arm {i}: {e}" for e in errors)
    if not (labels_by_arm[0] == labels_by_arm[1] == labels_by_arm[2]):
        batch_errors.append("request labels/order differ across arms")
    if not (payload_by_arm[0] == payload_by_arm[1] == payload_by_arm[2]):
        batch_errors.append("payloads differ across arms")
    pairs = {}
    for left, right, name in ((0, 1, "O1_A"), (1, 2, "A_O2"), (0, 2, "O1_O2")):
        valid_all = bool(all_hashes[left]) and all(len(h) == batch and None not in h for h in all_hashes[left])
        valid_measured = bool(measured_hashes[left]) and all(
            len(h) == batch and None not in h for h in measured_hashes[left]
        )
        pairs[name] = {
            "all_recorded_pixels_exact": valid_all and all_hashes[left] == all_hashes[right],
            "measured_pixels_exact": valid_measured and measured_hashes[left] == measured_hashes[right],
            "different_request_labels": [
                labels_by_arm[left][i]
                for i, h in enumerate(all_hashes[left])
                if i >= len(all_hashes[right]) or h != all_hashes[right][i]
            ],
        }
    integrity = not common_errors and not batch_errors
    numerical = (
        integrity
        and all(a["within_process_all_recorded_pixels_exact"] for a in arm_results)
        and all(pair["all_recorded_pixels_exact"] for pair in pairs.values())
    )
    timing_ok = all(len(values) == repeat_count and summarize(values)["finite_positive"] for values in measured_by_arm)
    timing_ok = timing_ok and not any(a["timing_errors"] for a in arm_results)
    means = [a["http_wall"]["mean_ms"] for a in arm_results]
    if timing_ok:
        drift = abs(means[2] - means[0]) / means[0]
        baseline = (means[0] + means[2]) / 2
        reduction = (baseline - means[1]) / baseline
    else:
        drift, baseline, reduction = None, None, None
    drift_pass = timing_ok and drift <= protocol["baseline_drift_limit_fraction"]
    return {
        "batch": batch,
        "integrity_passed": integrity,
        "arms": arm_results,
        "cross_arm_pixels": pairs,
        "strict_numerical_gate_passed": numerical,
        "timing_complete_and_finite": timing_ok,
        "baseline_drift_fraction": drift,
        "baseline_drift_limit_fraction": protocol["baseline_drift_limit_fraction"],
        "baseline_timing_stability_passed": drift_pass,
        "bracket_baseline_mean_ms": baseline,
        "candidate_mean_ms": means[1],
        "observed_latency_reduction_fraction": reduction,
        "performance_claim_eligible": integrity and numerical and timing_ok and drift_pass,
        "errors": batch_errors,
        "scope": "This batch, prompt, seed, resolution and three fresh processes only. No outliers removed.",
    }


def analyze(paths, protocol, manifest_paths, harness):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(harness.resolve()))
    verify_proofs = importlib.import_module("proof_validation").verify_startup_proofs
    arms = [
        load_arm(path, variant, protocol, manifest, harness, verify_proofs)
        for path, variant, manifest in zip(paths, protocol["order"], manifest_paths)
    ]
    common_errors = [f"arm {i}: {error}" for i, arm in enumerate(arms) for error in arm["errors"]]
    for key in COMMON:
        if not all(arm["metadata"].get(key) == arms[0]["metadata"].get(key) for arm in arms[1:]):
            common_errors.append(f"runtime/config {key} differs across arms")
    for rank in range(protocol["parallelism"]["tp"]):
        workers = [
            {k: v for k, v in arm["receipts"][rank]["worker"].items() if k != "worker_module_file"}
            if len(arm["receipts"]) > rank
            else None
            for arm in arms
        ]
        if not (workers[0] is not None and workers[0] == workers[1] == workers[2]):
            common_errors.append(f"rank {rank} worker/runtime/precision settings differ or are missing")
    for i, arm in enumerate(arms):
        if any(row.get("batch") not in protocol["batches"] for row in arm["rows"]):
            common_errors.append(f"arm {i}: unexpected request batch")
    for first, second in zip(arms, arms[1:]):
        end, start = first["metadata"].get("ended_unix_s"), second["metadata"].get("started_unix_s")
        if not finite_number(end, positive=True) or not finite_number(start, positive=True) or end > start:
            common_errors.append("O/A/O process order/serial execution not verified")
    batches = {str(batch): compare_batch(arms, batch, protocol, common_errors) for batch in protocol["batches"]}
    return {
        "schema_version": 1,
        "protocol_id": protocol["protocol_id"],
        "source_shas": protocol["source_shas"],
        "order": protocol["order"],
        "scope": protocol["scope"],
        "statistical_unit": protocol["statistical_unit"],
        "percentile_method": protocol["percentile_method"],
        "common_integrity_errors": common_errors,
        "batches": batches,
        "all_batches_performance_claim_eligible": all(b["performance_claim_eligible"] for b in batches.values()),
        "limits": protocol["limits"],
        "image_validation_note": "Recomputed PNG file and decoded RGB hashes; image equality does not test hidden-tensor finiteness.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arms", type=Path, nargs=3, required=True, metavar=("O1", "A", "O2"))
    parser.add_argument("--harness", type=Path, required=True)
    parser.add_argument("--base-manifest", type=Path, required=True)
    parser.add_argument("--candidate-manifest", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=Path(__file__).with_name("PROTOCOL.json"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if any(args.output.resolve().is_relative_to(path.resolve()) for path in args.arms):
        raise ValueError("Analysis output must be outside raw arm directories")
    if args.output.exists():
        raise FileExistsError("Refusing to overwrite an existing analysis")
    result = analyze(
        args.arms,
        read_json(args.protocol),
        [args.base_manifest, args.candidate_manifest, args.base_manifest],
        args.harness,
    )
    result["analysis_sha256"] = sha256(__file__)
    result["protocol_sha256"] = sha256(args.protocol)
    result["validator_sources_sha256"] = {
        name: sha256(args.harness / name) for name in ("proof_validation.py", "source_manifest.py")
    }
    result["harness_manifest_sha256"] = sha256(args.harness / "BUNDLE_MANIFEST.json")
    result["input_receipt_sha256"] = {
        str(path): sha256(path)
        for arm in args.arms
        for path in (arm / "metadata.json", arm / "http/requests.jsonl")
        if path.exists()
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "common_integrity_errors": result["common_integrity_errors"],
                "batches": {
                    k: {
                        n: v[n]
                        for n in (
                            "strict_numerical_gate_passed",
                            "baseline_timing_stability_passed",
                            "performance_claim_eligible",
                            "observed_latency_reduction_fraction",
                        )
                    }
                    for k, v in result["batches"].items()
                },
            }
        )
    )


if __name__ == "__main__":
    main()
