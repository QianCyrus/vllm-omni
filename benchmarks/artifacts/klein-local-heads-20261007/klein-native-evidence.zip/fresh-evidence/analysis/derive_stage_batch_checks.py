#!/usr/bin/env python3
"""Derive batch-local image checks from the unchanged frozen stage parser report."""

import argparse
import hashlib
import json
from pathlib import Path


def derive(report):
    if (report.get("kind") != "native_stage_diagnostic" or report.get("scored") is not False
            or report.get("performance_claim_eligible") is not False
            or report.get("execution_integrity") != "PASS" or report.get("rank") != 0
            or report.get("across_rank_aggregation") is not None):
        raise ValueError("Expected a validated, unscored rank-0 stage diagnostic")
    comparisons = report["native_image_comparison"]
    if len(comparisons) != 2 or set(report["batches"]) != {"1", "4"}:
        raise ValueError("Expected two stage services and B1/B4")
    if [len(value["comparisons"]) for value in comparisons] != [2, 1]:
        raise ValueError("Must compare stage O to native O1/O2 and stage A to native A")
    output = {
        "kind": "derived_native_stage_batch_checks", "scored": False,
        "native_service_performance_qualified_by_this_report": False,
        "rank": 0, "across_rank_aggregation": None,
        "scope": "Batch-local image checks for separate synchronizing stage diagnostics; no change to native timing gates.",
        "limitations": "Exact images do not prove timing neutrality. Synchronization/logging overhead remains. One diagnostic process per variant, five measured samples per batch.",
        "batches": {},
    }
    for batch in (1, 4):
        value = report["batches"][str(batch)]
        native = []
        for stage_variant, section in zip(("O", "A"), comparisons, strict=True):
            for comparison in section["comparisons"]:
                if comparison["variant"] != stage_variant:
                    raise ValueError("Native comparison variant mismatch")
                rows = [row for row in comparison["requests"] if row["batch"] == batch]
                if len(rows) != 8 or len({row["label"] for row in rows}) != 8:
                    raise ValueError("Expected all three warmups and five stage samples")
                expected_labels = {f"b{batch}-{kind}-{i:02}" for kind, count in (("warmup", 3), ("sample", 5)) for i in range(count)}
                if {row["label"] for row in rows} != expected_labels:
                    raise ValueError("Stage labels differ from frozen protocol")
                if any(row["matched_native_requests"] != 35 for row in rows):
                    raise ValueError("Expected comparison against five warmups plus thirty native samples")
                native.append({
                    "stage_variant": stage_variant,
                    "native_arm": Path(comparison["directory"]).name,
                    "stage_requests": 8, "stage_images": 8 * batch,
                    "native_requests": 35, "native_images": 35 * batch,
                    "all_stage_images_exact_to_all_native_repeats": all(row["exact_to_all_native_repeats"] for row in rows),
                    "different_stage_request_labels": [row["label"] for row in rows if not row["exact_to_all_native_repeats"]],
                })
        within = value["within_process_images_exact_including_warmup"]
        cross = value["cross_variant_all_images_exact"]
        if len(within) != 2:
            raise ValueError("Expected two within-service image checks")
        native_exact = all(item["all_stage_images_exact_to_all_native_repeats"] for item in native)
        output["batches"][str(batch)] = {
            "within_process_images_exact_including_warmup": within,
            "cross_variant_all_stage_images_exact": cross,
            "same_variant_native_images_exact": native_exact,
            "batch_image_check_passed": all(within) and cross and native_exact,
            "native_comparisons": native,
            "diagnostic_stages": value["stages"],
        }
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.summary.read_bytes()
    result = derive(json.loads(raw))
    result["input_report"] = {"file": args.summary.name, "sha256": hashlib.sha256(raw).hexdigest()}
    result["derivation_script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with args.output.open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value["batch_image_check_passed"] for key, value in result["batches"].items()}))


if __name__ == "__main__":
    main()
