"""CPU-only layout test for the benchmark controls, not production validation.

Tiny FP64 dense reference, real PyTorch SDPA/RMSNorm, simulated TP gather.
Import stubs replace framework dispatch only in this standalone test process.
"""

import importlib.util
import sys
import types
import unittest
from pathlib import Path

import torch
from torch.nn import functional as F


class Attention(torch.nn.Module):
    def __init__(self, num_heads, **kwargs):
        super().__init__()
        self.num_heads = num_heads

    def forward(self, query, key, value, metadata=None):
        return F.scaled_dot_product_attention(
            query.transpose(1, 2),
            key.transpose(1, 2),
            value.transpose(1, 2),
            attn_mask=None if metadata is None else metadata.attn_mask,
        ).transpose(1, 2)


def load_controls():
    modules = {
        "vllm.distributed": {"tensor_model_parallel_all_gather": None},
        "vllm_omni.diffusion.attention.backends.abstract": {"AttentionMetadata": types.SimpleNamespace},
        "vllm_omni.diffusion.attention.layer": {"Attention": Attention},
        "vllm_omni.diffusion.layers.rope": {"apply_rope_to_qk": lambda rope, q, k, emb: (q, k)},
    }
    saved = {}
    for fullname, attrs in modules.items():
        parts = fullname.split(".")
        for count in range(1, len(parts) + 1):
            name = ".".join(parts[:count])
            if name not in saved:
                saved[name] = sys.modules.get(name)
                sys.modules[name] = types.ModuleType(name)
        for name, value in attrs.items():
            setattr(sys.modules[fullname], name, value)
    try:
        path = Path(__file__).with_name("ablation_variants.py")
        spec = importlib.util.spec_from_file_location("controls_under_test", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        for name, value in saved.items():
            if value is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value


class Projection(torch.nn.Module):
    def __init__(self, weight, bias, rank):
        super().__init__()
        self.weight = torch.nn.Parameter(weight)
        self.bias = torch.nn.Parameter(bias)
        self.tp_rank = rank

    def forward(self, value):
        return F.linear(value, self.weight, self.bias), None


class SwiGLU(torch.nn.Module):
    def forward(self, value):
        gate, up = value.chunk(2, dim=-1)
        return F.silu(gate) * up


class ControlsTest(unittest.TestCase):
    def test_controls_restore_global_segment_order(self):
        controls = load_controls()
        torch.manual_seed(13)
        world, dim, mlp, heads = 4, 32, 96, 8
        width = dim // heads
        x = torch.randn(2, 7, dim, dtype=torch.float64)
        weight = torch.randn(3 * dim + 2 * mlp, dim, dtype=torch.float64) * 0.1
        bias = torch.randn(3 * dim + 2 * mlp, dtype=torch.float64) * 0.1
        output_weight = torch.randn(dim, dim + mlp, dtype=torch.float64) * 0.1
        output_bias = torch.randn(dim, dtype=torch.float64) * 0.1
        packed = F.linear(x, weight, bias)
        q, k, v, gate, up = packed.split([dim, dim, dim, mlp, mlp], dim=-1)
        query = F.rms_norm(q.unflatten(-1, (heads, width)), (width,), eps=1e-6)
        key = F.rms_norm(k.unflatten(-1, (heads, width)), (width,), eps=1e-6)
        attention = Attention(heads)(query, key, v.unflatten(-1, (heads, width))).flatten(2, 3)
        mlp_output = F.silu(gate) * up
        expected = F.linear(torch.cat([attention, mlp_output], dim=-1), output_weight, output_bias)

        def rank_segments(value, sizes, rank, axis=-1):
            return torch.cat([part.chunk(world, dim=axis)[rank] for part in value.split(sizes, dim=axis)], dim=axis)

        def gathered_segments(value, sizes):
            return torch.cat([rank_segments(value, sizes, rank) for rank in range(world)], dim=-1)

        for variant in ("L", "H", "M"):
            for rank in range(world):
                with self.subTest(variant=variant, rank=rank):
                    local_weight = rank_segments(weight, [dim] * 3 + [mlp] * 2, rank, axis=0)
                    local_bias = rank_segments(bias, [dim] * 3 + [mlp] * 2, rank, axis=0)
                    candidate = types.SimpleNamespace(
                        local_tp=True,
                        heads=heads,
                        inner_dim=dim,
                        mlp_hidden_dim=mlp,
                        head_dim=width,
                        to_qkv_mlp_proj=Projection(local_weight, local_bias, rank),
                        to_out=Projection(output_weight, output_bias, rank),
                        norm_q=torch.nn.RMSNorm(width, eps=1e-6, dtype=torch.float64),
                        norm_k=torch.nn.RMSNorm(width, eps=1e-6, dtype=torch.float64),
                        rope=torch.nn.Identity(),
                        mlp_act_fn=SwiGLU(),
                        attn=Attention(heads // world),
                    )
                    if variant == "L":
                        inputs = [rank_segments(packed, [dim] * 3 + [mlp] * 2, rank)]
                        outputs = [gathered_segments(packed, [dim] * 3 + [mlp] * 2)]
                    elif variant == "H":
                        mlp_input = torch.cat([gate, up], dim=-1)
                        inputs = [rank_segments(mlp_input, [mlp] * 2, rank), attention.chunk(world, dim=-1)[rank]]
                        outputs = [gathered_segments(mlp_input, [mlp] * 2), attention]
                    else:
                        qkv = torch.cat([q, k, v], dim=-1)
                        inputs = [rank_segments(qkv, [dim] * 3, rank), mlp_output.chunk(world, dim=-1)[rank]]
                        outputs = [gathered_segments(qkv, [dim] * 3), mlp_output]
                    calls = []

                    def gather(value, dim=-1):
                        call = len(calls)
                        self.assertEqual(dim, -1)
                        torch.testing.assert_close(value, inputs[call], rtol=1e-12, atol=1e-12)
                        calls.append(value.shape)
                        return outputs[call]

                    controls.tensor_model_parallel_all_gather = gather
                    actual = controls.AblationAttention(candidate, variant, world)(x)
                    torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
                    self.assertEqual(len(calls), 1 if variant == "L" else 2)


if __name__ == "__main__":
    unittest.main()
