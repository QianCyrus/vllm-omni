#!/usr/bin/env python3
"""Real-weight Klein block ablations; synthetic inputs are not model activations.

Run with torchrun under the frozen candidate runtime. O loads the pinned base
module; A loads the pinned candidate module. L/H/M exist only in this harness.
"""

import argparse
import dataclasses
import hashlib
import importlib.metadata
import json
import os
import statistics
import subprocess
import time
import traceback
from pathlib import Path
from unittest.mock import patch

from component_utils import (
    CPUControlPlane,
    checkpoint_tensors,
    load_module,
    segmented_rows,
    sha256,
    tensor_metrics,
    to_device,
)


def verify_module_identity(path, expected_sha):
    """Require a clean checkout or frozen export with a matching COMMIT marker.

    Export byte manifests are verified by the allocation launcher. This check
    prevents mixing module paths and declared revisions in the component run.
    """
    path = Path(path).resolve()
    for root in path.parents:
        if (root / "COMMIT").is_file():
            actual = (root / "COMMIT").read_text().strip()
        elif (root / ".git").exists():
            actual = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
            dirty = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain"], text=True)
            if dirty:
                raise ValueError("Run from a clean committed source tree or verified immutable export")
        else:
            continue
        if actual != expected_sha:
            raise ValueError(f"Module source identity differs from the declared SHA: {path}")
        return root
    raise ValueError("Module path must belong to a pinned source checkout/export")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Local, revision-pinned Diffusers checkpoint")
    parser.add_argument("--model-revision", required=True)
    parser.add_argument("--baseline-module", required=True)
    parser.add_argument("--candidate-module", required=True)
    parser.add_argument("--base-sha", required=True)
    parser.add_argument("--head-sha", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--blocks", default="0")
    parser.add_argument("--batches", default="1,4")
    parser.add_argument("--sequence-length", type=int, default=4608)
    parser.add_argument("--seed", type=int, default=8137)
    parser.add_argument("--variants", default="O,L,H,M,A")
    parser.add_argument("--lanes", choices=("eager", "compiled", "both"), default="both")
    parser.add_argument("--mode", choices=("correctness", "both"), default="correctness")
    parser.add_argument("--warmups", type=int, default=10)
    parser.add_argument("--rounds", type=int, default=30)
    parser.add_argument("--calls", type=int, default=5)
    parser.add_argument("--captures", help="Optional phase7-schema native capture directory; trusted local files only")
    parser.add_argument("--steps", default="0", help="Capture step indices; unused for synthetic inputs")
    parser.add_argument("--profile", action="store_true", help="Separate unscored trace, never inside timing")
    parser.add_argument("--deadline-seconds", type=float, default=780)
    args = parser.parse_args()
    if min(args.sequence_length, args.warmups, args.rounds, args.calls) < 1:
        parser.error("length and repetition counts must be positive")
    args.blocks = [int(value) for value in args.blocks.split(",")]
    args.batches = [int(value) for value in args.batches.split(",")]
    args.steps = [int(value) for value in args.steps.split(",")]
    args.variants = args.variants.split(",")
    if len(set(args.variants)) != len(args.variants) or not set(args.variants) <= set("OLHMA"):
        parser.error("variants must be distinct members of O,L,H,M,A")
    if not args.variants or args.variants[0] != "O" or min(args.batches) < 1:
        parser.error("O must be first and batch sizes positive")
    for value in (args.base_sha, args.head_sha, args.model_revision):
        if len(value) != 40 or any(char not in "0123456789abcdef" for char in value):
            parser.error("Source and model revisions must be complete commit hashes")
    return args


def cpu_tensor_digest(value):
    import torch

    return hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()


def load_capture(directory, case, baseline_hash, world):
    """Require captured base output and matching logical inputs on every rank."""
    import torch

    path = Path(directory) / f"{case}.pt"
    records = [json.loads((Path(directory) / f"{case}-rank{rank}.json").read_text()) for rank in range(world)]
    first = records[0]
    for rank, record in enumerate(records):
        expected_case = f"b{record['batch']}-step{record['step']}-block{record['block']}"
        if record["rank"] != rank or record["module_sha256"] != baseline_hash or expected_case != case:
            raise ValueError("Capture source, rank or case mismatch")
        for key in ("kwargs", "attention_input", "output", "request"):
            if record[key] != first[key]:
                raise ValueError(f"Capture differs between TP ranks: {key}")
    if sha256(path) != first["tensor_file_sha256"]:
        raise ValueError("Capture tensor file does not match its receipt")
    capture = torch.load(path, map_location="cpu", weights_only=False)
    saved = {key: value for key, value in first.items() if key not in ("tensor_file", "tensor_file_sha256")}
    if capture["metadata"] not in (first, saved):
        raise ValueError("Capture tensor/JSON metadata differ")
    return capture, {
        "source": "captured_native_logical_values",
        "file_sha256": first["tensor_file_sha256"],
        "limitation": "Legacy captures do not establish original strides/storage aliasing or native compiled replay.",
    }


def main():
    args = parse_args()
    verify_module_identity(args.baseline_module, args.base_sha)
    candidate_root = verify_module_identity(args.candidate_module, args.head_sha)
    started = time.monotonic()
    rank, world = int(os.environ["RANK"]), int(os.environ["WORLD_SIZE"])
    local_rank = int(os.environ["LOCAL_RANK"])
    if world != 4:
        raise ValueError("This first component protocol is fixed to TP4")
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if (output / f"status-rank{rank}.json").exists():
        raise FileExistsError("Use a fresh output directory; do not overwrite an earlier run")

    def write(name, value):
        path = output / f"{name}-rank{rank}.json"
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
        temporary.replace(path)

    def progress(stage, **extra):
        record = {"rank": rank, "stage": stage, "elapsed_s": time.monotonic() - started, **extra}
        print("COMPONENT_PROGRESS " + json.dumps(record), flush=True)
        with (output / f"progress-rank{rank}.jsonl").open("a") as stream:
            stream.write(json.dumps(record) + "\n")

    write("status", {"status": "RUNNING", "component_only": True})
    progress("imports_before")
    import ablation_variants
    import torch
    import torch.distributed as dist
    import vllm.model_executor.layers.linear as linear_module
    from vllm.config.vllm import set_current_vllm_config
    from vllm.model_executor.model_loader.weight_utils import default_weight_loader

    import vllm_omni
    from vllm_omni.diffusion.config import set_current_diffusion_config
    from vllm_omni.diffusion.data import AttentionConfig, AttentionSpec, DiffusionParallelConfig, OmniDiffusionConfig
    from vllm_omni.diffusion.distributed.parallel_state import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_world_group,
        init_distributed_environment,
        initialize_model_parallel,
    )
    from vllm_omni.diffusion.forward_context import set_forward_context
    from vllm_omni.diffusion.vllm_config import create_diffusion_vllm_config
    from vllm_omni.diffusion.worker.diffusion_worker import _resolve_ir_op_priority

    if Path(vllm_omni.__file__).resolve().parent.parent != candidate_root:
        raise ValueError("Framework imports must come from the declared candidate source tree")
    torch.set_num_threads(2)
    torch.cuda.set_device(local_rank)
    init_distributed_environment(world_size=world, rank=rank, local_rank=local_rank, backend="nccl")
    initialize_model_parallel(
        data_parallel_size=1, sequence_parallel_size=1, tensor_parallel_size=world, backend="nccl"
    )
    control = CPUControlPlane(torch, dist, get_world_group().cpu_group, progress)
    parallel = DiffusionParallelConfig(data_parallel_size=1, sequence_parallel_size=1, tensor_parallel_size=world)
    config = OmniDiffusionConfig(
        model=args.model,
        parallel_config=parallel,
        dtype=torch.bfloat16,
        diffusion_attention_config=AttentionConfig(default=AttentionSpec(backend="TORCH_SDPA")),
    )
    vllm_config = create_diffusion_vllm_config(torch.device("cuda", local_rank), config)
    vllm_config.kernel_config.ir_op_priority = _resolve_ir_op_priority(config, vllm_config)
    baseline = load_module(args.baseline_module, "klein_component_base")
    candidate = load_module(args.candidate_module, "klein_component_head")
    architecture = json.loads((Path(args.model) / "transformer/config.json").read_text())
    heads, head_dim = architecture["num_attention_heads"], architecture["attention_head_dim"]
    dim = heads * head_dim
    mlp = int(dim * architecture["mlp_ratio"])
    widths = [dim, dim, dim, mlp, mlp]
    if heads % world or any(width % world for width in widths):
        raise ValueError("All segments and heads must divide TP")
    checks, mappings, timings, collectives, input_records, compiler_records = [], [], [], [], [], []
    metadata = {
        "scope": "one real-weight single-stream block; no full-model quality/latency claim",
        "input_source": "captured_native_logical_values" if args.captures else "synthetic_inputs_with_real_checkpoint",
        "args": vars(args),
        "rank": rank,
        "world": world,
        "gpu": torch.cuda.get_device_name(),
        "gpu_memory_bytes": torch.cuda.get_device_properties(local_rank).total_memory,
        "versions": {key: importlib.metadata.version(key) for key in ("torch", "vllm", "diffusers", "transformers")},
        "cuda_build": torch.version.cuda,
        "nccl": torch.cuda.nccl.version(),
        "hashes": {
            "base_module": sha256(args.baseline_module),
            "head_module": sha256(args.candidate_module),
            **{
                name: sha256(Path(__file__).with_name(name))
                for name in ("bench_components.py", "ablation_variants.py", "component_utils.py")
            },
            "transformer_config": sha256(Path(args.model) / "transformer/config.json"),
        },
        "architecture": architecture,
        "ir_op_priority": dataclasses.asdict(vllm_config.kernel_config.ir_op_priority),
        "ir_enable_torch_wrap": vllm_config.compilation_config.ir_enable_torch_wrap,
        "compilation": "torch.compile(bound block.forward, dynamic=True), as in native regional compilation",
        "comparison_runtime": "All arms share the candidate framework dependencies; O's block source is pinned base.",
        "timing": "unprofiled CUDA events and synchronized wall clock; retain every rank and score max rank",
        "memory_scope": "all selected variants coexist; component memory cannot establish full-model peak reduction",
        "ablations": "H/M alter both computation and communication; percentages are not additive",
    }
    write("metadata", metadata)

    def persist():
        for name, value in (
            ("correctness", checks),
            ("loader", mappings),
            ("timing", timings),
            ("collectives", collectives),
            ("inputs", input_records),
            ("compiler", compiler_records),
        ):
            write(name, value)

    def compiler_counters():
        from torch._dynamo.utils import counters

        return {group: dict(values) for group, values in counters.items()}

    def deadline():
        if control.any_true(time.monotonic() - started > args.deadline_seconds):
            raise TimeoutError("Component deadline reached; partial results are incomplete")

    def construct(variant, weights, block_index):
        module = baseline if variant == "O" else candidate
        previous_dtype = torch.get_default_dtype()
        try:
            torch.set_default_dtype(torch.bfloat16)
            with set_current_diffusion_config(config), set_current_vllm_config(vllm_config), torch.device("cuda"):
                extra = {} if variant == "O" else {"local_tp": True}
                block = module.Flux2SingleTransformerBlock(
                    parallel_config=parallel,
                    dim=dim,
                    num_attention_heads=heads,
                    attention_head_dim=head_dim,
                    mlp_ratio=architecture["mlp_ratio"],
                    eps=architecture.get("eps", 1e-6),
                    bias=False,
                    prefix=f"single_transformer_blocks.{block_index}",
                    **extra,
                )
                if variant in ("L", "H", "M"):
                    block.attn = ablation_variants.AblationAttention(block.attn, variant, world)
        finally:
            torch.set_default_dtype(previous_dtype)
        params = dict(block.named_parameters())
        if set(params) != set(weights):
            raise ValueError(f"Canonical/parameter name mismatch: {variant}: {set(params) ^ set(weights)}")
        for name, parameter in params.items():
            canonical = weights[name]
            getattr(parameter, "weight_loader", default_weight_loader)(parameter, canonical)
            if name.startswith("attn.to_qkv_mlp_proj."):
                expected = (
                    canonical.chunk(world, dim=0)[rank]
                    if variant == "O"
                    else segmented_rows(canonical, widths, rank, world)
                )
            elif name.startswith("attn.to_out."):
                expected = canonical.chunk(world, dim=0)[rank]
            else:
                expected = canonical
            exact = torch.equal(parameter.detach().cpu(), expected)
            mappings.append(
                {"block": block_index, "variant": variant, "name": name, "exact": exact, "shape": list(parameter.shape)}
            )
            if control.any_true(not exact):
                raise ValueError(f"Canonical weight mapping failed: {variant}/{name}")
        expected_heads = heads // world if variant in ("H", "A") else heads
        if block.attn.attn.num_heads != expected_heads:
            raise ValueError("Attention is configured with the wrong head count")
        progress(
            "constructed",
            block=block_index,
            variant=variant,
            actual_heads=block.attn.attn.num_heads,
            input_gather=block.attn.to_qkv_mlp_proj.gather_output,
            norm_class=type(block.attn.norm_q).__name__,
            norm_forward=repr(block.attn.norm_q.forward),
        )
        return block.eval()

    def synthetic_inputs(batch, block_index):
        generator = torch.Generator(device="cpu").manual_seed(args.seed + 1000 * block_index + batch)
        hidden = torch.randn(batch, args.sequence_length, dim, generator=generator).bfloat16()
        modulation = tuple((torch.randn(batch, 1, dim, generator=generator) * 0.1).bfloat16() for _ in range(3))
        ids = torch.zeros(args.sequence_length, len(architecture["axes_dims_rope"]), device="cuda")
        # Valid but synthetic positions; neither hidden states nor modulation
        # come from a denoising step. S=4608 matches the historical B1/B4 shape.
        ids[:, -1] = torch.arange(args.sequence_length, device="cuda")
        position = baseline.Flux2PosEmbed(architecture["rope_theta"], list(architecture["axes_dims_rope"]))
        rotary = position(ids)
        evidence = {
            "source": "synthetic_inputs_with_real_checkpoint",
            "seed": args.seed + 1000 * block_index + batch,
            "shape": list(hidden.shape),
            "hidden_sha256": cpu_tensor_digest(hidden),
            "modulation_sha256": [cpu_tensor_digest(value) for value in modulation],
            "rotary_ids": "all zero except monotonically increasing final axis",
            "layout": "contiguous generated inputs; no native storage/activation claim",
        }
        kwargs = {
            "hidden_states": hidden.cuda(),
            "encoder_hidden_states": None,
            "temb_mod_params": tuple(value.cuda() for value in modulation),
            "image_rotary_emb": rotary,
        }
        return kwargs, evidence

    def observe_gathers(block, kwargs, case, variant):
        calls = []

        def wrap(original):
            def observed(value, *positional, **keywords):
                calls.append(
                    {
                        "input_shape": list(value.shape),
                        "dtype": str(value.dtype),
                        "dimension": keywords.get("dim", positional[0] if positional else -1),
                        "logical_output_bytes": value.numel() * value.element_size() * world,
                    }
                )
                return original(value, *positional, **keywords)

            return observed

        patches = [
            patch.object(module, "tensor_model_parallel_all_gather", wrap(module.tensor_model_parallel_all_gather))
            for module in (linear_module, candidate, ablation_variants)
            if hasattr(module, "tensor_model_parallel_all_gather")
        ]
        try:
            for item in patches:
                item.start()
            result = block(**kwargs)
            del result
            torch.accelerator.synchronize()
        finally:
            for item in reversed(patches):
                item.stop()
        expected_calls = 2 if variant in ("O", "L") else 3
        features = {
            "O": 4 * dim + 2 * mlp,
            "L": 4 * dim + 2 * mlp,
            "H": 2 * dim + 2 * mlp,
            "M": 4 * dim + mlp,
            "A": 2 * dim + mlp,
        }[variant]
        hidden = kwargs["hidden_states"]
        expected_bytes = hidden.shape[0] * hidden.shape[1] * features * hidden.element_size()
        actual_bytes = sum(item["logical_output_bytes"] for item in calls)
        valid = len(calls) == expected_calls and actual_bytes == expected_bytes
        collectives.append(
            {
                "case": case,
                "variant": variant,
                "calls": calls,
                "valid": valid,
                "expected_calls": expected_calls,
                "expected_logical_bytes": expected_bytes,
                "scope": "eager diagnostic logical collective tensors, not network traffic",
            }
        )
        if control.any_true(not valid):
            raise ValueError("Observed collective count or byte volume differs from the declared ablation")

    def check_outputs(callables, kwargs, case, lane, capture=None):
        expected = callables["O"](**kwargs).detach().cpu()
        if capture is not None and lane == "eager":
            replay = tensor_metrics(capture["output"], expected)
            checks.append({"case": case, "lane": lane, "comparison": "native-O-vs-harness-O", "metrics": replay})
            if control.any_true(not replay["exact"] or not replay.get("finite", False)):
                raise ValueError("Native base replay failed; do not interpret candidate comparisons")
        failed = False
        for variant in args.variants:
            actual = callables[variant](**kwargs).detach().cpu()
            metrics = tensor_metrics(expected, actual)
            checks.append({"case": case, "lane": lane, "comparison": f"O-vs-{variant}", "metrics": metrics})
            failed |= not metrics["exact"] or not metrics.get("finite", False)
            del actual
        del expected
        persist()
        if control.any_true(failed):
            raise ValueError("NUMERICAL_REVIEW_REQUIRED: component equality failed; timing this case is blocked")

    def benchmark(callables, kwargs, case, lane):
        counters_before = compiler_counters()
        samples = {variant: [] for variant in args.variants}
        schedule = []
        for repeat in range(args.rounds):
            # Rotate the first variant; alternating reversal also varies adjacency.
            order = args.variants[repeat % len(args.variants) :] + args.variants[: repeat % len(args.variants)]
            if repeat % 2:
                order = list(reversed(order))
            schedule.append(order)
            for variant in order:
                deadline()
                control.barrier()
                torch.accelerator.synchronize()
                begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                begin.record()
                wall_start = time.perf_counter()
                for _ in range(args.calls):
                    result = callables[variant](**kwargs)
                    del result
                end.record()
                torch.accelerator.synchronize()
                wall_ms = 1000 * (time.perf_counter() - wall_start) / args.calls
                cuda_ms = begin.elapsed_time(end) / args.calls
                samples[variant].append(control.gather_timing([wall_ms, cuda_ms], world))
        for variant in args.variants:
            wall = [max(rank_value[0] for rank_value in sample) for sample in samples[variant]]
            cuda = [max(rank_value[1] for rank_value in sample) for sample in samples[variant]]
            timings.append(
                {
                    "case": case,
                    "lane": lane,
                    "variant": variant,
                    "schedule": schedule,
                    "samples_per_rank_wall_cuda_ms": samples[variant],
                    "rank_max_wall_mean_ms": statistics.mean(wall),
                    "rank_max_wall_sd_ms": statistics.stdev(wall) if len(wall) > 1 else 0.0,
                    "rank_max_wall_median_ms": statistics.median(wall),
                    "rank_max_cuda_mean_ms": statistics.mean(cuda),
                }
            )
        persist()
        counters_after = compiler_counters()
        compiler_records.append(
            {"case": case, "lane": lane, "phase": "timing", "before": counters_before, "after": counters_after}
        )
        recompiled = counters_before.get("stats", {}).get("unique_graphs", 0) != counters_after.get("stats", {}).get(
            "unique_graphs", 0
        )
        if lane == "compiled" and control.any_true(recompiled):
            raise ValueError("Compilation occurred during the scored interval; timing lane is invalid")

    status = "FAILED"
    try:
        for block_index in args.blocks:
            deadline()
            # Checkpoint CPU I/O precedes the native forward/inference context.
            weights, provenance = checkpoint_tensors(args.model, block_index)
            write(f"weights-block{block_index}", provenance)
            with torch.inference_mode(), set_forward_context(vllm_config=vllm_config, omni_diffusion_config=config):
                modules = {variant: construct(variant, weights, block_index) for variant in args.variants}
                del weights
                lanes = ("eager", "compiled") if args.lanes == "both" else (args.lanes,)
                compiled = None
                if "compiled" in lanes:
                    compiled = {
                        variant: torch.compile(module.forward, dynamic=True) for variant, module in modules.items()
                    }
                for batch in args.batches:
                    for step in args.steps if args.captures else (None,):
                        deadline()
                        capture = None
                        if args.captures:
                            case = f"b{batch}-step{step}-block{block_index}"
                            capture, evidence = load_capture(
                                args.captures, case, metadata["hashes"]["base_module"], world
                            )
                            kwargs = to_device(capture["kwargs"], "cuda")
                        else:
                            case = f"synthetic-b{batch}-s{args.sequence_length}-block{block_index}"
                            kwargs, evidence = synthetic_inputs(batch, block_index)
                        if kwargs["encoder_hidden_states"] is not None:
                            raise ValueError(
                                "The first component protocol expects already-concatenated single-stream input"
                            )
                        if kwargs["hidden_states"].dtype != torch.bfloat16:
                            raise ValueError("This protocol is fixed to BF16")
                        input_records.append({"case": case, **evidence})
                        # Eager correctness and communication proof precede all timing.
                        check_outputs(modules, kwargs, case, "eager", capture)
                        for variant in args.variants:
                            observe_gathers(modules[variant], kwargs, case, variant)
                        for lane in lanes:
                            callables = modules if lane == "eager" else compiled
                            for variant in args.variants:
                                deadline()
                                progress("warmup_before", case=case, lane=lane, variant=variant)
                                counters_before = compiler_counters()
                                for _ in range(args.warmups):
                                    result = callables[variant](**kwargs)
                                    del result
                                torch.accelerator.synchronize()
                                compiler_records.append(
                                    {
                                        "case": case,
                                        "lane": lane,
                                        "variant": variant,
                                        "phase": "warmup",
                                        "before": counters_before,
                                        "after": compiler_counters(),
                                    }
                                )
                                progress("warmup_after", case=case, lane=lane, variant=variant)
                            check_outputs(callables, kwargs, case, lane)
                            if args.mode == "both":
                                benchmark(callables, kwargs, case, lane)
                            if args.profile:
                                deadline()
                                control.barrier()
                                with torch.profiler.profile(
                                    activities=[
                                        torch.profiler.ProfilerActivity.CPU,
                                        torch.profiler.ProfilerActivity.CUDA,
                                    ],
                                    record_shapes=True,
                                ) as profiler:
                                    for variant in args.variants:
                                        with torch.profiler.record_function(f"component_{variant}_{lane}"):
                                            result = callables[variant](**kwargs)
                                            torch.accelerator.synchronize()
                                            del result
                                profiler.export_chrome_trace(str(output / f"trace-{case}-{lane}-rank{rank}.json"))
                        del kwargs, capture
                del modules, compiled
                torch.accelerator.empty_cache()
        if sha256(args.baseline_module) != metadata["hashes"]["base_module"]:
            raise ValueError("Base source changed while the experiment was running")
        if sha256(args.candidate_module) != metadata["hashes"]["head_module"]:
            raise ValueError("Candidate source changed while the experiment was running")
        for name in ("bench_components.py", "ablation_variants.py", "component_utils.py"):
            if sha256(Path(__file__).with_name(name)) != metadata["hashes"][name]:
                raise ValueError(f"Harness source changed while the experiment was running: {name}")
        status = "PASS_COMPONENT_ONLY"
    except BaseException:
        write("error", {"traceback": traceback.format_exc()})
        raise
    finally:
        persist()
        write(
            "status",
            {
                "status": status,
                "elapsed_s": time.monotonic() - started,
                "native_full_model_quality_proven": False,
                "service_performance_proven": False,
            },
        )
        destroy_model_parallel()
        destroy_distributed_environment()


if __name__ == "__main__":
    main()
