"""Benchmark-only L/H/M controls. O and A use the unmodified source classes."""

import torch
from vllm.distributed import tensor_model_parallel_all_gather

from vllm_omni.diffusion.attention.backends.abstract import AttentionMetadata
from vllm_omni.diffusion.attention.layer import Attention
from vllm_omni.diffusion.layers.rope import apply_rope_to_qk


def gather_segments(value, global_widths, world):
    """One collective, then rank-major -> segment-major output order."""
    local_widths = [width // world for width in global_widths]
    gathered = tensor_model_parallel_all_gather(value.contiguous(), dim=-1)
    ranks = [chunk.split(local_widths, dim=-1) for chunk in gathered.split(sum(local_widths), dim=-1)]
    return torch.cat(
        [torch.cat([ranks[rank][segment] for rank in range(world)], dim=-1) for segment in range(len(global_widths))],
        dim=-1,
    )


class AblationAttention(torch.nn.Module):
    """Same segmented projection weights as A; selectively replicate computation.

    H gathers [gate_r, up_r] once and restores [all gate, all up].
    M gathers [Q_r, K_r, V_r] once and restores [all Q, all K, all V].
    These controls change communication as well as computation.
    """

    def __init__(self, candidate_attention, variant, world):
        super().__init__()
        if variant not in ("L", "H", "M") or not candidate_attention.local_tp:
            raise ValueError("L/H/M require an active local-TP candidate")
        self.variant = variant
        self.world = world
        self.heads = candidate_attention.heads
        self.dim = candidate_attention.inner_dim
        self.mlp_dim = candidate_attention.mlp_hidden_dim
        self.local_attention = variant == "H"
        self.local_mlp = variant == "M"
        self.query_num_heads = self.heads // world if self.local_attention else self.heads
        self.to_qkv_mlp_proj = candidate_attention.to_qkv_mlp_proj
        self.to_out = candidate_attention.to_out
        self.norm_q = candidate_attention.norm_q
        self.norm_k = candidate_attention.norm_k
        self.rope = candidate_attention.rope
        self.mlp_act_fn = candidate_attention.mlp_act_fn
        self.attn = (
            candidate_attention.attn
            if self.local_attention
            else Attention(
                num_heads=self.heads,
                head_size=candidate_attention.head_dim,
                softmax_scale=candidate_attention.head_dim**-0.5,
                causal=False,
            )
        )

    def forward(self, hidden_states, attention_mask=None, image_rotary_emb=None, **kwargs):
        projected, _ = self.to_qkv_mlp_proj(hidden_states)
        if self.variant == "L":
            projected = gather_segments(projected, [self.dim] * 3 + [self.mlp_dim] * 2, self.world)
            qkv, mlp = projected.split([self.dim * 3, self.mlp_dim * 2], dim=-1)
        else:
            qkv, mlp = projected.split([self.dim * 3 // self.world, self.mlp_dim * 2 // self.world], dim=-1)
            if self.local_attention:
                mlp = gather_segments(mlp, [self.mlp_dim] * 2, self.world)
            else:
                qkv = gather_segments(qkv, [self.dim] * 3, self.world)

        query, key, value = [part.unflatten(-1, (self.query_num_heads, -1)) for part in qkv.chunk(3, dim=-1)]
        query, key = self.norm_q(query), self.norm_k(key)
        query, key = apply_rope_to_qk(self.rope, query, key, image_rotary_emb)
        metadata = None
        if attention_mask is not None:
            if attention_mask.dim() == 3:
                attention_mask = attention_mask.unsqueeze(1)
            if self.local_attention and attention_mask.dim() == 4 and attention_mask.shape[1] != 1:
                attention_mask = attention_mask.narrow(
                    1, self.to_qkv_mlp_proj.tp_rank * self.query_num_heads, self.query_num_heads
                )
            metadata = AttentionMetadata(attn_mask=attention_mask)
        attention = self.attn(query, key, value, metadata).flatten(2, 3).to(query.dtype)
        mlp = self.mlp_act_fn(mlp)
        if self.local_attention:
            attention = tensor_model_parallel_all_gather(attention.contiguous())
        if self.local_mlp:
            mlp = tensor_model_parallel_all_gather(mlp.contiguous())
        result, _ = self.to_out(torch.cat([attention, mlp], dim=-1))
        return result
