"""CPU provenance, numerical reductions and Gloo control for component diagnostics."""

import hashlib
import importlib.util
import json
import sys
from pathlib import Path


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def segmented_rows(tensor, widths, rank, world):
    import torch

    if any(width % world for width in widths):
        raise ValueError("Every packed segment must divide TP")
    pieces = []
    offset = 0
    for width in widths:
        size = width // world
        pieces.append(tensor.narrow(0, offset + rank * size, size))
        offset += width
    if offset != tensor.shape[0]:
        raise ValueError("Packed segment widths do not cover the canonical tensor")
    return torch.cat(pieces, dim=0)


def to_device(value, device):
    import torch

    if isinstance(value, torch.Tensor):
        return value.to(device=device)
    if isinstance(value, dict):
        return {key: to_device(item, device) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(to_device(item, device) for item in value)
    if isinstance(value, list):
        return [to_device(item, device) for item in value]
    return value


def tensor_metrics(expected, actual):
    import torch

    if expected.shape != actual.shape or expected.dtype != actual.dtype:
        return {
            "exact": False,
            "shape_matches": expected.shape == actual.shape,
            "dtype_matches": expected.dtype == actual.dtype,
            "expected_shape": list(expected.shape),
            "actual_shape": list(actual.shape),
        }
    if torch.equal(expected, actual):
        finite = bool(torch.isfinite(expected).all())
        return {
            "exact": True,
            "finite": finite,
            "shape_matches": True,
            "dtype_matches": True,
            "differing_elements": 0,
            "elements": expected.numel(),
            "max_abs": 0.0,
            "relative_l2": 0.0,
            "rmse": 0.0,
            "cosine": 1.0,
        }
    # Chunk the CPU reduction: full B4 projection is ~1 GiB BF16.
    expected = expected.reshape(-1)
    actual = actual.reshape(-1)
    count = 0
    max_abs = 0.0
    squared_error = 0.0
    expected_squared = 0.0
    actual_squared = 0.0
    dot = 0.0
    finite = True
    for offset in range(0, expected.numel(), 1048576):
        left = expected[offset : offset + 1048576].float()
        right = actual[offset : offset + 1048576].float()
        delta = right - left
        finite = finite and bool(torch.isfinite(right).all()) and bool(torch.isfinite(left).all())
        count += int((left != right).sum())
        max_abs = max(max_abs, float(delta.abs().max()))
        squared_error += float(delta.double().square().sum())
        expected_squared += float(left.double().square().sum())
        actual_squared += float(right.double().square().sum())
        dot += float((left.double() * right.double()).sum())
    if not finite:
        return {
            "exact": False,
            "finite": False,
            "shape_matches": True,
            "dtype_matches": True,
            "differing_elements": count,
            "elements": expected.numel(),
            "max_abs": None,
            "relative_l2": None,
            "rmse": None,
            "cosine": None,
        }
    return {
        "exact": count == 0,
        "finite": finite,
        "shape_matches": True,
        "dtype_matches": True,
        "differing_elements": count,
        "elements": expected.numel(),
        "max_abs": max_abs,
        "relative_l2": (squared_error / max(expected_squared, 1e-300)) ** 0.5,
        "rmse": (squared_error / max(expected.numel(), 1)) ** 0.5,
        "cosine": dot / max((expected_squared * actual_squared) ** 0.5, 1e-300),
    }


def checkpoint_tensors(model, block):
    import torch
    from safetensors import safe_open

    directory = Path(model) / "transformer"
    prefix = f"single_transformer_blocks.{block}."
    index_path = directory / "diffusion_pytorch_model.safetensors.index.json"
    if index_path.exists():
        index = json.loads(index_path.read_text())["weight_map"]
        paths = sorted({directory / file for name, file in index.items() if name.startswith(prefix)})
    else:
        paths = sorted(directory.glob("*.safetensors"))
    if not paths:
        raise RuntimeError(f"No canonical checkpoint shards under {directory}")
    result = {}
    sources = {}
    for path in paths:
        with safe_open(path, framework="pt", device="cpu") as handle:
            for name in handle.keys():
                if name.startswith(prefix):
                    local_name = name[len(prefix) :].replace(".to_out.0.", ".to_out.")
                    if local_name in result:
                        raise RuntimeError(f"Duplicate checkpoint tensor {local_name}")
                    result[local_name] = handle.get_tensor(name)
                    sources[local_name] = {
                        "checkpoint_key": name,
                        "file": str(path),
                        "shape": list(result[local_name].shape),
                        "dtype": str(result[local_name].dtype),
                        "sha256_contiguous_bytes": hashlib.sha256(
                            result[local_name].contiguous().view(torch.uint8).numpy().tobytes()
                        ).hexdigest(),
                    }
    return result, sources


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class CPUControlPlane:
    """Only CPU scalar/control collectives; never touch the default NCCL group."""

    def __init__(self, torch, dist, group, progress):
        self.torch, self.dist, self.group, self.progress = torch, dist, group, progress
        self.logged = set()
        if str(dist.get_backend(group)).lower() != "gloo":
            raise RuntimeError("Control-plane group must be Gloo")

    def _begin(self, operation):
        first = operation not in self.logged
        if first:
            self.progress("control_before", operation=operation)
        return first

    def _end(self, operation, first):
        if first:
            self.logged.add(operation)
            self.progress("control_after", operation=operation)

    def any_true(self, value):
        first = self._begin("cpu_all_reduce")
        # Gloo may write from a worker thread outside InferenceMode. Normal
        # CPU buffers avoid inference-tensor mutation restrictions there.
        with self.torch.inference_mode(False):
            tensor = self.torch.tensor([int(value)], dtype=self.torch.int64, device="cpu")
            self.dist.all_reduce(tensor, op=self.dist.ReduceOp.MAX, group=self.group)
        self._end("cpu_all_reduce", first)
        return bool(tensor.item())

    def barrier(self):
        first = self._begin("cpu_barrier")
        self.dist.barrier(group=self.group)
        self._end("cpu_barrier", first)

    def gather_timing(self, values, world):
        first = self._begin("cpu_timing_gather")
        with self.torch.inference_mode(False):
            local = self.torch.tensor(values, device="cpu", dtype=self.torch.float64)
            gathered = [self.torch.empty_like(local) for _ in range(world)]
            self.dist.all_gather(gathered, local, group=self.group)
        self._end("cpu_timing_gather", first)
        return [value.tolist() for value in gathered]
