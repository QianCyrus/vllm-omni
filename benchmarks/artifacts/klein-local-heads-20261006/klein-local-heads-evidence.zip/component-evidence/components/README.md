# Frozen component harness

The Python files are unchanged copies of the measured harness and its CPU layout test. See [the evidence README](../README.md) for the exact environment, public reproduction command, results and limits.
