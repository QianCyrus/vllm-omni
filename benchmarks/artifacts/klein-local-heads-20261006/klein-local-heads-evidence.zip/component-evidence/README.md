# Klein-4B local-TP component benchmark

A real-weight single-stream **block 0** benchmark on **4 × NVIDIA A100-SXM4-40GB**. Inputs are fixed-seed synthetic activations, not captured model activations. This result does not establish whole-model quality, DiT latency, or HTTP latency.

## Environment and workload

- Model: `black-forest-labs/FLUX.2-klein-4B`, revision `e7b7dc27f91deacad38e78976d1f2b499d76a294`.
- vLLM-Omni base: `5f95115e703ffe51e03e40ae23c78ff841c3335e`; candidate: `39a06eac411a377e0bc1eb13bdbceb10c9783bf6`.
- PyTorch `2.13.0+cu130`, vLLM `0.31.0`, Diffusers `0.40.0`, Transformers `5.14.1`, NCCL `2.29.7`.
- BF16, TP4/SP1, native `TORCH_SDPA`; compilation uses `torch.compile(block.forward, dynamic=True)`.
- B1/B4, sequence length 4608, hidden size 3072, 24 attention heads of width 128, MLP width 9216.
- 10 warmups; 30 interleaved rounds; 5 calls per variant per round. Each sample uses the slowest rank. Values below are mean ± sample standard deviation in milliseconds. Rounds share one process launch.

All variants use the candidate framework dependencies. O uses the pinned base block source; A uses the pinned candidate. L/H/M are benchmark-only controls. H/M also change communication and data rearrangement, so their deltas are not pure operator savings and cannot be added.

| Variant | Attention | MLP activation | Gathered output width / calls |
|---|---|---|---|
| O: original | Full heads | Full width | 10D / 2 |
| L: segmented layout control | Full heads | Full width | 10D / 2 |
| H: local heads | Local heads | Full width | 8D / 3 |
| M: local MLP | Full heads | Local width | 7D / 3 |
| A: combined candidate | Local heads | Local width | 5D / 3 |

## Unprofiled block timing

| Lane | Batch | O | L | H | M | A | O → A reduction |
|---|---:|---:|---:|---:|---:|---:|---:|
| Eager | 1 | 5.3171 ± 0.0228 | 6.4118 ± 0.0146 | 4.7697 ± 0.1429 | 4.9750 ± 0.0424 | 3.0844 ± 0.0042 | 41.99% |
| Eager | 4 | 20.3680 ± 0.0129 | 24.6503 ± 0.0218 | 17.9372 ± 0.0172 | 18.8328 ± 0.0131 | 11.4726 ± 0.0126 | 43.67% |
| Compiled | 1 | 4.3357 ± 0.0092 | 5.4855 ± 0.0187 | 3.3886 ± 0.0074 | 4.2180 ± 0.0214 | 2.5294 ± 0.0041 | 41.66% |
| Compiled | 4 | 16.5882 ± 0.0544 | 21.1539 ± 0.0777 | 12.7572 ± 0.0796 | 16.0859 ± 0.0536 | 9.4474 ± 0.0586 | 43.05% |

All 120 recorded output comparisons across four ranks are exact and finite for these block/input cases. Weight row mappings pass, and no new compiler graph was created during timing. These checks do not replace full-model output validation. All variants coexist in memory; this run cannot establish full-model peak memory savings.

## Mechanism seen in the traces

Separate warmed traces contain compiled-region markers and actual PyTorch Flash SDPA GPU kernels. For B4, SDPA inputs change from `[4,24,4608,128]` to `[4,6,4608,128]`.

This table shows kernel-duration sums averaged across four ranks, one profiled call per rank/variant. These are diagnostic timings, not the repeated timing estimator above.

| B4 compiled GPU work | O (ms) | A (ms) |
|---|---:|---:|
| Flash SDPA | 4.8058 | 1.2208 |
| NCCL AllGather | 4.6115 | 2.6253 |
| Q/K RMSNorm | 0.6674 | 0.1738 |
| RoPE | 0.3693 | 0.0933 |
| GEMM | 3.9714 | 3.9683 |

Observed logical gathered output volume is 1080 → 540 MiB per rank/block at B4. This is not measured network traffic. The number of collectives increases from 2 to 3. L is slower because restoring the full segmented tensor adds copies; A avoids reconstructing both full branches. Kernel sums can overlap and must not be added as removable latency.

## Run completion

**All requested measurements and traces completed, but the job did not exit cleanly.** All four ranks wrote `PASS_COMPONENT_ONLY` at about 743 s after completing the final source checks. The wrapper later sent SIGTERM at its 810 s overall deadline; the job exited with code 124, with 848 s total elapsed time including shutdown. The completion record precedes distributed teardown. The retained measurement files pass the independent integrity audit, but the exact cleanup/process-exit stall was not identified. This package does not label the overall job as successful.

## Reproduce

Run inside an allocated four-GPU environment with the versions above. Set `MODEL` to the local model snapshot at the stated revision, `BASE_ROOT` and `CANDIDATE_ROOT` to clean source checkouts at the stated commits, and `OUTPUT` to a new result directory. Install the candidate project and its required dependencies in that environment. An immutable export may be used instead of a clean checkout if it has a matching `COMMIT` marker; verify its source manifest first.

```bash
BASE_SHA=5f95115e703ffe51e03e40ae23c78ff841c3335e
CANDIDATE_SHA=39a06eac411a377e0bc1eb13bdbceb10c9783bf6
MODEL_REVISION=e7b7dc27f91deacad38e78976d1f2b499d76a294
PYTHONPATH="$CANDIDATE_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  python -m torch.distributed.run --standalone --nnodes=1 --nproc-per-node=4 \
  components/bench_components.py \
  --model "$MODEL" --model-revision "$MODEL_REVISION" \
  --baseline-module "$BASE_ROOT/vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py" \
  --candidate-module "$CANDIDATE_ROOT/vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py" \
  --base-sha "$BASE_SHA" --head-sha "$CANDIDATE_SHA" \
  --blocks 0 --batches 1,4 --sequence-length 4608 --seed 8137 \
  --variants O,L,H,M,A --lanes both --mode both \
  --warmups 10 --rounds 30 --calls 5 --profile \
  --deadline-seconds 765 --output "$OUTPUT"
```

The measured run used a 765 s internal deadline and an 810 s outer wrapper budget. For a repeat, reserve enough allocation time for model loading, compilation and clean distributed shutdown; changing the startup/cleanup budget does not change the fixed measured rounds.

To audit these included measurement files on CPU:

```bash
python3 summarize_components.py data --harness-dir components \
  --expected-base-sha "$BASE_SHA" --expected-head-sha "$CANDIDATE_SHA"
python3 components/test_ablation_layout.py
```

The second command is an optional tiny CPU layout test requiring PyTorch; it uses dispatch stubs and simulated collectives. The JSON auditor needs only the Python standard library.

## Files and privacy

`components/*.py` are byte-identical copies of the measured harness sources and its CPU layout test. `data/` retains every rank's raw timing, compiler counters, correctness, weight-loader and collective checks. `trace-mechanism-summary.json` retains per-rank operator shapes and kernel observations without large raw traces. `run-completion.json` records the timeout separately from completed measurements. `SHA256SUMS` covers every included file except itself.

Only publication copies were changed. Private paths were replaced by environment placeholders or checkpoint-relative names; the checkpoint config's original `_name_or_path` field was removed. Model revision, source commits, model tensor content hashes, harness hashes and all numerical values are preserved. `sanitization-manifest.json` records transformations and original/copy hashes. No model weights or binary files are included.
