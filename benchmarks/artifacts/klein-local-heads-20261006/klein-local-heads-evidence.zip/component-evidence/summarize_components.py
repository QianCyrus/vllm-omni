#!/usr/bin/env python3
"""CPU-only integrity audit and O/L/H/M/A component timing summary.

Never changes input evidence. Partial/failed results remain visible but are not
eligible for timing claims. No torch, CUDA, model or network imports.
"""

import argparse
import hashlib
import json
import math
import statistics
from collections import Counter
from pathlib import Path


def stats(values):
    return {"count": len(values), "mean_ms": statistics.mean(values),
            "std_ms": statistics.stdev(values) if len(values) > 1 else 0.0,
            "median_ms": statistics.median(values), "min_ms": min(values), "max_ms": max(values),
            "samples_ms": values}


def summarize(directory, harness_dir=None, expected_base_sha=None, expected_head_sha=None):
    directory = Path(directory)
    errors, warnings, data, failures = [], [], {}, []

    def require(condition, message):
        if not condition:
            errors.append(message)
        return condition

    def read(name, rank, default=None):
        path = directory / f"{name}-rank{rank}.json"
        try:
            return json.loads(path.read_text())
        except (OSError, ValueError) as exc:
            errors.append(f"{path.name}: {exc}")
            return default

    for rank in range(4):
        data[rank] = {name: read(name, rank, {} if name in ("status", "metadata") else [])
                      for name in ("status", "metadata", "loader", "inputs", "correctness",
                                   "collectives", "compiler", "timing")}
        error_file = directory / f"error-rank{rank}.json"
        if error_file.exists():
            failures.append({"rank": rank, "error": json.loads(error_file.read_text())})
        progress = directory / f"progress-rank{rank}.jsonl"
        if progress.exists():
            try:
                data[rank]["last_progress"] = json.loads(progress.read_text().splitlines()[-1])
            except (ValueError, IndexError):
                warnings.append(f"rank {rank}: final progress row is incomplete")
        status = data[rank]["status"]
        require(status.get("status") == "PASS_COMPONENT_ONLY", f"rank {rank}: status is {status.get('status')}")
        require(status.get("native_full_model_quality_proven") is False
                and status.get("service_performance_proven") is False,
                f"rank {rank}: unexpected full-model claim flags")
    metadata = data[0]["metadata"]
    args = metadata.get("args", {})
    timings = []
    if not metadata or not args:
        return {"status": "INVALID_OR_INCOMPLETE", "component_timing_comparison_eligible": False,
                "errors": errors, "failures": failures, "warnings": warnings,
                "last_progress": {rank: value.get("last_progress") for rank, value in data.items()}}

    try:
        variants = args["variants"]
        require(variants and variants[0] == "O" and len(set(variants)) == len(variants)
                and set(variants) <= set("OLHMA"), "Invalid or repeated variants")
        lanes = ["eager", "compiled"] if args["lanes"] == "both" else [args["lanes"]]
        cases = {}
        for block in args["blocks"]:
            for batch in args["batches"]:
                for step in args["steps"] if args.get("captures") else [None]:
                    case = (f"b{batch}-step{step}-block{block}" if step is not None else
                            f"synthetic-b{batch}-s{args['sequence_length']}-block{block}")
                    cases[case] = (block, batch)
        if expected_base_sha:
            require(args["base_sha"] == expected_base_sha, "Declared base SHA differs from expected SHA")
        if expected_head_sha:
            require(args["head_sha"] == expected_head_sha, "Declared head SHA differs from expected SHA")
        require(metadata.get("input_source") == ("captured_native_logical_values" if args.get("captures")
                else "synthetic_inputs_with_real_checkpoint"), "Input provenance mode mismatch")
        if harness_dir:
            for name in ("bench_components.py", "ablation_variants.py", "component_utils.py"):
                digest = hashlib.sha256((Path(harness_dir) / name).read_bytes()).hexdigest()
                require(metadata["hashes"].get(name) == digest, f"Frozen harness hash differs: {name}")
        else:
            warnings.append("No local harness directory supplied: hashes checked across ranks, not against source bytes")
        architecture = metadata["architecture"]
        dim = architecture["num_attention_heads"] * architecture["attention_head_dim"]
        mlp = int(dim * architecture["mlp_ratio"])
        expected_features = {"O": 4*dim+2*mlp, "L": 4*dim+2*mlp, "H": 2*dim+2*mlp,
                             "M": 4*dim+mlp, "A": 2*dim+mlp}
        expected_correctness = Counter()
        for case in cases:
            for variant in variants:
                expected_correctness[case, "eager", f"O-vs-{variant}"] = 1 + int("eager" in lanes)
                if "compiled" in lanes:
                    expected_correctness[case, "compiled", f"O-vs-{variant}"] = 1
            if args.get("captures"):
                expected_correctness[case, "eager", "native-O-vs-harness-O"] = 1
        expected_collectives = Counter((case, variant) for case in cases for variant in variants)
        expected_compiler = Counter((case, lane, "warmup", variant)
                                    for case in cases for lane in lanes for variant in variants)
        if args["mode"] == "both":
            expected_compiler.update((case, lane, "timing", None) for case in cases for lane in lanes)
        expected_timing = Counter((case, lane, variant) for case in cases for lane in lanes for variant in variants
                                  if args["mode"] == "both")

        for rank, records in data.items():
            meta = records["metadata"]
            require(meta.get("rank") == rank and meta.get("world") == 4, f"rank {rank}: metadata identity mismatch")
            for key in ("args", "hashes", "architecture", "versions", "cuda_build", "nccl", "ir_op_priority",
                        "ir_enable_torch_wrap", "compilation", "input_source", "gpu", "gpu_memory_bytes"):
                require(meta.get(key) == metadata.get(key), f"rank {rank}: metadata differs: {key}")
            require(records["inputs"] == data[0]["inputs"], f"rank {rank}: input evidence differs")
            require(Counter(row["case"] for row in records["inputs"]) == Counter(cases.keys()),
                    f"rank {rank}: incomplete/duplicate input cases")
            expected_loader = Counter()
            for block in args["blocks"]:
                weights = read(f"weights-block{block}", rank, {})
                if rank:
                    require(weights == read(f"weights-block{block}", 0, {}), f"rank {rank}: checkpoint provenance differs")
                require(bool(weights), f"rank {rank}: no checkpoint tensor provenance for block {block}")
                expected_loader.update((block, variant, name) for variant in variants for name in weights)
            require(Counter((r["block"], r["variant"], r["name"]) for r in records["loader"]) == expected_loader,
                    f"rank {rank}: incomplete/duplicate weight loader checks")
            require(all(r.get("exact") is True for r in records["loader"]), f"rank {rank}: weight loader failed")
            require(Counter((r["case"], r["lane"], r["comparison"]) for r in records["correctness"]) == expected_correctness,
                    f"rank {rank}: incomplete/duplicate correctness comparisons")
            for row in records["correctness"]:
                metrics = row.get("metrics", {})
                if not require(metrics.get("exact") is True and metrics.get("finite") is True,
                               f"rank {rank}: numerical gate failed: {row['case']}/{row['lane']}/{row['comparison']}"):
                    failures.append({"rank": rank, "comparison": row})
            require(Counter((r["case"], r["variant"]) for r in records["collectives"]) == expected_collectives,
                    f"rank {rank}: incomplete/duplicate collective observations")
            for row in records["collectives"]:
                calls, variant = row["calls"], row["variant"]
                count = 2 if variant in ("O", "L") else 3
                batch = cases[row["case"]][1]
                sequence = calls[0]["input_shape"][1] if args.get("captures") else args["sequence_length"]
                expected_bytes = batch * sequence * expected_features[variant] * 2
                require(row.get("valid") is True and len(calls) == count == row["expected_calls"],
                        f"rank {rank}: collective count/validity mismatch: {row['case']}/{variant}")
                require(row["expected_logical_bytes"] == expected_bytes
                        and sum(call["logical_output_bytes"] for call in calls) == expected_bytes,
                        f"rank {rank}: collective logical volume mismatch: {row['case']}/{variant}")
                for call in calls:
                    require(call["dtype"] == "torch.bfloat16" and call["input_shape"][:2] == [batch, sequence]
                            and call["dimension"] in (-1, 2)
                            and call["logical_output_bytes"] == math.prod(call["input_shape"]) * 2 * 4,
                            f"rank {rank}: invalid collective operand: {row['case']}/{variant}")
            require(records["collectives"] == data[0]["collectives"], f"rank {rank}: collective evidence differs")
            require(Counter((r["case"], r["lane"], r["phase"], r.get("variant")) for r in records["compiler"])
                    == expected_compiler, f"rank {rank}: incomplete/duplicate compiler records")
            graphs_created = 0
            for row in records["compiler"]:
                before = row["before"].get("stats", {}).get("unique_graphs", 0)
                after = row["after"].get("stats", {}).get("unique_graphs", 0)
                if row["lane"] == "compiled" and row["phase"] == "timing":
                    require(before == after, f"rank {rank}: new graph during timing: {row['case']}")
                if row["lane"] == "compiled" and row["phase"] == "warmup":
                    graphs_created += after-before
            if "compiled" in lanes:
                require(graphs_created > 0, f"rank {rank}: no compiler graphs recorded during compiled warmup")
            require(Counter((r["case"], r["lane"], r["variant"]) for r in records["timing"]) == expected_timing,
                    f"rank {rank}: incomplete/duplicate timing records")
            require(records["timing"] == data[0]["timing"], f"rank {rank}: gathered timing copies differ")

        grouped = {}
        for row in data[0]["timing"]:
            key = (row["case"], row["lane"], row["variant"])
            samples = row["samples_per_rank_wall_cuda_ms"]
            require(len(samples) == args["rounds"], f"{key}: wrong timing round count")
            require(all(len(sample) == 4 and all(len(pair) == 2 and all(
                isinstance(value, (int, float)) and math.isfinite(value) and value > 0 for value in pair)
                for pair in sample) for sample in samples), f"{key}: invalid per-rank timing samples")
            schedule = []
            for repeat in range(args["rounds"]):
                order = variants[repeat % len(variants):] + variants[:repeat % len(variants)]
                schedule.append(list(reversed(order)) if repeat % 2 else order)
            require(row["schedule"] == schedule, f"{key}: unexpected variant rotation schedule")
            wall = stats([max(pair[0] for pair in sample) for sample in samples])
            cuda = stats([max(pair[1] for pair in sample) for sample in samples])
            for field, value in (("rank_max_wall_mean_ms", wall["mean_ms"]),
                                 ("rank_max_wall_sd_ms", wall["std_ms"]),
                                 ("rank_max_wall_median_ms", wall["median_ms"]),
                                 ("rank_max_cuda_mean_ms", cuda["mean_ms"])):
                require(math.isclose(row[field], value, rel_tol=1e-9, abs_tol=1e-9), f"{key}: corrupt aggregate {field}")
            grouped[key] = {"case": key[0], "lane": key[1], "variant": key[2], "rank_max_wall": wall,
                            "rank_max_cuda": cuda}
        for key, row in grouped.items():
            for baseline in ("O", "L"):
                reference = grouped.get((key[0], key[1], baseline))
                if reference:
                    row[f"relative_to_{baseline}"] = {
                        metric: {"latency_reduction_pct": 100 * (1-row[metric]["mean_ms"]/reference[metric]["mean_ms"]),
                                 "speedup": reference[metric]["mean_ms"]/row[metric]["mean_ms"]}
                        for metric in ("rank_max_wall", "rank_max_cuda")}
            timings.append(row)
    except (KeyError, TypeError, ValueError, IndexError, OSError, ZeroDivisionError) as exc:
        errors.append(f"Malformed/incomplete evidence: {type(exc).__name__}: {exc}")
    return {
        "status": "PASS_COMPONENT_ONLY" if not errors else "INVALID_OR_INCOMPLETE",
        "component_timing_comparison_eligible": not errors and args.get("mode") == "both" and bool(timings),
        "full_model_performance_or_quality_proven": False,
        "scope": metadata.get("scope"), "input_source": metadata.get("input_source"),
        "base_sha": args.get("base_sha"), "head_sha": args.get("head_sha"),
        "model_revision": args.get("model_revision"), "hardware": metadata.get("gpu"),
        "gpu_memory_bytes": metadata.get("gpu_memory_bytes"), "world": 4,
        "versions": metadata.get("versions"), "hashes": metadata.get("hashes"),
        "errors": errors, "warnings": warnings, "failures": failures, "timings": timings,
        "last_progress": {rank: value.get("last_progress") for rank, value in data.items()},
        "limits": ["All variants use candidate framework dependencies; O uses the pinned baseline block source.",
                   "H/M alter communication and layout as well as compute; reductions are not additive.",
                   "Compiler counters establish graph creation and no new graphs during timing, not kernel attribution.",
                   "Collective receipts are eager logical tensor volumes, not measured network bytes.",
                   "All variants coexist; this run does not establish full-model peak memory savings.",
                   "Within-process rounds are not independent service deployments."],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--harness-dir", type=Path)
    parser.add_argument("--expected-base-sha")
    parser.add_argument("--expected-head-sha")
    parser.add_argument("--output", type=Path, help="Write to a new file; never overwrite evidence")
    args = parser.parse_args()
    report = summarize(args.directory, args.harness_dir, args.expected_base_sha, args.expected_head_sha)
    encoded = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        with args.output.open("x") as stream:
            stream.write(encoded)
    else:
        print(encoded, end="")
    raise SystemExit(0 if report["status"] == "PASS_COMPONENT_ONLY" else 1)


if __name__ == "__main__":
    main()
