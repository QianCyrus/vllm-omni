# Klein-4B native quality comparison

The candidate matched the second baseline process on **93/93 output images**.
The two baseline processes differed on all 25 B1 images and matched on all 68
B4 images. The original O/A/O exact gate therefore remains **failed**
(`NUMERICAL_REVIEW_REQUIRED`). The cause of the baseline variation is unknown.

| Comparison | Exact images | Different images |
|---|---:|---:|
| First baseline O1 vs candidate A | 68 | 25 |
| Second baseline O2 vs candidate A | 93 | 0 |
| First baseline O1 vs second baseline O2 | 68 | 25 |

These counts include square B1/B4 generation, both rectangular B1 cases, one-
and two-reference B1 editing, and seven sentinel images. Each fresh process
handled 42 requests / 93 images, with each corpus case executed once. The native
startup image dummy was unchanged. There were no added boundary hooks, profiler
or synchronizing stage timers in this quality run.

The lowest baseline-to-baseline corpus PSNR was **25.7069 dB**, for
`illustration-seed2026-b1` (RGB8 RMSE 13.2189, maximum absolute difference 255).
The differences are not uniformly small. Candidate-to-O1 metrics equal the
baseline O2-to-O1 metrics because A and O2 are pixel-identical. This is evidence
for these outputs, not a proof of process-level determinism or a broad quality
guarantee. No approximate tolerance was introduced, and no original receipt was
changed. This run does not qualify full-service performance or an end-to-end
speedup. The separate component benchmark has its own scope and limitations.

The test used **4 × NVIDIA A100-SXM4-40GB**, TP4/SP1, BF16, `TORCH_SDPA`, regional
dynamic compilation, no diffusion cache and VAE tile/1 with the fast path off.
PyTorch was `2.13.0+cu130`, vLLM `0.31.0`, Diffusers `0.40.0`, Transformers
`5.14.1`, and Pillow `12.3.0`. vLLM-Omni code identity is given by the tested
source commits:

- Base: `5f95115e703ffe51e03e40ae23c78ff841c3335e`.
- Candidate: `39a06eac411a377e0bc1eb13bdbceb10c9783bf6`.
- Model: `black-forest-labs/FLUX.2-klein-4B`, revision
  `e7b7dc27f91deacad38e78976d1f2b499d76a294`.

`image-comparisons.json` contains 93 per-image PNG and decoded RGB hash records,
all three exactness comparisons, and the existing error metrics for all 86
corpus images. The seven sentinels have hash comparisons; no extra metric run was
added for them. SSIM was not computed. A null PSNR for an exact pair represents
zero MSE / infinite PSNR, not a missing comparison.

`source-and-config-assurance.json` records selected source, model-config and
startup-validation facts, plus hashes of the original receipts. It is a
sanitized summary, not the original qualification file. Full relative-path
source manifests are included. The frozen quality harness, fixed prompts,
synthetic editing fixtures and external comparator were copied byte-for-byte.
Generated output PNGs and HTTP response bodies are omitted; hashes alone cannot
recompute the historical image metrics. No private paths, cluster account
identifiers or GPU UUIDs are included.

To check the package without a GPU:

```sh
sha256sum -c SHA256SUMS
python quality_harness/bundle_integrity.py
```

To reproduce, use a checkout containing both tested commits and the exact model
revision. Set `EVIDENCE` to this directory, `PYTHON` to the matching environment,
`BASE_EXPORT` and `CANDIDATE_EXPORT` to clean git-archive exports, `MODEL_SNAPSHOT`
to the model directory, and `OUTPUT` to a new output directory. Each source export
needs a `COMMIT` text file containing its full tested SHA; this marker is excluded
from source-file hashing. Keep generated files outside the exports. The included
manifests are checked against every exported file before and after each run.

The frozen launcher requires a real PJM allocation. Use one allocation with four
A100 GPUs, a fresh node-local `/tmp` cache parent, and sequential service starts.
Do not fabricate `PJM_JOBID` to bypass this check. `commands.json` also contains
the exact server/client argument lists with named path placeholders, for
adapting the experiment to another scheduler.

```sh
BASE_SHA=5f95115e703ffe51e03e40ae23c78ff841c3335e
CANDIDATE_SHA=39a06eac411a377e0bc1eb13bdbceb10c9783bf6
NODE_LOCAL=/tmp/klein-quality-reproduction

for ARM in 01-O 02-A 03-O; do
  SOURCE="$BASE_EXPORT"
  SOURCE_SHA="$BASE_SHA"
  MANIFEST="$EVIDENCE/source-manifests/base-manifest.json"
  VARIANT=O
  if [ "$ARM" = 02-A ]; then
    SOURCE="$CANDIDATE_EXPORT"
    SOURCE_SHA="$CANDIDATE_SHA"
    MANIFEST="$EVIDENCE/source-manifests/candidate-manifest.json"
    VARIANT=A
  fi
  "$PYTHON" "$EVIDENCE/quality_harness/launch_native.py" \
    --source-root "$SOURCE" --source-sha "$SOURCE_SHA" \
    --source-manifest "$MANIFEST" --model "$MODEL_SNAPSHOT" \
    --output "$OUTPUT/$ARM" --cache-root "$NODE_LOCAL/arms" \
    --arm "$ARM" --variant "$VARIANT" --tensor-parallel-size 4 \
    --port 8091 --compile-mode regional --batches 1 4 \
    --warmup 0 --repeats 1 --steps 4 --diagnostic --edit-batches 1 \
    --quality-corpus "$EVIDENCE/quality_harness/quality_tools/data/square.json" \
    --startup-timeout 650 --run-timeout 700 || exit "$?"
done

"$PYTHON" "$EVIDENCE/analysis_tools/compare_quality_oao.py" \
  --o1 "$OUTPUT/01-O" --candidate "$OUTPUT/02-A" --o2 "$OUTPUT/03-O" \
  --harness "$EVIDENCE/quality_harness" \
  --base-manifest "$EVIDENCE/source-manifests/base-manifest.json" \
  --candidate-manifest "$EVIDENCE/source-manifests/candidate-manifest.json" \
  --output "$OUTPUT/comparison"
```

Add `--check` to each launcher invocation first to verify files and commands
without starting a server. An allocation coordinator must enforce the overall
budget and retain partial failures; the example per-arm limits are not a promise
that a full run will fit any particular allocation. The comparator returns 0
only when every tested image and applicable repeat control is exact, 2 when
valid evidence contains numerical differences, and an error for invalid or
incomplete evidence. It does not qualify performance. The reported historical
run returned 2 and its failed gate remains unchanged.
