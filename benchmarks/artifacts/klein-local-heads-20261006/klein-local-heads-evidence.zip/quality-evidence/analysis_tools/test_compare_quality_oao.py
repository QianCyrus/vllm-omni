"""CPU fixtures exercise the real frozen HTTP client and external exact gate."""

import base64
import email.parser
import email.policy
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import compare_quality_oao as check

ROOT = Path(__file__).resolve().parent
HARNESS = ROOT.parent / "quality_harness"


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


class QualityGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (ROOT / ".selftest").mkdir(exist_ok=True)
        cls.temp = tempfile.TemporaryDirectory(dir=ROOT / ".selftest")
        cls.root = Path(cls.temp.name)
        cls.modules = check.load_modules(HARNESS)
        cls.base_sha, cls.head_sha = "a" * 40, "b" * 40
        cls.base_manifest, cls.head_manifest = cls.root / "base.json", cls.root / "head.json"
        for path, head in ((cls.base_manifest, cls.base_sha), (cls.head_manifest, cls.head_sha)):
            write(path, {"schema_version": 2, "base_sha": cls.base_sha, "head_sha": head,
                         "files": {check.MODEL_MODULE: head[0] * 64, check.WORKER_MODULE: "c" * 64}})

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                from PIL import Image
                raw = self.rfile.read(int(self.headers["Content-Length"]))
                if self.path.endswith("generations"):
                    fields = json.loads(raw)
                else:
                    parsed = email.parser.BytesParser(policy=email.policy.default).parsebytes(
                        ("Content-Type: " + self.headers["Content-Type"] + "\r\nMIME-Version: 1.0\r\n\r\n").encode() + raw)
                    fields = {part.get_param("name", header="content-disposition"): part.get_content().strip()
                              for part in parsed.iter_parts() if part.get_param("name", header="content-disposition") != "image"}
                width, height = map(int, fields["size"].split("x"))
                data = []
                for index in range(int(fields["n"])):
                    buffer = io.BytesIO()
                    image = Image.new("RGB", (width, height), (41, index * 20, 83))
                    image.putpixel((0, 0), (101, 151, 201))
                    image.save(buffer, format="PNG")
                    data.append({"b64_json": base64.b64encode(buffer.getvalue()).decode()})
                result = json.dumps({"data": data}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(result)))
                self.end_headers()
                self.wfile.write(result)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            original = cls.root / "client"
            original.mkdir()
            command = [sys.executable, str(HARNESS / "bench_tp_service.py"), "--base-url", f"http://127.0.0.1:{server.server_port}",
                       "--output", str(original / "http"), "--arm", "O1", "--source-sha", cls.base_sha,
                       "--warmup", "0", "--repeats", "1", "--batches", "1", "4", "--steps", "4", "--diagnostic",
                       "--quality-corpus", str(HARNESS / "quality_tools/data/square.json"), "--edit-batches", "1"]
            result = subprocess.run(command, capture_output=True, text=True, timeout=90, env=os.environ.copy())
            if result.returncode:
                raise AssertionError(result.stderr)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()
        cls.template = cls.root / "template"
        cls.template.mkdir()
        for index, (name, variant) in enumerate((("O1", "O"), ("A", "A"), ("O2", "O"))):
            path = cls.template / name
            shutil.copytree(original, path)
            cls.complete_server_receipts(path, name, variant, index, command)

    @classmethod
    def complete_server_receipts(cls, path, name, variant, index, command):
        source_sha = cls.head_sha if variant == "A" else cls.base_sha
        manifest_path = cls.head_manifest if variant == "A" else cls.base_manifest
        manifest = check.read(manifest_path)
        session = check.read(path / "quality/session.json")
        start, end = index * 100 + 1, index * 100 + 99
        session.update(arm=name, source_sha=source_sha, started_unix_s=start + 10, ended_unix_s=end - 10)
        for phase, relative in cls.modules.session.PHASES.items():
            directory = path / relative
            cm = check.read(directory / "metadata.json")
            cm.update(arm=name, source_sha=source_sha)
            write(directory / "metadata.json", cm)
            rows = [json.loads(line) for line in (directory / "requests.jsonl").read_text().splitlines()]
            for row in rows:
                row["arm"] = name
            (directory / "requests.jsonl").write_text("".join(json.dumps(row) + "\n" for row in rows))
        write(path / "quality/session.json", session)
        root = Path("/tmp/cpu-fixture-source") / variant
        for rank in range(4):
            local, heads = variant == "A", 6 if variant == "A" else 24
            receipt = {"status": "PASS", "rank": rank, "tp_rank": rank, "world_size": 4, "tp_world_size": 4,
                       "source_sha": source_sha, "module_sha256": manifest["files"][check.MODEL_MODULE],
                       "module_file": str(root / check.MODEL_MODULE), "hook_sha256": cls.modules.frozen["hooks/sitecustomize.py"],
                       "variant": variant, "compile_mode": "regional", "load_model_complete": True,
                       "blocks": [{"index": i, "global_heads": 24, "local_tp": local, "query_num_heads": heads,
                                   "attention_num_heads": heads} for i in range(20)],
                       "compile": {"single_block_wrappers": [True] * 20, "double_block_wrappers": [True] * 5},
                       "worker": {"ir_priority_resolved_by_native_worker": True, "worker_module_sha256": manifest["files"][check.WORKER_MODULE],
                                  "ir_op_priority": {}, "gpu_name": "CPU test fixture only", "gpu_memory_bytes": 0,
                                  "torch_version": "fixture", "torch_cuda_version": "fixture", "cudnn_version": 0,
                                  "matmul_allow_tf32": False, "cudnn_allow_tf32": False, "float32_matmul_precision": "highest"}}
            write(path / f"startup_activation/rank{rank}.json", receipt)
        proof = cls.modules.proofs.verify_startup_proofs(path / "startup_activation", root, source_sha,
                    manifest["files"][check.MODEL_MODULE], variant, cls.modules.frozen["hooks/sitecustomize.py"], 4, "regional")
        proof["verified_before_client_unix_s"] = start + 5
        command = list(command)
        command[command.index("--arm") + 1] = name
        command[command.index("--source-sha") + 1] = source_sha
        command[command.index("--output") + 1] = str(path / "http")
        meta = {"arm": name, "variant": variant, "status": "PASS", "source_unchanged": True, "cleanup_complete": True,
                "startup_proof_unchanged": True, "scored": False, "diagnostic": True, "source_sha": source_sha,
                "source_base_sha": cls.base_sha, "source_patch_sha256": None, "source_sha256": manifest["files"],
                "source_manifest_sha256": check.sha(manifest_path), "quality_bundle_sha256": cls.modules.frozen,
                "quality_bundle_manifest_sha256": check.sha(HARNESS / "BUNDLE_MANIFEST.json"),
                "launcher_sha256": cls.modules.frozen["launch_native.py"], "client_sha256": cls.modules.frozen["bench_tp_service.py"],
                "startup_hook_sha256": {"sitecustomize.py": cls.modules.frozen["hooks/sitecustomize.py"]},
                "quality_session": session, "quality_session_sha256": check.sha(path / "quality/session.json"),
                "startup_activation": proof, "compile_mode": "regional", "parallelism": {"tp": 4, "sp": 1, "dp": 1, "pp": 1, "cfg": 1},
                "dtype": "bfloat16", "attention_backend": "TORCH_SDPA", "cache_backend": "none", "vae_mode": "tile", "vae_degree": 1,
                "model_revision": check.read(HARNESS / "quality_tools/data/manifest.json")["model_revision"],
                "model_config_sha256": {"fixture": "d" * 64}, "versions": {"fixture": "CPU only"},
                "server_command": ["CPU", "fixture"], "client_command": command, "native_image_dummy": "unchanged",
                "pjm_job_id": "CPU-fixture-not-a-job", "started_unix_s": start, "ended_unix_s": end}
        write(path / "metadata.json", meta)
        write(path / "validation.json", {key: meta[key] for key in ("status", "scored", "diagnostic", "source_unchanged", "cleanup_complete")})

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.local = tempfile.TemporaryDirectory(dir=self.root)
        self.run = Path(self.local.name)
        for name in ("O1", "A", "O2"):
            shutil.copytree(self.template / name, self.run / name)

    def tearDown(self):
        self.local.cleanup()

    def analyze(self):
        return check.analyze(self.run / "O1", self.run / "A", self.run / "O2", HARNESS,
                             self.base_manifest, self.head_manifest, self.run / "analysis")

    def test_exact_triangle(self):
        report = self.analyze()
        self.assertTrue(report["quality_exact_gate_passed"])
        self.assertFalse(report["historical_unstable_control_resolved"])
        self.assertEqual(report["kind"], "native_quality_oao_exact")
        self.assertTrue(all(value["images_including_sentinels"] == 93 for value in report["comparisons"].values()))

    def test_nonexact_sentinel_blocks_gate(self):
        from PIL import Image
        directory = self.run / "A/http"
        path = directory / "requests.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        item = rows[0]["images"][0]
        file = directory / item["file"]
        with Image.open(file) as image:
            changed = image.convert("RGB")
        changed.putpixel((5, 5), (255, 255, 255))
        changed.save(file, format="PNG")
        item["pixel_sha256"] = hashlib.sha256(changed.tobytes()).hexdigest()
        item["saved_png_sha256"] = item["response_image_sha256"] = check.sha(file)
        path.write_text("".join(json.dumps(row) + "\n" for row in rows))
        summary = check.read(directory / "summary.json")
        summary["1"]["ordered_pixel_sha256"] = [item["pixel_sha256"]]
        write(directory / "summary.json", summary)
        report = self.analyze()
        self.assertFalse(report["quality_exact_gate_passed"])
        self.assertTrue(report["comparisons"]["O1-O2"]["exact"])
        self.assertEqual(report["comparisons"]["O1-A"]["phases"]["square"]["different_request_labels"], ["b1-sample-00"])

    def test_wrong_source_sha(self):
        path = self.run / "A/metadata.json"
        value = check.read(path)
        value["source_sha"] = "e" * 40
        write(path, value)
        with self.assertRaisesRegex(ValueError, "source SHA"):
            self.analyze()

    def test_wrong_configuration(self):
        path = self.run / "A/metadata.json"
        value = check.read(path)
        value["dtype"] = "float32"
        write(path, value)
        with self.assertRaisesRegex(ValueError, "numerical execution"):
            self.analyze()

    def test_png_tamper(self):
        path = next((self.run / "O1/http/images").glob("*.png"))
        path.write_bytes(path.read_bytes() + b"tampered")
        with self.assertRaisesRegex(ValueError, "Image file changed"):
            self.analyze()

    def test_partial_session(self):
        path = self.run / "O1"
        session = check.read(path / "quality/session.json")
        session["phases"].pop()
        write(path / "quality/session.json", session)
        meta = check.read(path / "metadata.json")
        meta.update(quality_session=session, quality_session_sha256=check.sha(path / "quality/session.json"))
        write(path / "metadata.json", meta)
        with self.assertRaisesRegex(ValueError, "Partial phase"):
            self.analyze()


if __name__ == "__main__":
    unittest.main(verbosity=2)
