# Exact O/A/O quality analysis

The frozen `quality_harness/` is unchanged. This separate CPU analysis tool reads
three completed native quality arms in O1/A/O2 order, verifies their evidence and
compares all returned images. It does not launch a model or submit a job.

```sh
python analysis_tools/compare_quality_oao.py \
  --o1 "$RUN/quality/01-O" \
  --candidate "$RUN/quality/02-A" \
  --o2 "$RUN/quality/03-O" \
  --harness "$PAYLOAD/quality_harness" \
  --base-manifest "$PAYLOAD/base-manifest.json" \
  --candidate-manifest "$PAYLOAD/candidate-manifest.json" \
  --output "$RUN/quality-analysis"
```

Output must be a new directory outside the raw arm directories. Pillow and NumPy
are required. Optional `--ssim` adds the frozen comparator's skimage SSIM metric;
it never changes the exact acceptance rule.

The tool validates the frozen bundle, complete source-manifest maps, constructor
and native-worker receipts, configured regional compilation, matching runtime
and model configuration, session completion and script hashes, fixed corpus
payloads, all sentinel rows, and every saved PNG and decoded pixel hash. It also
reconstructs each editing multipart request, checks input fixtures and rehashes
raw editing responses against their output PNGs. Generation response JSON is
not retained by the frozen client; its saved response image bytes are checked,
but its raw response JSON hash cannot independently be revalidated.

Each arm must contain exactly 42 requests / 93 images, including the four
sentinel requests / seven images. The existing phase comparator supplies metrics
for 86 corpus images. This analyzer additionally checks all seven sentinel
images in O1/A, O2/A and O1/O2. Identical-payload repeats within each arm are also
checked when present; the default frozen corpus normally has none, so this
check says NOT_APPLICABLE rather than inventing repeat evidence.

`qualification.json` uses `kind="native_quality_oao_exact"` and
`quality_exact_gate_passed=true` only when every tested image is pixel-exact in
all three comparisons and any within-arm duplicate-payload controls are exact.
Exit code 0 denotes this limited exact pass. Exit code 2 denotes valid evidence
with a numerical difference. Invalid or incomplete evidence raises an error
and produces no positive qualification. Neither return status qualifies timing.

The receipt records `base_sha`, `candidate_sha`, analysis/bundle/input hashes and
the raw evidence file hashes under relative paths for each arm. Input-file names
are logical filenames for the preserved input artifacts, not proof those files
were copied to the analysis output. Preserve them and the exact receipt together
before a separate formal-scoring coordinator checks the gate. This is a new
quality receipt, never a fabricated `run_native.py` pilot qualification.

Earlier uninstrumented baseline process variation remains documented through
`historical_unstable_control_resolved=false`, including when this corpus passes.
Later agreement does not explain its cause or establish global determinism.
All statements remain limited to this fixed three-arm corpus and its sentinels.
Floating-point intermediate equality, broad visual quality and performance are
not certified by decoded PNG agreement.

CPU tests exercise the real frozen client against an HTTP stub and attach
explicitly synthetic server receipts. They test exact/nonexact triangles,
including a sentinel-only difference, source/configuration failures, a modified
PNG and a self-consistent but incomplete phase session. They are harness tests,
not model evidence.
