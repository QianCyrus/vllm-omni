#!/usr/bin/env python3
"""Qualify a frozen native O/A/O quality corpus using an exact-only gate.

This is an external analysis receipt, not a run_native.py qualification.
Historical baseline process variation remains unresolved even if this passes.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import sys
from pathlib import Path

MODEL_MODULE = "vllm_omni/diffusion/models/flux2_klein/flux2_klein_transformer.py"
WORKER_MODULE = "vllm_omni/diffusion/worker/diffusion_worker.py"
COMMON = ("quality_bundle_sha256", "quality_bundle_manifest_sha256", "compile_mode", "parallelism",
          "dtype", "attention_backend", "cache_backend", "vae_mode", "vae_degree", "model_revision",
          "model_config_sha256", "versions", "server_command", "native_image_dummy", "pjm_job_id")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def read(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def flag(command, name, default=None):
    return command[command.index(name) + 1] if name in command else default


def load_modules(harness):
    # Imports must resolve from the explicitly selected, subsequently hash-checked bundle.
    harness = Path(harness).resolve()
    sys.path.insert(0, str(harness))
    import bundle_integrity
    import compare_session
    import proof_validation
    from quality_tools import compare_quality, edit_regression
    for module in (bundle_integrity, compare_session, proof_validation, compare_quality, edit_regression):
        require(Path(module.__file__).resolve().is_relative_to(harness), "Analysis imported a different harness")
    frozen = bundle_integrity.verify(harness)
    return argparse.Namespace(root=harness, frozen=frozen, bundle=bundle_integrity, session=compare_session,
                              proofs=proof_validation, quality=compare_quality, edits=edit_regression)


def inspect_arm(path, variant, manifest_path, modules):
    path = Path(path).resolve()
    meta = modules.session.inspect(path)
    manifest = read(manifest_path)
    require(manifest.get("schema_version") == 2, "Require full source manifest v2")
    require(re.fullmatch("[0-9a-f]{40}", manifest.get("head_sha", "")), "Invalid source SHA")
    require(meta.get("variant") == variant and meta.get("source_sha") == manifest["head_sha"], "Wrong arm/source SHA")
    require(meta.get("source_sha256") == manifest["files"] and meta.get("source_manifest_sha256") == sha(manifest_path),
            "Server full source manifest mismatch")
    require(meta.get("source_base_sha") == manifest.get("base_sha"), "Wrong source base SHA")
    require(meta.get("source_patch_sha256") == manifest.get("patch_sha256"), "Wrong source patch SHA")
    require(meta.get("quality_bundle_sha256") == modules.frozen and
            meta.get("quality_bundle_manifest_sha256") == sha(modules.root / "BUNDLE_MANIFEST.json"), "Frozen bundle mismatch")
    for field, filename in (("launcher_sha256", "launch_native.py"), ("client_sha256", "bench_tp_service.py")):
        require(meta.get(field) == modules.frozen[filename], "Wrong executed " + field)
    require(meta.get("startup_hook_sha256") == {name.removeprefix("hooks/"): value for name, value in modules.frozen.items()
            if name.startswith("hooks/") and name.endswith(".py")}, "Wrong startup hook hashes")
    require(meta.get("model_revision") == read(modules.root / "quality_tools/data/manifest.json")["model_revision"],
            "Model revision differs from frozen corpus")
    require(flag(meta["client_command"], "--source-sha") == meta["source_sha"]
            and flag(meta["client_command"], "--arm") == meta["arm"], "Client command source/arm mismatch")
    require(meta.get("diagnostic") is True and meta.get("scored") is False, "Quality arm is not diagnostic")
    require(not any(meta.get(key) for key in ("profile_dir", "stage_metrics_enabled", "diagnostic_hook_sha256",
                "capture_environment", "optimization_environment")), "Instrumented or selected quality arm")
    require(meta.get("compile_mode") == "regional" and meta.get("parallelism") ==
            {"tp": 4, "sp": 1, "dp": 1, "pp": 1, "cfg": 1}, "Wrong native compile/parallel configuration")
    require(meta.get("dtype") == "bfloat16" and meta.get("attention_backend") == "TORCH_SDPA"
            and meta.get("cache_backend") == "none" and meta.get("vae_mode") == "tile" and meta.get("vae_degree") == 1,
            "Wrong numerical execution configuration")
    require(read(path / "validation.json") == {key: meta[key] for key in
            ("status", "scored", "diagnostic", "source_unchanged", "cleanup_complete")}, "Launcher validation disagrees")
    session = meta["quality_session"]
    require(session.get("arm") == meta["arm"] and session.get("source_sha") == meta["source_sha"]
            and session.get("scored") is False and session.get("bundle_unchanged") is True, "Session identity mismatch")
    require(session.get("scripts_sha256") == {name: value for name, value in modules.frozen.items() if name.endswith(".py")}
            and session.get("bundle_manifest_sha256") == meta["quality_bundle_manifest_sha256"], "Session script receipt mismatch")
    require([entry.get("phase") for entry in session.get("phases", [])] == list(modules.session.PHASES)
            and all(entry.get("status") == "PASS" for entry in session["phases"]), "Partial phase session")
    require(session.get("editing_batches") == [1] and session.get("editing_repeats") == 1, "Require frozen default B1 edit lane")
    for key, expected in (("actual_generation_requests", 40), ("actual_generation_images", 91),
                          ("corpus_generation_requests", 36), ("corpus_generation_images", 84),
                          ("actual_total_requests", 42), ("actual_total_images", 93)):
        require(session.get(key) == expected, "Wrong traffic count: " + key)
    first = read(path / "startup_activation/rank0.json")
    source_root = Path(first["module_file"])
    for _ in Path(MODEL_MODULE).parts:
        source_root = source_root.parent
    proof = modules.proofs.verify_startup_proofs(path / "startup_activation", source_root, meta["source_sha"],
        manifest["files"][MODEL_MODULE], variant, modules.frozen["hooks/sitecustomize.py"], 4, "regional")
    saved = meta.get("startup_activation", {})
    require(proof["files_sha256"] == saved.get("files_sha256") and proof["records"] == saved.get("records"),
            "Startup raw receipts changed after launch")
    for record in proof["records"]:
        require(record.get("worker", {}).get("worker_module_sha256") == manifest["files"][WORKER_MODULE],
                "Native worker source differs")
        require(record.get("compile", {}).get("double_block_wrappers") == [True] * 5, "Double blocks not configured compiled")
    require(meta.get("started_unix_s", 0) < meta.get("ended_unix_s", 0), "Invalid server lifetime")
    require(saved.get("verified_before_client_unix_s", 0) <= session["started_unix_s"] <= session["ended_unix_s"]
            <= meta["ended_unix_s"], "Client/session outside verified service lifetime")
    return meta


def validate_generation(arm, relative, corpus_name, meta, modules):
    directory = arm / relative
    cm = read(directory / "metadata.json")
    rows = [json.loads(line) for line in (directory / "requests.jsonl").read_text().splitlines()]
    corpus_path = modules.root / "quality_tools/data" / corpus_name
    corpus = read(corpus_path)["cases"]
    batches = [1, 4] if corpus_name == "square.json" else [1]
    width, height = map(int, corpus[0]["payload"]["size"].split("x"))
    require(cm.get("source_sha") == meta["source_sha"] and cm.get("arm") == meta["arm"], "Generation source/arm mismatch")
    require(cm.get("client_sha256") == modules.frozen["bench_core.py"] and cm.get("quality_corpus_sha256") == sha(corpus_path),
            "Generation client/corpus hash mismatch")
    require(cm.get("batches") == batches and cm.get("warmup_per_batch") == 0 and cm.get("repeats_per_batch") == 1
            and cm.get("diagnostic") is True and cm.get("concurrency") == 1 and not cm.get("profile_batches")
            and not cm.get("capture_arm_file") and cm.get("quality_corpus_requests") == len(corpus), "Wrong generation controls")
    val = read(directory / "validation.json")
    require(val.get("status") == "PASS" and val.get("scored") is False and val.get("requests_completed") == len(rows),
            "Generation validation mismatch")
    phase = "square" if corpus_name == "square.json" else corpus_name.removesuffix(".json")
    receipt = next(item for item in meta["quality_session"]["phases"] if item["phase"] == phase)
    require(receipt.get("validation") == val and receipt.get("corpus_sha256") == sha(corpus_path)
            and (receipt.get("width"), receipt.get("height")) == (width, height), "Generation phase receipt mismatch")
    command = meta["client_command"]
    require(flag(command, "--warmup") == "0" and flag(command, "--repeats") == "1"
            and flag(command, "--steps") == "4" and "--diagnostic" in command, "Wrong client command")
    from bench_core import PROMPT
    expected = []
    for batch in batches:
        payload = dict(corpus[0]["payload"], prompt=flag(command, "--prompt", PROMPT),
                       seed=int(flag(command, "--seed", 8137)), n=batch, size=f"{width}x{height}")
        expected.append((f"b{batch}-sample-00", payload, False))
    expected.extend(("quality-" + item["case_id"], item["payload"], True) for item in corpus)
    require([row["label"] for row in rows] == [item[0] for item in expected], "Missing/extra/reordered generation requests")
    checked = {}
    for row, (label, payload, correctness) in zip(rows, expected):
        require(row.get("payload") == payload and row.get("payload_sha256") == hashlib.sha256(canonical(payload)).hexdigest(),
                "Generation payload differs: " + label)
        require(row.get("arm") == meta["arm"] and row.get("batch") == payload["n"] and row.get("http_status") == 200
                and row.get("scored") is False and row.get("warmup") is False and row.get("profiled") is False
                and row.get("correctness_only") is correctness, "Generation row/control mismatch")
        require(len(row["images"]) == payload["n"], "Wrong generation output count")
        hashes = []
        for index, item in enumerate(row["images"]):
            require(item["index"] == index and (item["width"], item["height"]) == (width, height), "Wrong image shape/order")
            modules.quality.pixels(directory, item)
            require(item.get("response_image_sha256") == item.get("saved_png_sha256"), "Response image hash differs")
            hashes.append(item["pixel_sha256"])
        checked[label] = {"payload_sha256": row["payload_sha256"], "pixels": hashes}
    summary = read(directory / "summary.json")
    for batch in batches:
        require(summary[str(batch)].get("ordered_pixel_sha256") == checked[f"b{batch}-sample-00"]["pixels"]
                and summary[str(batch)].get("scored") is False, "Sentinel summary differs from images")
    return checked


def validate_edits(arm, meta, modules):
    directory = arm / "quality/edits"
    cm, _ = modules.quality.read_run(directory, "edit")
    require(cm.get("source_sha") == meta["source_sha"] and cm.get("arm") == meta["arm"]
            and cm.get("client_sha256") == modules.frozen["quality_tools/edit_regression.py"], "Edit identity mismatch")
    require(cm.get("fixture_manifest_sha256") == modules.frozen["quality_tools/data/manifest.json"]
            and cm.get("batches") == [1] and cm.get("input_counts") == [1, 2] and cm.get("repeats") == 1
            and cm.get("requests") == 2 and cm.get("images") == 2 and cm.get("scored") is False, "Edit controls mismatch")
    phase = meta["quality_session"]["phases"][-1]
    require(phase.get("requests") == 2 and phase.get("images") == 2, "Edit phase receipt mismatch")
    manifest, fixtures = modules.edits.load_fixtures(directory / "inputs")
    require(manifest == read(modules.root / "quality_tools/data/manifest.json"), "Copied edit fixture manifest differs")
    rows = [json.loads(line) for line in (directory / "requests.jsonl").read_text().splitlines()]
    require([row.get("case_id") for row in rows] == [f"edit-input{count}-b1-seed8137" for count in (1, 2)], "Edit coverage/order mismatch")
    checked = {}
    for count, row in zip((1, 2), rows):
        fields = {"model": "klein-local-heads-bench", "prompt": modules.edits.PROMPT, "n": "1", "size": "1024x1024",
                  "num_inference_steps": "4", "guidance_scale": "1.0", "seed": "8137", "generator_device": "cpu",
                  "response_format": "b64_json", "output_format": "png", "output_compression": "100", "return_stage_metrics": "true"}
        body, content_type, identity = modules.edits.multipart(fields, fixtures[:count])
        case = row["case_id"]
        saved_identity = read(directory / f"requests/{case}.json")
        body_sha = hashlib.sha256(body).hexdigest()
        require(saved_identity == {**identity, "multipart_sha256": body_sha, "content_type": content_type}
                and (directory / f"requests/{case}.multipart.bin").read_bytes() == body, "Edit multipart/raw request differs")
        require(row.get("request_sha256") == hashlib.sha256(canonical(identity)).hexdigest()
                and row.get("multipart_sha256") == body_sha and row.get("input_count") == count and row.get("repeat") == 0
                and row.get("batch") == 1 and row.get("http_status") == 200 and row.get("scored") is False
                and row.get("arm") == meta["arm"], "Edit row mismatch")
        response = directory / row["response_file"]
        require(response.resolve().is_relative_to((directory / "responses").resolve()), "Response escaped evidence directory")
        require(sha(response) == row["response_sha256"], "Edit raw response hash differs")
        response_images = read(response).get("data", [])
        require(len(response_images) == len(row["images"]) == 1, "Edit raw response image count differs")
        item = row["images"][0]
        require(item["index"] == 0 and (item["width"], item["height"]) == (1024, 1024), "Wrong edit image shape/order")
        modules.quality.pixels(directory, item)
        encoded = base64.b64decode(response_images[0]["b64_json"], validate=True)
        require(hashlib.sha256(encoded).hexdigest() == item["png_sha256"], "Edit raw response image differs from PNG")
        checked[case] = {"payload_sha256": row["request_sha256"], "pixels": [item["pixel_sha256"]]}
    return checked


def analyze(o1, candidate, o2, harness, base_manifest, candidate_manifest, output, ssim=False):
    modules = load_modules(harness)
    paths = {"O1": Path(o1).resolve(), "A": Path(candidate).resolve(), "O2": Path(o2).resolve()}
    require(len(set(paths.values())) == 3, "Require three distinct service arms")
    metadata, records = {}, {}
    for name, path in paths.items():
        metadata[name] = inspect_arm(path, "A" if name == "A" else "O",
                                     candidate_manifest if name == "A" else base_manifest, modules)
        records[name] = {}
        for phase, relative in modules.session.PHASES.items():
            records[name][phase] = validate_edits(path, metadata[name], modules) if phase == "edits" else validate_generation(
                path, relative, phase + ".json", metadata[name], modules)
    require(read(candidate_manifest)["base_sha"] == read(base_manifest)["head_sha"], "Candidate is not based on tested base")
    for name in ("A", "O2"):
        for key in COMMON:
            require(metadata["O1"].get(key) == metadata[name].get(key), "Unmatched execution setting: " + key)
        for rank in range(4):
            a = metadata["O1"]["startup_activation"]["records"][rank]["worker"]
            b = metadata[name]["startup_activation"]["records"][rank]["worker"]
            for key in ("ir_op_priority", "gpu_name", "gpu_memory_bytes", "torch_version", "torch_cuda_version",
                        "cudnn_version", "matmul_allow_tf32", "cudnn_allow_tf32", "float32_matmul_precision"):
                require(key in a and a.get(key) == b.get(key), "Worker settings differ: " + key)
    require(metadata["O1"]["ended_unix_s"] <= metadata["A"]["started_unix_s"]
            and metadata["A"]["ended_unix_s"] <= metadata["O2"]["started_unix_s"], "Service arms were not sequential O/A/O")
    output = Path(output).resolve()
    require(not any(output.is_relative_to(path) or path.is_relative_to(output) for path in paths.values()), "Output overlaps raw arms")
    output.mkdir(parents=True, exist_ok=False)
    comparisons = {}
    for left, right in (("O1", "A"), ("O2", "A"), ("O1", "O2")):
        key = left + "-" + right
        details, exact, images = {}, True, 0
        for phase, relative in modules.session.PHASES.items():
            report = modules.quality.compare(paths[left] / relative, paths[right] / relative,
                                             "edit" if phase == "edits" else "generation", ssim)
            require(report["base_sha"] == metadata[left]["source_sha"] and report["candidate_sha"] == metadata[right]["source_sha"],
                    "Phase comparison source mismatch")
            (output / f"{key}-{phase}.json").write_text(json.dumps(report, indent=2) + "\n")
            a, b = records[left][phase], records[right][phase]
            require(a.keys() == b.keys(), "Different all-request coverage")
            differences = []
            for label in a:
                require(a[label]["payload_sha256"] == b[label]["payload_sha256"], "Cross-arm request differs")
                images += len(a[label]["pixels"])
                if a[label]["pixels"] != b[label]["pixels"]:
                    differences.append(label)
            exact &= not differences
            details[phase] = {"requests_including_sentinels": len(a), "different_request_labels": differences,
                              "corpus_images": report["images"], "corpus_exact_images": report["exact_images"]}
        require(images == 93, "All-image exact gate did not cover 93 images")
        comparisons[key] = {"exact": exact, "images_including_sentinels": images, "phases": details}
    repeats = {}
    for name, phases in records.items():
        grouped = {}
        for phase, values in phases.items():
            for label, value in values.items():
                grouped.setdefault(value["payload_sha256"], []).append((phase, label, value["pixels"]))
        groups = [group for group in grouped.values() if len(group) > 1]
        repeats[name] = {"duplicate_payload_groups": len(groups), "status": "NOT_APPLICABLE" if not groups else
                        ("EXACT" if all(all(item[2] == group[0][2] for item in group) for group in groups) else "DIFFERENCE")}
    passed = all(value["exact"] for value in comparisons.values()) and all(value["status"] != "DIFFERENCE" for value in repeats.values())
    evidence = {name: {path.relative_to(root).as_posix(): sha(path) for path in sorted(root.rglob("*"))
                if path.is_file() and path.suffix in (".json", ".jsonl", ".png", ".bin")}
                for name, root in paths.items()}
    require(modules.bundle.verify(modules.root) == modules.frozen, "Frozen quality bundle changed during analysis")
    summary = {"schema_version": 1, "qualification_type": "native_oao_quality_exact_only", "kind": "native_quality_oao_exact",
               "status": "PASS_EXACT_CORPUS" if passed else "NUMERICAL_REVIEW_REQUIRED",
               "quality_exact_gate_passed": passed, "scored": False, "performance_qualified": False,
               "historical_unstable_control_resolved": False,
               "historical_control_note": "Earlier uninstrumented pilot baseline process variance was observed. Later O/O boundary agreement did not explain or resolve it.",
               "scope": "This frozen three-arm corpus and sentinel outputs only. No population determinism, bitwise floating-point intermediate or image-quality claim.",
               "not_a_run_native_qualification": True,
               "base_sha": read(base_manifest)["head_sha"], "candidate_sha": read(candidate_manifest)["head_sha"],
               "quality_bundle_manifest_sha256": sha(modules.root / "BUNDLE_MANIFEST.json"),
               "analysis_script_sha256": sha(Path(__file__)),
               "source_manifests_sha256": {"base": sha(base_manifest), "candidate": sha(candidate_manifest)},
               "input_files_sha256": {"base_manifest": {"file": Path(base_manifest).name, "sha256": sha(base_manifest)},
                   "candidate_manifest": {"file": Path(candidate_manifest).name, "sha256": sha(candidate_manifest)},
                   "analysis_script": {"file": "analysis_tools/compare_quality_oao.py", "sha256": sha(Path(__file__))},
                   "quality_bundle_manifest": {"file": "quality_harness/BUNDLE_MANIFEST.json", "sha256": sha(modules.root / "BUNDLE_MANIFEST.json")}},
               "arm_paths": {name: str(path) for name, path in paths.items()},
               "comparisons": comparisons, "within_arm_same_payload_controls": repeats,
               "requests_per_arm": 42, "images_per_arm": 93, "corpus_images_per_pair": 86, "sentinel_images_per_pair": 7,
               "runtime_settings": {key: metadata["O1"][key] for key in COMMON if key not in ("quality_bundle_sha256", "server_command")},
               "evidence_sha256": evidence,
               "evidence_limits": ["Generation raw response JSON was not retained by the frozen client; all saved image bytes and decoded pixels are rehashed.",
                                   "Edit multipart requests, raw responses, input fixtures and image bytes are revalidated.",
                                   "Weight files are not rehashed by this analyzer; model revision/config and prior source/startup receipts are checked.",
                                   "Every corpus case runs once per service; no within-arm repeat claim without duplicate identical payloads."]}
    (output / "qualification.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("o1", "candidate", "o2", "harness", "base-manifest", "candidate-manifest", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--ssim", action="store_true")
    args = parser.parse_args()
    result = analyze(args.o1, args.candidate, args.o2, args.harness, args.base_manifest, args.candidate_manifest, args.output, args.ssim)
    print(json.dumps({key: result[key] for key in ("status", "quality_exact_gate_passed", "historical_unstable_control_resolved")}, indent=2))
    raise SystemExit(0 if result["quality_exact_gate_passed"] else 2)


if __name__ == "__main__":
    main()
