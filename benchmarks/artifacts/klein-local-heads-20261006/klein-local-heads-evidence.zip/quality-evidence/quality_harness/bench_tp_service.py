#!/usr/bin/env python3
"""Quality-session adapter for the existing launcher's client CLI.

One already running service receives square, both rectangles, then editing.
The unchanged generation client is retained in bench_core.py.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
import time
import traceback
from pathlib import Path

import bench_core as core
import bundle_integrity
from quality_tools import edit_regression

PROMPT = core.PROMPT
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "quality_tools/data"


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def run(args, edit_batches=(1,)):
    if not args.diagnostic or args.profile_batches or args.capture_arm_file or args.quality_cases:
        raise ValueError("Quality session must be unscored, without profiler/capture or extra ad hoc cases")
    if args.batches != [1, 4] or args.warmup != 0 or args.repeats != 1 or args.steps != 4:
        raise ValueError("Frozen quality session requires --batches 1 4 --warmup 0 --repeats 1 --steps 4")
    if (args.width, args.height) != (1024, 1024) or args.model != "klein-local-heads-bench":
        raise ValueError("Wrong frozen model name or generation size")
    if args.quality_corpus is None or args.quality_corpus.resolve() != (DATA / "square.json").resolve():
        raise ValueError("Use the square corpus from this frozen bundle")
    if list(edit_batches) not in ([1], [1, 4]):
        raise ValueError("Editing batches must be 1, or 1 4")
    before = bundle_integrity.verify(ROOT)
    quality = args.output.parent / "quality"
    quality.mkdir(parents=True, exist_ok=False)
    session = {"schema_version": 1, "status": "RUNNING", "arm": args.arm, "source_sha": args.source_sha,
               "scored": False, "started_unix_s": time.time(), "phases": [],
               "scripts_sha256": {name: value for name, value in before.items() if name.endswith(".py")},
               "bundle_manifest_sha256": hashlib.sha256((ROOT / bundle_integrity.MANIFEST).read_bytes()).hexdigest(),
               "editing_batches": list(edit_batches), "editing_repeats": 1,
               "actual_generation_requests": 40, "actual_generation_images": 91,
               "corpus_generation_requests": 36, "corpus_generation_images": 84,
               "notes": "Generation client adds 4 sentinel requests/7 images. All requests are non-scored."}
    path = quality / "session.json"
    write_json(path, session)

    def generation(phase, phase_args):
        record = {"phase": phase, "output": str(phase_args.output), "status": "RUNNING",
                  "width": phase_args.width, "height": phase_args.height,
                  "corpus_sha256": hashlib.sha256(phase_args.quality_corpus.read_bytes()).hexdigest()}
        session["phases"].append(record)
        write_json(path, session)
        core.run(phase_args)
        validation = json.loads((phase_args.output / "validation.json").read_text())
        if validation.get("status") != "PASS" or validation.get("scored") is not False:
            raise RuntimeError("Generation phase did not complete as non-scored evidence")
        record.update(status="PASS", validation=validation)
        write_json(path, session)

    try:
        generation("square", args)
        for width, height in ((768, 1024), (1024, 768)):
            rectangle = copy.copy(args)
            rectangle.batches = [1]
            rectangle.width, rectangle.height = width, height
            rectangle.quality_corpus = DATA / f"rectangle-{width}x{height}.json"
            rectangle.output = quality / f"rectangle-{width}x{height}"
            generation(f"rectangle-{width}x{height}", rectangle)
        edit_args = argparse.Namespace(base_url=args.base_url, model=args.model, fixtures=DATA,
                                       output=quality / "edits", arm=args.arm, source_sha=args.source_sha,
                                       batches=list(edit_batches), input_counts=[1, 2], repeats=1,
                                       seed=8137, request_timeout=args.request_timeout, check=False)
        record = {"phase": "edits", "output": str(edit_args.output), "status": "RUNNING"}
        session["phases"].append(record)
        write_json(path, session)
        result = edit_regression.run(edit_args)
        if result.get("status") != "PASS" or result.get("scored") is not False:
            raise RuntimeError("Editing phase did not complete as non-scored evidence")
        record.update(status="PASS", requests=result["requests"], images=result["images"])
        if bundle_integrity.verify(ROOT) != before:
            raise RuntimeError("Quality bundle changed during the session")
        session.update(status="PASS", bundle_unchanged=True,
                       actual_total_requests=40 + result["requests"], actual_total_images=91 + result["images"])
    except BaseException as exc:
        session.update(status="FAIL", error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        session["ended_unix_s"] = time.time()
        write_json(path, session)
    return session


def main():
    adapter = argparse.ArgumentParser(add_help=False)
    adapter.add_argument("--edit-batches", nargs="+", type=int, choices=(1, 4), default=[1])
    extra, remaining = adapter.parse_known_args()
    sys.argv = [sys.argv[0], *remaining]
    run(core.parse_args(), extra.edit_batches)


if __name__ == "__main__":
    main()
