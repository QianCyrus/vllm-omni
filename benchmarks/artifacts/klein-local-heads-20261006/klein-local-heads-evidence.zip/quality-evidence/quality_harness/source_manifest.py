#!/usr/bin/env python3
"""Hash a clean committed checkout or a frozen git-archive export; no GPU imports."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_files(root):
    root = Path(root).resolve()
    files = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if ".git" in relative.parts or "__pycache__" in relative.parts or relative.as_posix() == "COMMIT":
            continue
        if path.is_file():
            if not path.resolve().is_relative_to(root):
                raise ValueError(f"Source symlink escapes root: {relative}")
            files[relative.as_posix()] = sha256(path)
    return files


def identity(root, expected):
    if len(expected) != 40 or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("Source SHA must be a complete lowercase commit SHA")
    if (root / ".git").exists():
        actual = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(
            ["git", "-C", str(root), "status", "--porcelain", "--untracked-files=all"], text=True
        )
        if dirty:
            raise ValueError("Source checkout must be clean, including untracked files")
    else:
        actual = (root / "COMMIT").read_text().strip()
    if actual != expected:
        raise ValueError(f"Source identity {actual} != {expected}")


def verify_source(root, expected, manifest_path):
    root = Path(root).resolve()
    identity(root, expected)
    manifest = json.loads(Path(manifest_path).read_text())
    if manifest.get("head_sha") != expected or manifest.get("schema_version") != 2:
        raise ValueError("Wrong source manifest SHA/schema")
    actual = source_files(root)
    if actual != manifest["files"]:
        differences = sorted(name for name in actual.keys() | manifest["files"].keys()
                             if actual.get(name) != manifest["files"].get(name))
        raise ValueError(f"Source file set/content changed: {differences[:10]}")
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--base-sha", default="5f95115e703ffe51e03e40ae23c78ff841c3335e")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    if args.output.resolve().is_relative_to(root):
        raise ValueError("Manifest must live outside the frozen source root")
    identity(root, args.source_sha)
    record = {"schema_version": 2, "head_sha": args.source_sha, "base_sha": args.base_sha,
              "files": source_files(root)}
    with args.output.open("x") as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
    verify_source(root, args.source_sha, args.output)
    print(json.dumps({"status": "PASS", "head_sha": args.source_sha, "files": len(record["files"]),
                      "manifest_sha256": sha256(args.output)}))


if __name__ == "__main__":
    main()
