"""CPU-only validation of worker/constructor/compile receipts."""

import json
from pathlib import Path

from source_manifest import sha256


def verify_startup_proofs(directory, source_root, source_sha, module_sha, variant, hook_sha, tp, compile_mode):
    source_root = Path(source_root).resolve()
    paths = sorted(Path(directory).glob("rank*.json"))
    if [path.name for path in paths] != [f"rank{rank}.json" for rank in range(tp)]:
        raise ValueError("Incomplete startup receipts")
    local = variant == "A" and tp > 1
    expected_heads = 24 // tp if local else 24
    records = []
    for rank, path in enumerate(paths):
        record = json.loads(path.read_text())
        if any(record.get(k) != v for k, v in {
            "status": "PASS", "rank": rank, "tp_rank": rank, "world_size": tp, "tp_world_size": tp,
            "source_sha": source_sha, "module_sha256": module_sha, "hook_sha256": hook_sha,
            "variant": variant, "compile_mode": compile_mode,
        }.items()):
            raise ValueError(f"Rank {rank} identity/config mismatch")
        if not Path(record["module_file"]).resolve().is_relative_to(source_root):
            raise ValueError("Worker imported unexpected model source")
        if not record.get("worker", {}).get("ir_priority_resolved_by_native_worker"):
            raise ValueError("Missing native worker IR priority resolution receipt")
        blocks = record.get("blocks", [])
        if len(blocks) != 20:
            raise ValueError("Expected 20 single blocks")
        for index, block in enumerate(blocks):
            if any(block.get(k) != v for k, v in {
                "index": index, "global_heads": 24, "local_tp": local,
                "query_num_heads": expected_heads, "attention_num_heads": expected_heads,
            }.items()):
                raise ValueError(f"Rank {rank}, single block {index}: unexpected heads/path")
        compiled = record.get("compile", {}).get("single_block_wrappers", [])
        if compile_mode == "regional" and (len(compiled) != 20 or not all(compiled)):
            raise ValueError("Regional compile was not configured for every single block")
        if record.get("load_model_complete") is not True:
            raise ValueError("Model loading receipt incomplete")
        records.append(record)
    return {"status": "PASS", "scope": "Native worker priority, construction and configured compile wrappers; "
            "not a kernel-execution or image-equivalence proof", "records": records,
            "files_sha256": {path.name: sha256(path) for path in paths}}
