"""Exercise the actual adapter subprocess with a CPU HTTP stub, including failure propagation."""

import base64
import email.parser
import email.policy
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from quality_tools.compare_quality import compare

ROOT = Path(__file__).resolve().parent
TEMP = ROOT / ".selftest"
TEMP.mkdir(exist_ok=True)


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=TEMP)
        self.root = Path(self.tmp.name)
        self.observed = []
        self.fail_size = None
        test = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                from PIL import Image

                raw = self.rfile.read(int(self.headers["Content-Length"]))
                if self.path == "/v1/images/generations":
                    fields = json.loads(raw)
                    image_count = 0
                else:
                    message = email.parser.BytesParser(policy=email.policy.default).parsebytes(
                        f"Content-Type: {self.headers['Content-Type']}\r\nMIME-Version: 1.0\r\n\r\n".encode() + raw)
                    fields, images = {}, []
                    for part in message.iter_parts():
                        name = part.get_param("name", header="content-disposition")
                        if name == "image":
                            images.append(part.get_payload(decode=True))
                        else:
                            fields[name] = part.get_content().strip()
                    image_count = len(images)
                test.observed.append({"route": self.path, "fields": fields, "input_images": image_count})
                if fields["size"] == test.fail_size:
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(b'{"error":"injected rectangle failure"}')
                    return
                width, height = map(int, fields["size"].split("x"))
                data = []
                for index in range(int(fields["n"])):
                    buffer = io.BytesIO()
                    Image.new("RGB", (width, height), (index * 20, 41, 89)).save(buffer, format="PNG")
                    data.append({"b64_json": base64.b64encode(buffer.getvalue()).decode()})
                result = json.dumps({"data": data}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(result)))
                self.end_headers()
                self.wfile.write(result)

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.tmp.cleanup()

    def invoke(self, variant):
        output = self.root / variant
        output.mkdir()
        command = [sys.executable, str(ROOT / "bench_tp_service.py"),
                   "--base-url", f"http://127.0.0.1:{self.server.server_port}", "--output", str(output / "http"),
                   "--arm", variant, "--source-sha", ("a" if variant == "O" else "b") * 40,
                   "--warmup", "0", "--repeats", "1", "--batches", "1", "4", "--diagnostic",
                   "--quality-corpus", str(ROOT / "quality_tools/data/square.json"), "--edit-batches", "1"]
        return subprocess.run(command, capture_output=True, text=True, env=os.environ.copy(), timeout=60), output

    def test_full_session_uses_one_http_server_and_all_phases(self):
        for variant in ("O", "A"):
            result, output = self.invoke(variant)
            self.assertEqual(result.returncode, 0, result.stderr)
            session = json.loads((output / "quality/session.json").read_text())
            self.assertEqual(session["status"], "PASS")
            self.assertEqual(session["actual_total_requests"], 42)
            self.assertEqual(session["actual_total_images"], 93)
            self.assertTrue(session["bundle_unchanged"])
            self.assertEqual([phase["phase"] for phase in session["phases"]],
                             ["square", "rectangle-768x1024", "rectangle-1024x768", "edits"])
            self.assertEqual(len(session["scripts_sha256"]), len(list(ROOT.glob("*.py"))) + len(list((ROOT / "hooks").glob("*.py"))) + len(list((ROOT / "quality_tools").glob("*.py"))))
        self.assertEqual(len(self.observed), 84)
        self.assertEqual([item["input_images"] for item in self.observed if item["route"].endswith("edits")], [1, 2, 1, 2])
        total = 0
        for relative, kind in (("http", "generation"), ("quality/rectangle-768x1024", "generation"),
                               ("quality/rectangle-1024x768", "generation"), ("quality/edits", "edit")):
            report = compare(self.root / "O" / relative, self.root / "A" / relative, kind)
            self.assertEqual(report["status"], "EXACT")
            total += report["images"]
        self.assertEqual(total, 86)

    def test_failure_stops_remaining_phases_and_returns_nonzero(self):
        self.fail_size = "768x1024"
        result, output = self.invoke("O")
        self.assertNotEqual(result.returncode, 0)
        session = json.loads((output / "quality/session.json").read_text())
        self.assertEqual(session["status"], "FAIL")
        self.assertEqual([phase["phase"] for phase in session["phases"]], ["square", "rectangle-768x1024"])
        self.assertEqual(len(self.observed), 35)
        self.assertTrue(all(item["route"] == "/v1/images/generations" for item in self.observed))
        self.assertFalse((output / "quality/edits").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
