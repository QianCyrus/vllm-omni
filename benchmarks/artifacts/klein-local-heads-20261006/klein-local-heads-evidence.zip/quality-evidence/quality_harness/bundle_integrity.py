"""Freeze and recheck every packaged quality-harness file, including fixtures."""

import argparse
import hashlib
import json
from pathlib import Path

MANIFEST = "BUNDLE_MANIFEST.json"


def inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        name = path.relative_to(root)
        if name.as_posix() == MANIFEST or any(part == "__pycache__" or part.startswith(".") for part in name.parts):
            continue
        if path.is_file():
            if not path.resolve().is_relative_to(root.resolve()):
                raise ValueError("Harness symlink escapes frozen bundle")
            result[name.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def verify(root):
    manifest = json.loads((root / MANIFEST).read_text())
    actual = inventory(root)
    if manifest.get("schema_version") != 1 or actual != manifest["files"]:
        raise ValueError("Quality bundle changed, or a file was added/removed after freezing")
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.freeze:
        with (root / MANIFEST).open("x") as stream:
            stream.write(json.dumps({"schema_version": 1, "files": inventory(root)}, indent=2, sort_keys=True) + "\n")
    files = verify(root)
    print(json.dumps({"status": "PASS", "files": len(files), "scripts": sum(name.endswith(".py") for name in files)}))


if __name__ == "__main__":
    main()
