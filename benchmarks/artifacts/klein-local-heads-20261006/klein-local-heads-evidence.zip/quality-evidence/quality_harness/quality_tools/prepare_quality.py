#!/usr/bin/env python3
"""Freeze existing-workload corpora and two synthetic, non-personal edit fixtures."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path


def write_json(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def payload(model, prompt, seed, batch, size):
    return {"model": model, "prompt": prompt, "seed": seed, "n": batch, "size": size,
            "num_inference_steps": 4, "guidance_scale": 1.0, "generator_device": "cpu",
            "response_format": "b64_json", "output_format": "png", "output_compression": 100,
            "return_stage_metrics": True}


def pattern(index):
    from PIL import Image, ImageDraw

    image = Image.new("RGB", (1024, 1024), (242, 242, 235))
    draw = ImageDraw.Draw(image)
    # Integer geometry, no fonts, no downloaded image and no random generator.
    for y in range(0, 1024, 64):
        for x in range(0, 1024, 64):
            if ((x // 64) + (y // 64) + index) % 2 == 0:
                draw.rectangle((x, y, x + 63, y + 63), fill=(227, 230, 222))
    if index == 0:
        draw.ellipse((128, 128, 448, 448), fill=(214, 51, 48), outline=(60, 25, 24), width=8)
        draw.rectangle((568, 176, 888, 432), fill=(41, 150, 82), outline=(20, 66, 40), width=8)
        draw.polygon([(184, 824), (376, 504), (568, 824)], fill=(47, 92, 196))
        for x in range(648, 904, 32):
            draw.rectangle((x, 552, x + 15, 856), fill=(38, 38, 38))
    elif index == 1:
        draw.rounded_rectangle((120, 128, 448, 464), radius=48, fill=(245, 181, 44), outline=(85, 62, 18), width=8)
        draw.ellipse((592, 160, 912, 480), fill=(83, 49, 178), outline=(38, 23, 69), width=8)
        draw.polygon([(160, 624), (464, 624), (552, 864), (72, 864)], fill=(34, 163, 187))
        for y in range(600, 904, 32):
            draw.rectangle((664, y, 904, y + 15), fill=(50, 50, 50))
    else:
        raise ValueError("Only fixture indices 0 and 1 are defined")
    return image


def prepare(workloads, output):
    spec_bytes = workloads.read_bytes()
    spec = json.loads(spec_bytes)
    output.mkdir(parents=True, exist_ok=False)
    quality = spec["quality"]
    common = {"schema_version": 1, "source_workloads_sha256": hashlib.sha256(spec_bytes).hexdigest(),
              "base_sha": spec["base_sha"], "model_revision": spec["model_revision"],
              "purpose": "Matched baseline/candidate quality only; not performance samples"}
    square = []
    for prompt in quality["prompts"]:
        for seed in quality["seeds"]:
            for batch in (1, 4):
                square.append({"case_id": f"{prompt['id']}-seed{seed}-b{batch}",
                               "payload": payload(spec["served_model_name"], prompt["text"], seed, batch, "1024x1024")})
    write_json(output / "square.json", {**common, "cases": square})
    rectangle = quality["rectangular_regression"]
    for size in rectangle["sizes"]:
        cases = [{"case_id": f"{prompt['id']}-seed{rectangle['seed']}-b1-{size}",
                  "payload": payload(spec["served_model_name"], prompt["text"], rectangle["seed"], 1, size)}
                 for prompt in quality["prompts"] if prompt["id"] in rectangle["prompt_ids"]]
        write_json(output / f"rectangle-{size}.json", {**common, "cases": cases})
    fixtures = []
    for index in range(2):
        image = pattern(index)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG", optimize=False, compress_level=9)
        data = buffer.getvalue()
        name = f"pattern-{index + 1}.png"
        (output / name).write_bytes(data)
        fixtures.append({"file": name, "width": 1024, "height": 1024, "mode": "RGB", "bytes": len(data),
                         "png_sha256": hashlib.sha256(data).hexdigest(),
                         "pixel_sha256": hashlib.sha256(image.tobytes()).hexdigest()})
    manifest = {**common, "fixture_origin": "Synthetic integer geometry generated locally by prepare_quality.py; no personal images",
                "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "fixtures": fixtures,
                "generation_quality_requests": 32, "generation_quality_images": 80,
                "rectangular_quality_requests": 4, "rectangular_quality_images": 4,
                "corpora_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(output.glob("*.json"))}}
    write_json(output / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workloads", type=Path, default=Path(__file__).parent.parent / "workloads.json")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "data")
    args = parser.parse_args()
    manifest = prepare(args.workloads.resolve(), args.output.resolve())
    print(json.dumps({"status": "PREPARED_NOT_GPU_TESTED", "output": str(args.output),
                      "quality_cases": manifest["generation_quality_requests"], "fixtures": manifest["fixtures"]}, indent=2))


if __name__ == "__main__":
    main()
