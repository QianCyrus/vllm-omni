#!/usr/bin/env python3
"""Unscored multipart image-edit regression against an already running local API."""

from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

PROMPT = ("Create a clean studio illustration based on the reference image or images. "
          "Keep the colored geometric shapes and add a soft light-blue background with gentle shadows.")
BASE_SHA = "5f95115e703ffe51e03e40ae23c78ff841c3335e"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def load_fixtures(directory):
    from PIL import Image

    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    fixtures = []
    if len(manifest["fixtures"]) != 2:
        raise ValueError("Expected exactly two frozen synthetic fixtures")
    for record in manifest["fixtures"]:
        path = directory / record["file"]
        if not path.resolve().is_relative_to(directory.resolve()):
            raise ValueError("Fixture escapes frozen directory")
        data = path.read_bytes()
        with Image.open(io.BytesIO(data)) as source:
            image = source.convert("RGB")
            image.load()
        if digest(data) != record["png_sha256"] or digest(image.tobytes()) != record["pixel_sha256"]:
            raise ValueError("Fixture content differs from frozen manifest")
        if image.size != (1024, 1024) or record["bytes"] != len(data):
            raise ValueError("Wrong fixture dimensions/size")
        fixtures.append((record, data))
    return manifest, fixtures


def multipart(fields, fixtures):
    identity = {"fields": fields, "input_images": [record for record, _ in fixtures]}
    boundary = "----KleinNativeEdit" + digest(canonical(identity))[:24]
    chunks = []
    for key, value in fields.items():
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
    for record, data in fixtures:
        if boundary.encode() in data:
            raise ValueError("Multipart boundary collides with input bytes")
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{record["file"]}"\r\nContent-Type: image/png\r\n\r\n'.encode())
        chunks.extend([data, b"\r\n"])
    chunks.append(f"--{boundary}--\r\n".encode())
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}", identity


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8091")
    parser.add_argument("--model", default="klein-local-heads-bench")
    parser.add_argument("--fixtures", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--batches", type=int, nargs="+", choices=(1, 4), default=[1])
    parser.add_argument("--input-counts", type=int, nargs="+", choices=(1, 2), default=[1, 2])
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--seed", type=int, default=8137)
    parser.add_argument("--request-timeout", type=float, default=300)
    parser.add_argument("--check", action="store_true", help="Validate frozen inputs and print cases; no requests or output directory")
    return parser.parse_args()


def run(args):
    from PIL import Image

    if len(args.source_sha) != 40 or any(c not in "0123456789abcdef" for c in args.source_sha):
        raise ValueError("Expected a full source commit SHA")
    parsed = urllib.parse.urlparse(args.base_url)
    if parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1") or parsed.username:
        raise ValueError("This client is restricted to an already running local HTTP API")
    if args.repeats < 1 or args.request_timeout <= 0 or len(args.batches) != len(set(args.batches)) or len(args.input_counts) != len(set(args.input_counts)):
        raise ValueError("Invalid repeats/timeout or duplicate cases")
    manifest, fixtures = load_fixtures(args.fixtures)
    cases = []
    for count in args.input_counts:
        for batch in args.batches:
            fields = {"model": args.model, "prompt": PROMPT, "n": str(batch), "size": "1024x1024",
                      "num_inference_steps": "4", "guidance_scale": "1.0", "seed": str(args.seed),
                      "generator_device": "cpu", "response_format": "b64_json", "output_format": "png",
                      "output_compression": "100", "return_stage_metrics": "true"}
            body, content_type, identity = multipart(fields, fixtures[:count])
            cases.append((f"edit-input{count}-b{batch}-seed{args.seed}", batch, body, content_type, identity))
    if args.check:
        print(json.dumps({"status": "STATIC_CHECK_PASS", "cases": [case[0] for case in cases],
                          "requests": len(cases) * args.repeats, "scored": False}, indent=2))
        return
    args.output.mkdir(parents=True, exist_ok=False)
    for name in ("inputs", "requests", "responses", "images"):
        (args.output / name).mkdir()
    write_json(args.output / "inputs/manifest.json", manifest)
    for record, data in fixtures:
        (args.output / "inputs" / record["file"]).write_bytes(data)
    metadata = {"schema_version": 1, "arm": args.arm, "source_sha": args.source_sha, "scored": False,
                "scope": "HTTP edit completion and output integrity; semantic quality and equivalence need cross-arm comparison",
                "endpoint": args.base_url.rstrip("/") + "/v1/images/edits", "base_protocol_sha": BASE_SHA,
                "protocol_source": "api_server.py:2315 and tests/entrypoints/openai_api/test_image_server.py:1578",
                "client_sha256": digest(Path(__file__).read_bytes()), "fixture_manifest_sha256": digest((args.fixtures / "manifest.json").read_bytes()),
                "batches": args.batches, "input_counts": args.input_counts, "repeats": args.repeats,
                "started_unix_s": time.time(), "status": "RUNNING"}
    write_json(args.output / "metadata.json", metadata)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    rows = []
    try:
        for case_id, batch, body, content_type, identity in cases:
            (args.output / "requests" / f"{case_id}.multipart.bin").write_bytes(body)
            write_json(args.output / "requests" / f"{case_id}.json", {**identity, "multipart_sha256": digest(body), "content_type": content_type})
            for repeat in range(args.repeats):
                label = f"{case_id}-repeat{repeat}"
                request = urllib.request.Request(metadata["endpoint"], data=body, headers={"Content-Type": content_type})
                started = time.perf_counter()
                try:
                    with opener.open(request, timeout=args.request_timeout) as response:
                        raw, status = response.read(), response.status
                except urllib.error.HTTPError as exc:
                    (args.output / "responses" / f"{label}.error.bin").write_bytes(exc.read())
                    raise RuntimeError(f"HTTP {exc.code}: see saved error response") from None
                elapsed_ms = (time.perf_counter() - started) * 1000
                (args.output / "responses" / f"{label}.json").write_bytes(raw)
                result = json.loads(raw)
                if status != 200 or not isinstance(result, dict) or not isinstance(result.get("data"), list) or len(result["data"]) != batch:
                    raise ValueError("Edit response status/image count invalid")
                images = []
                for index, item in enumerate(result["data"]):
                    if not isinstance(item.get("b64_json"), str) or not item["b64_json"]:
                        raise ValueError("Empty image output")
                    encoded = base64.b64decode(item["b64_json"], validate=True)
                    with Image.open(io.BytesIO(encoded)) as source:
                        if source.format != "PNG":
                            raise ValueError("Expected PNG output")
                        image = source.convert("RGB")
                        image.load()
                    if image.size != (1024, 1024) or not image.tobytes():
                        raise ValueError("Empty or wrong-size decoded output")
                    relative = f"images/{label}-i{index}.png"
                    (args.output / relative).write_bytes(encoded)
                    images.append({"file": relative, "index": index, "width": image.width, "height": image.height,
                                   "png_sha256": digest(encoded), "pixel_sha256": digest(image.tobytes()),
                                   "constant_rgb_image": all(lo == hi for lo, hi in image.getextrema())})
                row = {"case_id": case_id, "repeat": repeat, "arm": args.arm, "batch": batch,
                       "input_count": len(identity["input_images"]), "scored": False,
                       "request_sha256": digest(canonical(identity)), "multipart_sha256": digest(body),
                       "response_file": f"responses/{label}.json", "response_sha256": digest(raw),
                       "http_status": status, "wall_ms_unscored": elapsed_ms, "images": images,
                       "response_metrics": result.get("metrics")}
                rows.append(row)
                with (args.output / "requests.jsonl").open("a") as stream:
                    stream.write(json.dumps(row) + "\n")
                print(json.dumps({"case_id": case_id, "repeat": repeat, "images": len(images), "status": "COMPLETE", "scored": False}), flush=True)
        repeats = {}
        for case_id, *_ in cases:
            hashes = [[image["pixel_sha256"] for image in row["images"]] for row in rows if row["case_id"] == case_id]
            repeats[case_id] = {"repeats": len(hashes), "within_run_pixels_exact": all(value == hashes[0] for value in hashes) if len(hashes) > 1 else None}
        metadata.update(status="PASS", repeat_checks=repeats, requests=len(rows), images=sum(len(row["images"]) for row in rows))
    except BaseException as exc:
        metadata.update(status="FAIL", error=repr(exc))
        write_json(args.output / "failure.json", {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()})
        raise
    finally:
        metadata["ended_unix_s"] = time.time()
        write_json(args.output / "metadata.json", metadata)
    return metadata


if __name__ == "__main__":
    run(parse_args())
