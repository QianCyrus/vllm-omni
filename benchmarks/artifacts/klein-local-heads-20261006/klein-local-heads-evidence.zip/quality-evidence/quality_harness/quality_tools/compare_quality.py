#!/usr/bin/env python3
"""Match and rehash generation-corpus or edit outputs; never treat extras as corpus images."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_run(directory, kind):
    metadata = json.loads((directory / "metadata.json").read_text())
    rows = [json.loads(line) for line in (directory / "requests.jsonl").read_text().splitlines()]
    if kind == "generation":
        if json.loads((directory / "validation.json").read_text())["status"] != "PASS":
            raise ValueError("Generation client did not finish")
        rows = [row for row in rows if row["label"].startswith("quality-")]
        if len(rows) != metadata["quality_corpus_requests"]:
            raise ValueError("Generation quality corpus coverage incomplete")
        key = lambda row: row["label"]
        payload = lambda row: row["payload_sha256"]
    else:
        if metadata.get("status") != "PASS":
            raise ValueError("Edit client did not finish")
        if len(rows) != len(metadata["batches"]) * len(metadata["input_counts"]) * metadata["repeats"]:
            raise ValueError("Edit request coverage incomplete")
        key = lambda row: f"{row['case_id']}-repeat{row['repeat']}"
        payload = lambda row: row["request_sha256"]
    if not rows:
        raise ValueError("No quality rows found")
    indexed = {}
    for row in rows:
        label = key(row)
        if label in indexed or row["scored"]:
            raise ValueError("Duplicate or scored quality row")
        if kind == "generation" and sha(json.dumps(row["payload"], sort_keys=True, separators=(",", ":")).encode()) != row["payload_sha256"]:
            raise ValueError("Generation payload hash changed")
        if kind == "edit":
            if sha((directory / row["response_file"]).read_bytes()) != row["response_sha256"]:
                raise ValueError("Raw edit response changed")
        indexed[label] = {"payload_hash": payload(row), "images": row["images"]}
    return metadata, indexed


def pixels(directory, image):
    from PIL import Image
    import numpy as np

    path = directory / image["file"]
    if not path.resolve().is_relative_to((directory / "images").resolve()):
        raise ValueError("Image path escaped evidence directory")
    expected = image.get("png_sha256", image.get("saved_png_sha256"))
    if sha(path.read_bytes()) != expected:
        raise ValueError("Image file changed")
    with Image.open(path) as source:
        rgb = source.convert("RGB")
        rgb.load()
    if sha(rgb.tobytes()) != image["pixel_sha256"] or rgb.size != (image["width"], image["height"]):
        raise ValueError("Image pixels/dimensions changed")
    return np.asarray(rgb)


def compare(base, candidate, kind, compute_ssim=False):
    import numpy as np

    bm, br = read_run(base, kind)
    cm, cr = read_run(candidate, kind)
    common = ("client_sha256", "quality_corpus_sha256") if kind == "generation" else ("client_sha256", "fixture_manifest_sha256")
    if any(bm.get(field) != cm.get(field) for field in common) or br.keys() != cr.keys():
        raise ValueError("Different client/corpus/fixture or request coverage")
    records = []
    for label, left in br.items():
        right = cr[label]
        if left["payload_hash"] != right["payload_hash"] or len(left["images"]) != len(right["images"]):
            raise ValueError("Different request or image count")
        for a, b in zip(left["images"], right["images"], strict=True):
            if a["index"] != b["index"]:
                raise ValueError("Image order differs")
            original, changed = pixels(base, a), pixels(candidate, b)
            if original.shape != changed.shape:
                raise ValueError("Image shape differs")
            difference = original.astype(np.float64) - changed.astype(np.float64)
            mse = float(np.square(difference).mean())
            item = {"case_id": label, "image_index": a["index"], "exact": mse == 0,
                    "mae_8bit": float(np.abs(difference).mean()), "rmse_8bit": math.sqrt(mse),
                    "max_abs_8bit": int(np.abs(difference).max()),
                    "psnr_db": 10 * math.log10(255**2 / mse) if mse else None}
            if compute_ssim:
                from skimage.metrics import structural_similarity
                item["ssim"] = float(structural_similarity(original, changed, channel_axis=-1, data_range=255))
            records.append(item)
    return {"status": "EXACT" if all(record["exact"] for record in records) else "DIFFERENCES_RECORDED",
            "kind": kind, "base_sha": bm["source_sha"], "candidate_sha": cm["source_sha"],
            "requests": len(br), "images": len(records), "exact_images": sum(record["exact"] for record in records),
            "scored": False, "quality_gate_passed": None,
            "scope": "Matched output differences. Threshold decisions and visual inspection are separate.",
            "ssim_computed": compute_ssim, "records": records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True, help="Client output directory, not server arm directory")
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--kind", choices=("generation", "edit"), required=True)
    parser.add_argument("--ssim", action="store_true", help="Requires scikit-image; no proxy/downsample substitute")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = compare(args.base.resolve(), args.candidate.resolve(), args.kind, args.ssim)
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "requests", "images", "exact_images")}))


if __name__ == "__main__":
    main()
