#!/usr/bin/env python3
"""Compare complete, cleaned-up O/A quality arms across all four phases."""

import argparse
import hashlib
import json
from pathlib import Path

import bundle_integrity
from quality_tools.compare_quality import compare

PHASES = {"square": "http", "rectangle-768x1024": "quality/rectangle-768x1024",
          "rectangle-1024x768": "quality/rectangle-1024x768", "edits": "quality/edits"}


def inspect(arm):
    metadata = json.loads((arm / "metadata.json").read_text())
    if (metadata.get("status") != "PASS" or not metadata.get("source_unchanged")
            or not metadata.get("cleanup_complete") or not metadata.get("startup_proof_unchanged")
            or metadata.get("scored") is not False):
        raise ValueError("Arm source/startup/cleanup did not pass")
    session_bytes = (arm / "quality/session.json").read_bytes()
    if hashlib.sha256(session_bytes).hexdigest() != metadata.get("quality_session_sha256"):
        raise ValueError("Quality session receipt changed after launcher validation")
    session = json.loads(session_bytes)
    if session != metadata.get("quality_session") or session.get("status") != "PASS":
        raise ValueError("Quality session is incomplete or differs from arm receipt")
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ssim", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    frozen = bundle_integrity.verify(root)
    base, candidate = inspect(args.base), inspect(args.candidate)
    if base["variant"] != "O" or candidate["variant"] != "A":
        raise ValueError("Expected base O and candidate A")
    for field in ("quality_bundle_sha256", "quality_bundle_manifest_sha256", "compile_mode", "parallelism",
                  "dtype", "attention_backend", "cache_backend", "vae_mode", "vae_degree",
                  "model_revision", "model_config_sha256", "versions"):
        if base.get(field) != candidate.get(field):
            raise ValueError(f"Unmatched experiment setting: {field}")
    if base["quality_bundle_sha256"] != frozen:
        raise ValueError("Comparator differs from the frozen executed quality bundle")
    args.output.mkdir(parents=True, exist_ok=False)
    phases = {}
    for name, relative in PHASES.items():
        report = compare(args.base / relative, args.candidate / relative, "edit" if name == "edits" else "generation", args.ssim)
        if report["base_sha"] != base["source_sha"] or report["candidate_sha"] != candidate["source_sha"]:
            raise ValueError("Client source identity differs from server arm")
        (args.output / f"{name}.json").write_text(json.dumps(report, indent=2) + "\n")
        phases[name] = {key: report[key] for key in ("status", "requests", "images", "exact_images")}
    summary = {"status": "EXACT" if all(value["status"] == "EXACT" for value in phases.values()) else "DIFFERENCES_RECORDED",
               "base_sha": base["source_sha"], "candidate_sha": candidate["source_sha"], "scored": False,
               "quality_gate_passed": None, "phases": phases,
               "images_compared": sum(phase["images"] for phase in phases.values()),
               "scope": "Corpus and edit images only; seven generation sentinel images are excluded."}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
