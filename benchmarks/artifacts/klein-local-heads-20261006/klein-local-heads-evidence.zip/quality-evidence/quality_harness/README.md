# One native server per quality arm

This is a separate copy of the prepared harness. The original `harness/` is unchanged. `bench_core.py` is an unchanged copy of its generation client. The new `bench_tp_service.py` adapts the same client CLI and runs square, both rectangular corpora, and editing sequentially against the same server. Any failure produces a nonzero client exit; `launch_native.py` then fails and cleans up its tracked server processes.

Every arm has one server start and one client process. Default traffic is **42 requests / 93 images**: square 34/85 (including two sentinel requests), rectangles 6/6 (including two sentinel requests), and editing 2/2 (one reference image, then two reference images; B1 outputs). The actual quality comparison covers **38 requests / 86 images**, excluding the four generation sentinels / seven images. Optional `--edit-batches 1 4` expands editing to 4 requests / 10 images, giving 44 requests / 101 images in total.

All requests are non-scored. The server uses the same native startup image dummy and constructor/worker/compile receipts as the pilot. There is no profiler, boundary observer, synchronizing stage timer, production source patch, or optimization environment selector. `--diagnostic` is required because this is quality-only traffic.

## Integrity

`BUNDLE_MANIFEST.json` records every packaged file, including every executing Python script, both fixtures and all corpora. The launcher and client verify it before and after execution. The launcher records the entire file map plus manifest SHA in its metadata; the client records all script hashes and the corpus hash for each phase. The existing source manifests still independently bind the O/A production exports.

Only `__pycache__` and hidden temporary files/directories are excluded. Do not put run outputs inside the frozen bundle. Do not change a script after freezing: create a new bundle instead. Local-only tests use `.selftest/`, and no GPU tests have been run by preparing this bundle.

## Two controlled launches

Inside one existing PJM allocation, use the same model snapshot, Python environment, GPU assignment, TP4 settings and server port for both arms. Set the following variables to the actual remote paths and **full** source SHAs. Run O and A sequentially; if O fails, stop before A. The launcher itself requires `PJM_JOBID` and does not submit jobs.

```sh
set -eu
python "$QUALITY_HARNESS/launch_native.py" \
  --source-root "$BASE_EXPORT" --source-sha "$BASE_SHA" --source-manifest "$BASE_MANIFEST" \
  --model "$MODEL_SNAPSHOT" --output "$QUALITY_OUTPUT/01-O" --cache-root "$QUALITY_CACHE" \
  --arm O --variant O --tensor-parallel-size 4 --port 8091 --compile-mode regional \
  --batches 1 4 --warmup 0 --repeats 1 --steps 4 --diagnostic --edit-batches 1 \
  --quality-corpus "$QUALITY_HARNESS/quality_tools/data/square.json" \
  --startup-timeout 900 --run-timeout 1800

python "$QUALITY_HARNESS/launch_native.py" \
  --source-root "$CANDIDATE_EXPORT" --source-sha "$CANDIDATE_SHA" --source-manifest "$CANDIDATE_MANIFEST" \
  --model "$MODEL_SNAPSHOT" --output "$QUALITY_OUTPUT/02-A" --cache-root "$QUALITY_CACHE" \
  --arm A --variant A --tensor-parallel-size 4 --port 8091 --compile-mode regional \
  --batches 1 4 --warmup 0 --repeats 1 --steps 4 --diagnostic --edit-batches 1 \
  --quality-corpus "$QUALITY_HARNESS/quality_tools/data/square.json" \
  --startup-timeout 900 --run-timeout 1800
```

Use a new output root and a new node-local `/tmp` cache root for each pair. A shared cache parent is fine because the two output names select distinct initially empty cache subdirectories. First run both commands with `--check`; it verifies the bundle and source manifests and prints commands without starting the server. The parent controls the outer allocation deadline and token-hour budget; the two per-arm limits do not create a new allocation.

## Output paths and comparison

For an arm `01-O` or `02-A`:

- `metadata.json`, `validation.json`, `server.log`, `client.log`, `startup_activation/`: server/source/configuration/cleanup proof.
- `http/`: square corpus and its two sentinel requests.
- `quality/rectangle-768x1024/`, `quality/rectangle-1024x768/`: respective corpus and one sentinel request each.
- `quality/edits/`: synthetic input PNGs, frozen manifest, raw multipart requests, raw response JSON/base64, output PNGs and decoded RGB hashes.
- `quality/session.json`: all four phase receipts, traffic counts and script hashes; its final SHA is bound into launcher metadata.

```sh
python "$QUALITY_HARNESS/compare_session.py" \
  --base "$QUALITY_OUTPUT/01-O" --candidate "$QUALITY_OUTPUT/02-A" \
  --output "$QUALITY_OUTPUT/comparison" --ssim
```

`--ssim` requires `scikit-image` and computes full-resolution RGB SSIM. Omit the flag if only exactness/MAE/RMSE/maximum difference/PSNR are needed. The comparator validates both completed launcher receipts, matching runtime/bundle identity, all phases and saved images. It produces one JSON file per phase and `summary.json`, and it excludes the generation sentinels. It records differences rather than silently passing them; the parent applies the predeclared numeric/visual gates.

## CPU verification

`python test_session.py` uses the actual adapter subprocess with a local HTTP stub. It tests a complete pair on one stub server, all 84 requests, one/two reference-image uploads, the 86-image matched comparison, and a deliberately failed rectangle that prevents later phases and exits nonzero. It needs Pillow and NumPy, but no model imports or GPU. `python bundle_integrity.py` rechecks the frozen package. Exclude `.selftest` and `__pycache__` when copying the package.
